import os
import base64
import pandas as pd
import numpy as np
import json
from io import BytesIO

class ExcelBridge:
    @staticmethod
    def save_excel_from_base64(base64_data, output_path):
        """
        Base64 formatındaki Excel verisini dosyaya kaydet
        """
        try:
            # Base64'ten binary veriye dönüştür
            binary_data = base64.b64decode(base64_data)
            
            # BytesIO nesnesi oluştur
            excel_data = BytesIO(binary_data)
            
            # Excel dosyasını oku
            dfs = pd.read_excel(excel_data, sheet_name=None)
            
            # Excel dosyasını kaydet
            with pd.ExcelWriter(output_path) as writer:
                for sheet_name, df in dfs.items():
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            return True, "Excel dosyası başarıyla kaydedildi."
        
        except Exception as e:
            return False, f"Hata: {str(e)}"
    
    @staticmethod
    def clean_excel(input_file, cleaning_options, output_file=None):
        """
        Excel dosyasını temizle
        """
        try:
            # Excel dosyasını oku
            if isinstance(input_file, str):
                dfs = pd.read_excel(input_file, sheet_name=None)
            else:
                # Base64'ten binary veriye dönüştür
                binary_data = base64.b64decode(input_file)
                excel_data = BytesIO(binary_data)
                dfs = pd.read_excel(excel_data, sheet_name=None)
            
            cleaned_dfs = {}
            cleaning_results = {}
            
            for sheet_name, df in dfs.items():
                original_rows = len(df)
                original_cols = len(df.columns)
                changes = []
                
                # Temizleme işlemlerini uygula
                df_cleaned = df.copy()
                
                # Eksik değerleri işle
                if cleaning_options.get('handle_missing', False):
                    missing_strategy = cleaning_options.get('missing_strategy', 'remove_rows')
                    missing_fill_value = cleaning_options.get('missing_fill_value', 0)
                    
                    missing_before = df_cleaned.isna().sum().sum()
                    
                    if missing_strategy == 'remove_rows':
                        df_cleaned = df_cleaned.dropna()
                        changes.append(f"Eksik değer içeren {missing_before} satır silindi")
                    
                    elif missing_strategy == 'remove_columns':
                        df_cleaned = df_cleaned.dropna(axis=1)
                        changes.append(f"Eksik değer içeren {missing_before} sütun silindi")
                    
                    elif missing_strategy == 'fill_value':
                        df_cleaned = df_cleaned.fillna(missing_fill_value)
                        changes.append(f"{missing_before} eksik değer {missing_fill_value} ile dolduruldu")
                    
                    elif missing_strategy == 'fill_mean':
                        # Sayısal sütunlar için ortalama ile doldur
                        numeric_cols = df_cleaned.select_dtypes(include=['number']).columns
                        for col in numeric_cols:
                            df_cleaned[col] = df_cleaned[col].fillna(df_cleaned[col].mean())
                        changes.append(f"Sayısal sütunlardaki eksik değerler ortalama ile dolduruldu")
                    
                    elif missing_strategy == 'fill_median':
                        # Sayısal sütunlar için medyan ile doldur
                        numeric_cols = df_cleaned.select_dtypes(include=['number']).columns
                        for col in numeric_cols:
                            df_cleaned[col] = df_cleaned[col].fillna(df_cleaned[col].median())
                        changes.append(f"Sayısal sütunlardaki eksik değerler medyan ile dolduruldu")
                    
                    elif missing_strategy == 'fill_mode':
                        # Kategorik sütunlar için mod ile doldur
                        for col in df_cleaned.columns:
                            df_cleaned[col] = df_cleaned[col].fillna(df_cleaned[col].mode()[0] if not df_cleaned[col].mode().empty else '')
                        changes.append(f"Eksik değerler mod ile dolduruldu")
                
                # Tekrarlanan satırları kaldır
                if cleaning_options.get('remove_duplicates', False):
                    duplicates_before = len(df_cleaned)
                    df_cleaned = df_cleaned.drop_duplicates()
                    duplicates_removed = duplicates_before - len(df_cleaned)
                    if duplicates_removed > 0:
                        changes.append(f"{duplicates_removed} tekrarlanan satır silindi")
                
                # Aykırı değerleri işle
                if cleaning_options.get('handle_outliers', False):
                    outlier_strategy = cleaning_options.get('outlier_strategy', 'remove')
                    outlier_threshold = cleaning_options.get('outlier_threshold', 3.0)
                    
                    # Sayısal sütunları seç
                    numeric_cols = df_cleaned.select_dtypes(include=['number']).columns
                    outliers_count = 0
                    
                    for col in numeric_cols:
                        # Z-score hesapla
                        z_scores = np.abs((df_cleaned[col] - df_cleaned[col].mean()) / df_cleaned[col].std())
                        outliers = z_scores > outlier_threshold
                        col_outliers = outliers.sum()
                        outliers_count += col_outliers
                        
                        if outlier_strategy == 'remove':
                            df_cleaned = df_cleaned[~outliers]
                        elif outlier_strategy == 'cap':
                            # Aykırı değerleri üst ve alt sınırlara kırp
                            q1 = df_cleaned[col].quantile(0.25)
                            q3 = df_cleaned[col].quantile(0.75)
                            iqr = q3 - q1
                            lower_bound = q1 - outlier_threshold * iqr
                            upper_bound = q3 + outlier_threshold * iqr
                            df_cleaned[col] = df_cleaned[col].clip(lower_bound, upper_bound)
                    
                    if outliers_count > 0:
                        if outlier_strategy == 'remove':
                            changes.append(f"{outliers_count} aykırı değer içeren satır silindi")
                        elif outlier_strategy == 'cap':
                            changes.append(f"{outliers_count} aykırı değer kırpıldı")
                
                # Veri tiplerini düzelt
                if cleaning_options.get('fix_data_types', False):
                    type_conversions = cleaning_options.get('type_conversions', {})
                    
                    for col, new_type in type_conversions.items():
                        if col in df_cleaned.columns:
                            try:
                                if new_type == 'numeric':
                                    df_cleaned[col] = pd.to_numeric(df_cleaned[col], errors='coerce')
                                    changes.append(f"{col} sütunu sayısal tipe dönüştürüldü")
                                elif new_type == 'datetime':
                                    df_cleaned[col] = pd.to_datetime(df_cleaned[col], errors='coerce')
                                    changes.append(f"{col} sütunu tarih/saat tipine dönüştürüldü")
                                elif new_type == 'string':
                                    df_cleaned[col] = df_cleaned[col].astype(str)
                                    changes.append(f"{col} sütunu metin tipine dönüştürüldü")
                                elif new_type == 'category':
                                    df_cleaned[col] = df_cleaned[col].astype('category')
                                    changes.append(f"{col} sütunu kategori tipine dönüştürüldü")
                            except Exception as e:
                                changes.append(f"{col} sütunu dönüştürülürken hata: {str(e)}")
                
                # Metin temizleme
                if cleaning_options.get('clean_text', False):
                    text_columns = cleaning_options.get('text_columns', [])
                    text_operations = cleaning_options.get('text_operations', [])
                    
                    for col in text_columns:
                        if col in df_cleaned.columns:
                            # Sütunun metin tipinde olduğundan emin ol
                            df_cleaned[col] = df_cleaned[col].astype(str)
                            
                            if 'lowercase' in text_operations:
                                df_cleaned[col] = df_cleaned[col].str.lower()
                                changes.append(f"{col} sütunu küçük harfe dönüştürüldü")
                            
                            if 'uppercase' in text_operations:
                                df_cleaned[col] = df_cleaned[col].str.upper()
                                changes.append(f"{col} sütunu büyük harfe dönüştürüldü")
                            
                            if 'strip' in text_operations:
                                df_cleaned[col] = df_cleaned[col].str.strip()
                                changes.append(f"{col} sütunundaki boşluklar temizlendi")
                            
                            if 'remove_special' in text_operations:
                                df_cleaned[col] = df_cleaned[col].str.replace(r'[^\w\s]', '', regex=True)
                                changes.append(f"{col} sütunundaki özel karakterler temizlendi")
                
                # Sütunları yeniden adlandır
                if cleaning_options.get('rename_columns', False):
                    column_mapping = cleaning_options.get('column_mapping', {})
                    df_cleaned = df_cleaned.rename(columns=column_mapping)
                    if column_mapping:
                        changes.append(f"{len(column_mapping)} sütun yeniden adlandırıldı")
                
                # Sütunları seç veya çıkar
                if cleaning_options.get('select_columns', False):
                    columns_to_keep = cleaning_options.get('columns_to_keep', [])
                    if columns_to_keep:
                        # Sadece belirtilen sütunları tut
                        valid_columns = [col for col in columns_to_keep if col in df_cleaned.columns]
                        df_cleaned = df_cleaned[valid_columns]
                        changes.append(f"Sadece {len(valid_columns)} sütun tutuldu")
                
                if cleaning_options.get('drop_columns', False):
                    columns_to_drop = cleaning_options.get('columns_to_drop', [])
                    if columns_to_drop:
                        # Belirtilen sütunları çıkar
                        valid_columns = [col for col in columns_to_drop if col in df_cleaned.columns]
                        df_cleaned = df_cleaned.drop(columns=valid_columns)
                        changes.append(f"{len(valid_columns)} sütun silindi")
                
                # Sonuçları kaydet
                cleaned_dfs[sheet_name] = df_cleaned
                
                # Temizleme sonuçlarını kaydet
                cleaning_results[sheet_name] = {
                    'original_rows': original_rows,
                    'original_columns': original_cols,
                    'cleaned_rows': len(df_cleaned),
                    'cleaned_columns': len(df_cleaned.columns),
                    'changes': changes
                }
            
            # Sonuçları Excel'e kaydet
            if output_file:
                with pd.ExcelWriter(output_file) as writer:
                    for sheet_name, df in cleaned_dfs.items():
                        df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            return True, "Excel dosyası başarıyla temizlendi.", cleaning_results, cleaned_dfs
        
        except Exception as e:
            return False, f"Hata: {str(e)}", None, None