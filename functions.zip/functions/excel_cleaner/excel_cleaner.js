document.addEventListener('DOMContentLoaded', function() {
    // Tab değiştirme işlevi
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Aktif tab'ı değiştir
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // İlgili içeriği göster
            tabContents.forEach(content => {
                content.classList.remove('active');
                if (content.id === tabId + '-tab') {
                    content.classList.add('active');
                }
            });
        });
    });
    
    // Dosya seçimi
    const selectFileBtn = document.getElementById('selectFileBtn');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    const filePath = document.getElementById('filePath');
    let selectedFile = null;
    
    selectFileBtn.addEventListener('click', function() {
        // Python'a dosya seçim isteği gönder
        eel.select_file()().then(function(result) {
            if (result && result.path) {
                selectedFile = result.path;
                fileNameDisplay.textContent = result.name || 'Dosya seçildi';
                filePath.textContent = result.path;
                
                // Sütunları yükle
                loadColumns(result.path);
                
                // Temizleme butonu durumunu kontrol et
                checkCleanButton();
            }
        });
    });
    
    // Çıktı dosyası seçimi
    const selectOutputBtn = document.getElementById('selectOutputBtn');
    const outputNameDisplay = document.getElementById('outputNameDisplay');
    const outputPath = document.getElementById('outputPath');
    let selectedOutputFile = null;
    
    selectOutputBtn.addEventListener('click', function() {
        // Python'a çıktı dosyası seçim isteği gönder
        eel.select_output_file()().then(function(result) {
            if (result && result.path) {
                selectedOutputFile = result.path;
                outputNameDisplay.textContent = result.name || 'Dosya seçildi';
                outputPath.textContent = result.path;
                
                // Temizleme butonu durumunu kontrol et
                checkCleanButton();
            }
        });
    });
    
    // Sütunları yükleme fonksiyonu
    function loadColumns(filePath) {
        const columnsList = document.getElementById('columnsList');
        
        // Python'dan sütunları al
        eel.get_excel_columns(filePath)().then(function(columns) {
            if (columns && columns.length > 0) {
                columnsList.innerHTML = '';
                
                const selectColumnsDiv = document.createElement('div');
                selectColumnsDiv.className = 'option-title';
                selectColumnsDiv.textContent = 'Sütunlar';
                columnsList.appendChild(selectColumnsDiv);
                
                columns.forEach(function(column) {
                    const columnItem = document.createElement('div');
                    columnItem.className = 'column-item';
                    
                    const checkbox = document.createElement('input');
                    checkbox.type = 'checkbox';
                    checkbox.id = 'column_' + column;
                    checkbox.value = column;
                    checkbox.className = 'column-checkbox';
                    
                    const label = document.createElement('label');
                    label.htmlFor = 'column_' + column;
                    label.textContent = column;
                    
                    columnItem.appendChild(checkbox);
                    columnItem.appendChild(label);
                    columnsList.appendChild(columnItem);
                });
            } else {
                columnsList.innerHTML = '<div class="option-title">Sütun bulunamadı veya dosya okunamadı</div>';
            }
        }).catch(function(error) {
            console.error('Sütunlar yüklenirken hata:', error);
            columnsList.innerHTML = '<div class="option-title">Sütunlar yüklenirken hata oluştu</div>';
        });
    }
    
    // Temizleme butonu durumunu kontrol et
    function checkCleanButton() {
        const cleanButton = document.getElementById('cleanButton');
        
        if (selectedFile && selectedOutputFile) {
            cleanButton.disabled = false;
        } else {
            cleanButton.disabled = true;
        }
    }
    
    // Temizleme işlemi
    const cleanButton = document.getElementById('cleanButton');
    const statusDiv = document.getElementById('status');
    const resultsDiv = document.getElementById('results');
    const resultsContent = document.getElementById('resultsContent');
    
    cleanButton.addEventListener('click', function() {
        if (!selectedFile || !selectedOutputFile) {
            showStatus('Lütfen giriş ve çıkış dosyalarını seçin', 'error');
            return;
        }
        
        // Temizleme seçeneklerini topla
        const options = getCleaningOptions();
        
        // Temizleme işlemini başlat
        showStatus('Temizleme işlemi başlatıldı...', 'info');
        cleanButton.disabled = true;
        
        // Python'a temizleme isteği gönder
        eel.clean_excel(selectedFile, options, selectedOutputFile)().then(function(result) {
            cleanButton.disabled = false;
            
            if (result.success) {
                showStatus('Temizleme işlemi başarıyla tamamlandı!', 'success');
                showResults(result);
            } else {
                showStatus('Temizleme işlemi sırasında hata: ' + result.message, 'error');
            }
        }).catch(function(error) {
            cleanButton.disabled = false;
            showStatus('Temizleme işlemi sırasında hata: ' + error, 'error');
        });
    });
    
    // Temizleme seçeneklerini toplama
    function getCleaningOptions() {
        const options = {};
        
        // Eksik değerler
        options.handle_missing = document.getElementById('handleMissing').checked;
        if (options.handle_missing) {
            const missingStrategy = document.querySelector('input[name="missingStrategy"]:checked').value;
            options.missing_strategy = missingStrategy;
            
            if (missingStrategy === 'fill_value') {
                const fillValue = document.getElementById('fillValue').value;
                // Sayı mı değil mi kontrol et
                if (!isNaN(fillValue)) {
                    options.missing_fill_value = parseFloat(fillValue);
                } else {
                    options.missing_fill_value = fillValue;
                }
            }
        }
        
        // Tekrarlanan satırlar
        options.remove_duplicates = document.getElementById('removeDuplicates').checked;
        
        // Aykırı değerler
        options.handle_outliers = document.getElementById('handleOutliers').checked;
        if (options.handle_outliers) {
            options.outlier_strategy = document.querySelector('input[name="outlierStrategy"]:checked').value;
            options.outlier_threshold = parseFloat(document.getElementById('outlierThreshold').value) || 3.0;
        }
        
        // Veri tipleri
        options.fix_data_types = document.getElementById('fixDataTypes').checked;
        
        // Metin temizleme
        options.clean_text = document.getElementById('cleanText').checked;
        if (options.clean_text) {
            options.text_operations = [];
            
            if (document.getElementById('textLowercase').checked) {
                options.text_operations.push('lowercase');
            }
            if (document.getElementById('textUppercase').checked) {
                options.text_operations.push('uppercase');
            }
            if (document.getElementById('textStrip').checked) {
                options.text_operations.push('strip');
            }
            if (document.getElementById('textRemoveSpecial').checked) {
                options.text_operations.push('remove_special');
            }
        }
        
        // Sütun işlemleri
        options.select_columns = document.getElementById('selectColumns').checked;
        options.drop_columns = document.getElementById('dropColumns').checked;
        
        if (options.select_columns || options.drop_columns) {
            const selectedColumns = [];
            document.querySelectorAll('.column-checkbox:checked').forEach(function(checkbox) {
                selectedColumns.push(checkbox.value);
            });
            options.columns = selectedColumns;
        }
        
        return options;
    }
    
    // Durum mesajı gösterme
    function showStatus(message, type) {
        statusDiv.textContent = message;
        statusDiv.className = 'status';
        statusDiv.classList.add(type);
        statusDiv.style.display = 'block';
    }
    
    // Sonuçları gösterme
    function showResults(result) {
        resultsDiv.style.display = 'block';
        
        let resultText = `${result.message}\n\nTemizleme Sonuçları:\n`;
        
        for (const sheetName in result.results) {
            const sheetResults = result.results[sheetName];
            
            resultText += `\nSayfa: ${sheetName}\n`;
            resultText += `Orijinal: ${sheetResults.original_rows} satır, ${sheetResults.original_columns} sütun\n`;
            resultText += `Temizlenmiş: ${sheetResults.cleaned_rows} satır, ${sheetResults.cleaned_columns} sütun\n`;
            
            if (sheetResults.changes && sheetResults.changes.length > 0) {
                resultText += "Yapılan değişiklikler:\n";
                sheetResults.changes.forEach(function(change) {
                    resultText += `- ${change}\n`;
                });
            }
        }
        
        resultsContent.textContent = resultText;
    }
});

// Python fonksiyonları
eel.expose(showMessage);
function showMessage(message, type) {
    const statusDiv = document.getElementById('status');
    statusDiv.textContent = message;
    statusDiv.className = 'status';
    statusDiv.classList.add(type || 'info');
    statusDiv.style.display = 'block';
}