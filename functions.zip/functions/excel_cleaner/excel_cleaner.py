import os
import sys
import json
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel,
                             QFileDialog, QListWidget, QHBoxLayout, QMessageBox,
                             QLineEdit, QFormLayout, QGroupBox, QApplication, QComboBox,
                             QCheckBox, QListWidgetItem, QTabWidget, QRadioButton, QButtonGroup)
from .excel_bridge import ExcelBridge
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class ExcelCleanerWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.input_file = ""
        self.output_file = ""
        self.cleaning_options = {}
        self.initUI()
        
    def initUI(self):
        # Ana pencere ayarları
        self.setWindowTitle('Excel Veri Temizleme')
        self.setMinimumSize(800, 600)
        
        # Ana widget ve layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Başlık
        title_label = QLabel('Excel Veri Temizleme')
        title_font = QFont('Arial', 18, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Dosya seçim bölümü
        file_group = QGroupBox("Dosya Seçimi")
        file_layout = QVBoxLayout()
        
        # Dosya seçim butonu
        self.select_file_button = QPushButton('Excel Dosyası Seç')
        self.select_file_button.clicked.connect(self.select_file)
        file_layout.addWidget(self.select_file_button)
        
        # Seçilen dosyayı göster
        self.file_path = QLineEdit()
        self.file_path.setReadOnly(True)
        self.file_path.setPlaceholderText("Dosya seçilmedi")
        file_layout.addWidget(self.file_path)
        
        file_group.setLayout(file_layout)
        main_layout.addWidget(file_group)
        
        # Temizleme seçenekleri için tab widget
        self.tabs = QTabWidget()
        
        # Eksik değerler sekmesi
        self.missing_tab = QWidget()
        missing_layout = QVBoxLayout(self.missing_tab)
        
        self.handle_missing = QCheckBox("Eksik Değerleri İşle")
        missing_layout.addWidget(self.handle_missing)
        
        missing_strategy_group = QGroupBox("Eksik Değer Stratejisi")
        missing_strategy_layout = QVBoxLayout()
        
        self.missing_strategy_remove_rows = QRadioButton("Eksik Değer İçeren Satırları Sil")
        self.missing_strategy_remove_cols = QRadioButton("Eksik Değer İçeren Sütunları Sil")
        self.missing_strategy_fill_value = QRadioButton("Sabit Değer ile Doldur")
        self.missing_strategy_fill_mean = QRadioButton("Ortalama ile Doldur (Sayısal)")
        self.missing_strategy_fill_median = QRadioButton("Medyan ile Doldur (Sayısal)")
        self.missing_strategy_fill_mode = QRadioButton("Mod ile Doldur (Kategorik)")
        
        self.missing_strategy_group = QButtonGroup()
        self.missing_strategy_group.addButton(self.missing_strategy_remove_rows)
        self.missing_strategy_group.addButton(self.missing_strategy_remove_cols)
        self.missing_strategy_group.addButton(self.missing_strategy_fill_value)
        self.missing_strategy_group.addButton(self.missing_strategy_fill_mean)
        self.missing_strategy_group.addButton(self.missing_strategy_fill_median)
        self.missing_strategy_group.addButton(self.missing_strategy_fill_mode)
        
        missing_strategy_layout.addWidget(self.missing_strategy_remove_rows)
        missing_strategy_layout.addWidget(self.missing_strategy_remove_cols)
        missing_strategy_layout.addWidget(self.missing_strategy_fill_value)
        missing_strategy_layout.addWidget(self.missing_strategy_fill_mean)
        missing_strategy_layout.addWidget(self.missing_strategy_fill_median)
        missing_strategy_layout.addWidget(self.missing_strategy_fill_mode)
        
        self.missing_strategy_remove_rows.setChecked(True)
        
        missing_strategy_group.setLayout(missing_strategy_layout)
        missing_layout.addWidget(missing_strategy_group)
        
        self.fill_value_layout = QFormLayout()
        self.fill_value_input = QLineEdit("0")
        self.fill_value_layout.addRow("Doldurma Değeri:", self.fill_value_input)
        missing_layout.addLayout(self.fill_value_layout)
        
        self.tabs.addTab(self.missing_tab, "Eksik Değerler")
        
        # Tekrarlanan satırlar sekmesi
        self.duplicates_tab = QWidget()
        duplicates_layout = QVBoxLayout(self.duplicates_tab)
        
        self.remove_duplicates = QCheckBox("Tekrarlanan Satırları Kaldır")
        duplicates_layout.addWidget(self.remove_duplicates)
        
        self.tabs.addTab(self.duplicates_tab, "Tekrarlanan Satırlar")
        
        # Aykırı değerler sekmesi
        self.outliers_tab = QWidget()
        outliers_layout = QVBoxLayout(self.outliers_tab)
        
        self.handle_outliers = QCheckBox("Aykırı Değerleri İşle")
        outliers_layout.addWidget(self.handle_outliers)
        
        outlier_strategy_group = QGroupBox("Aykırı Değer Stratejisi")
        outlier_strategy_layout = QVBoxLayout()
        
        self.outlier_strategy_remove = QRadioButton("Aykırı Değer İçeren Satırları Sil")
        self.outlier_strategy_cap = QRadioButton("Aykırı Değerleri Kırp (Min/Max)")
        
        self.outlier_strategy_group = QButtonGroup()
        self.outlier_strategy_group.addButton(self.outlier_strategy_remove)
        self.outlier_strategy_group.addButton(self.outlier_strategy_cap)
        
        outlier_strategy_layout.addWidget(self.outlier_strategy_remove)
        outlier_strategy_layout.addWidget(self.outlier_strategy_cap)
        
        self.outlier_strategy_remove.setChecked(True)
        
        outlier_strategy_group.setLayout(outlier_strategy_layout)
        outliers_layout.addWidget(outlier_strategy_group)
        
        self.threshold_layout = QFormLayout()
        self.threshold_input = QLineEdit("3.0")
        self.threshold_layout.addRow("Eşik Değeri (Z-score):", self.threshold_input)
        outliers_layout.addLayout(self.threshold_layout)
        
        self.tabs.addTab(self.outliers_tab, "Aykırı Değerler")
        
        # Veri tipleri sekmesi
        self.datatypes_tab = QWidget()
        datatypes_layout = QVBoxLayout(self.datatypes_tab)
        
        self.fix_data_types = QCheckBox("Veri Tiplerini Düzelt")
        datatypes_layout.addWidget(self.fix_data_types)
        
        self.tabs.addTab(self.datatypes_tab, "Veri Tipleri")
        
        # Metin temizleme sekmesi
        self.text_tab = QWidget()
        text_layout = QVBoxLayout(self.text_tab)
        
        self.clean_text = QCheckBox("Metin Temizleme")
        text_layout.addWidget(self.clean_text)
        
        text_operations_group = QGroupBox("Metin İşlemleri")
        text_operations_layout = QVBoxLayout()
        
        self.text_lowercase = QCheckBox("Küçük Harfe Dönüştür")
        self.text_uppercase = QCheckBox("Büyük Harfe Dönüştür")
        self.text_strip = QCheckBox("Boşlukları Temizle")
        self.text_remove_special = QCheckBox("Özel Karakterleri Kaldır")
        
        text_operations_layout.addWidget(self.text_lowercase)
        text_operations_layout.addWidget(self.text_uppercase)
        text_operations_layout.addWidget(self.text_strip)
        text_operations_layout.addWidget(self.text_remove_special)
        
        text_operations_group.setLayout(text_operations_layout)
        text_layout.addWidget(text_operations_group)
        
        self.tabs.addTab(self.text_tab, "Metin Temizleme")
        
        # Sütun işlemleri sekmesi
        self.columns_tab = QWidget()
        columns_layout = QVBoxLayout(self.columns_tab)
        
        self.select_columns = QCheckBox("Belirli Sütunları Tut")
        self.drop_columns = QCheckBox("Belirli Sütunları Sil")
        
        columns_layout.addWidget(self.select_columns)
        columns_layout.addWidget(self.drop_columns)
        
        self.tabs.addTab(self.columns_tab, "Sütun İşlemleri")
        
        main_layout.addWidget(self.tabs)
        
        # Çıktı dosyası seçim bölümü
        output_group = QGroupBox("Çıktı Dosyası")
        output_layout = QFormLayout()
        
        self.output_path = QLineEdit()
        self.output_path.setReadOnly(True)
        self.output_path.setPlaceholderText("Çıktı dosyası seçilmedi")
        
        output_button_layout = QHBoxLayout()
        self.select_output_button = QPushButton('Çıktı Dosyası Seç')
        self.select_output_button.clicked.connect(self.select_output)
        output_button_layout.addWidget(self.output_path)
        output_button_layout.addWidget(self.select_output_button)
        
        output_layout.addRow(output_button_layout)
        output_group.setLayout(output_layout)
        main_layout.addWidget(output_group)
        
        # Temizleme butonu
        self.clean_button = QPushButton('Veriyi Temizle')
        self.clean_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
            }
        """)
        self.clean_button.clicked.connect(self.clean_data)
        self.clean_button.setEnabled(False)
        main_layout.addWidget(self.clean_button)
    
    def select_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Excel Dosyası Seç", "", "Excel Dosyaları (*.xlsx *.xls)")
        
        if file_path:
            self.input_file = file_path
            self.file_path.setText(file_path)
            self.check_clean_button()
    
    def select_output(self):
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Çıktı Dosyasını Seç", "", "Excel Dosyaları (*.xlsx)")
        
        if file_path:
            # Dosya uzantısını kontrol et ve gerekirse ekle
            if not file_path.endswith('.xlsx'):
                file_path += '.xlsx'
            
            self.output_file = file_path
            self.output_path.setText(file_path)
            self.check_clean_button()
    
    def check_clean_button(self):
        # Temizleme butonu için gerekli koşulları kontrol et
        if self.input_file and self.output_file:
            self.clean_button.setEnabled(True)
        else:
            self.clean_button.setEnabled(False)
    
    def get_cleaning_options(self):
        options = {}
        
        # Eksik değerler
        options['handle_missing'] = self.handle_missing.isChecked()
        if options['handle_missing']:
            if self.missing_strategy_remove_rows.isChecked():
                options['missing_strategy'] = 'remove_rows'
            elif self.missing_strategy_remove_cols.isChecked():
                options['missing_strategy'] = 'remove_columns'
            elif self.missing_strategy_fill_value.isChecked():
                options['missing_strategy'] = 'fill_value'
                try:
                    options['missing_fill_value'] = float(self.fill_value_input.text())
                except ValueError:
                    options['missing_fill_value'] = self.fill_value_input.text()
            elif self.missing_strategy_fill_mean.isChecked():
                options['missing_strategy'] = 'fill_mean'
            elif self.missing_strategy_fill_median.isChecked():
                options['missing_strategy'] = 'fill_median'
            elif self.missing_strategy_fill_mode.isChecked():
                options['missing_strategy'] = 'fill_mode'
        
        # Tekrarlanan satırlar
        options['remove_duplicates'] = self.remove_duplicates.isChecked()
        
        # Aykırı değerler
        options['handle_outliers'] = self.handle_outliers.isChecked()
        if options['handle_outliers']:
            if self.outlier_strategy_remove.isChecked():
                options['outlier_strategy'] = 'remove'
            elif self.outlier_strategy_cap.isChecked():
                options['outlier_strategy'] = 'cap'
            
            try:
                options['outlier_threshold'] = float(self.threshold_input.text())
            except ValueError:
                options['outlier_threshold'] = 3.0
        
        # Veri tipleri
        options['fix_data_types'] = self.fix_data_types.isChecked()
        
        # Metin temizleme
        options['clean_text'] = self.clean_text.isChecked()
        if options['clean_text']:
            text_operations = []
            if self.text_lowercase.isChecked():
                text_operations.append('lowercase')
            if self.text_uppercase.isChecked():
                text_operations.append('uppercase')
            if self.text_strip.isChecked():
                text_operations.append('strip')
            if self.text_remove_special.isChecked():
                text_operations.append('remove_special')
            
            options['text_operations'] = text_operations
        
        # Sütun işlemleri
        options['select_columns'] = self.select_columns.isChecked()
        options['drop_columns'] = self.drop_columns.isChecked()
        
        return options
    
    def clean_data(self):
        # Temizleme seçeneklerini al
        cleaning_options = self.get_cleaning_options()
        
        try:
            # Temizleme işlemini gerçekleştir
            success, message, results, _ = ExcelBridge.clean_excel(
                self.input_file, cleaning_options, self.output_file)
            
            if success:
                # Sonuçları göster
                result_message = f"{message}\n\nTemizleme Sonuçları:\n"
                
                for sheet_name, sheet_results in results.items():
                    result_message += f"\nSayfa: {sheet_name}\n"
                    result_message += f"Orijinal: {sheet_results['original_rows']} satır, {sheet_results['original_columns']} sütun\n"
                    result_message += f"Temizlenmiş: {sheet_results['cleaned_rows']} satır, {sheet_results['cleaned_columns']} sütun\n"
                    
                    if sheet_results['changes']:
                        result_message += "Yapılan değişiklikler:\n"
                        for change in sheet_results['changes']:
                            result_message += f"- {change}\n"
                
                QMessageBox.information(self, "Başarılı", result_message)
            else:
                QMessageBox.critical(self, "Hata", message)
        
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Temizleme sırasında hata oluştu: {str(e)}")

# Test için
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ExcelCleanerWindow()
    window.show()
    sys.exit(app.exec_())