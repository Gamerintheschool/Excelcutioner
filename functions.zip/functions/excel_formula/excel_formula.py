import os
import sys
import eel
from PyQt5.QtWidgets import QMainWindow, QVBoxLayout, QLabel, QWidget
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtWebEngineWidgets import QWebEngineView

class ExcelFormulaWindow(QMainWindow):
    """Excel formül oluşturucu ve yönetici penceresi"""
    
    def __init__(self):
        super().__init__()
        
        # Pencere başlığı ve boyutu
        self.setWindowTitle("Excel Formül Oluşturucu")
        self.resize(1200, 800)
        
        # Ana widget ve layout
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)
        
        # Başlık
        self.title_label = QLabel("Excel Formül Oluşturucu ve Yönetici")
        self.title_label.setAlignment(Qt.AlignCenter)
        self.title_label.setStyleSheet("font-size: 18pt; font-weight: bold; margin: 10px;")
        self.layout.addWidget(self.title_label)
        
        # Alt başlık
        self.subtitle_label = QLabel("Excel formülleri oluşturun, test edin ve yönetin")
        self.subtitle_label.setAlignment(Qt.AlignCenter)
        self.subtitle_label.setStyleSheet("font-size: 12pt; margin-bottom: 20px;")
        self.layout.addWidget(self.subtitle_label)
        
        # Web arayüzü için QWebEngineView
        self.web_view = QWebEngineView()
        self.layout.addWidget(self.web_view)
        
        # Eel'i başlat
        self.start_eel()
        
    def start_eel(self):
        """Eel web sunucusunu başlat"""
        # Mevcut dizini al
        current_dir = os.path.dirname(os.path.abspath(__file__))
        web_dir = os.path.join(current_dir, 'web')
        
        # Web dizini yoksa oluştur
        if not os.path.exists(web_dir):
            os.makedirs(web_dir)
        
        # Eel'i başlat
        eel.init(web_dir)
        
        # Excel köprüsünü içe aktar ve başlat
        from .excel_bridge import init_bridge
        init_bridge()
        
        # Eel'i başlat (yeni bir pencere açmadan)
        eel_kwargs = {
            'mode': 'custom',
            'port': 8001,
            'block': False
        }
        
        # Eel'i başlat
        eel.start('excel_formula.html', **eel_kwargs)
        
        # Web görünümünü ayarla
        self.web_view.load(Qt.QUrl("http://localhost:8001/excel_formula.html"))
    
    def closeEvent(self, event):
        """Pencere kapatıldığında Eel'i durdur"""
        try:
            eel.shutdown()
        except:
            pass
        event.accept()