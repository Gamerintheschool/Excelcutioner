// Excel Formül Oluşturucu JavaScript

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', function() {
    // Dosya seçme butonu
    document.getElementById('selectFileBtn').addEventListener('click', selectExcelFile);
    
    // Formül kategorileri yükle
    loadFormulaCategories();
    
    // Formül şablonları yükle
    loadFormulaTemplates();
    
    // Formül açıklamaları yükle
    loadFormulaDescriptions();
    
    // Kaydedilmiş formülleri yükle
    loadSavedFormulas();
    
    // Formül kaydetme butonu
    document.getElementById('saveFormulaBtn').addEventListener('click', saveFormula);
    
    // Formül temizleme butonu
    document.getElementById('clearFormulaBtn').addEventListener('click', clearFormulaForm);
    
    // Test değeri ekleme butonu
    document.getElementById('addTestValueBtn').addEventListener('click', addTestValue);
    
    // İlk test değeri satırını ekle
    addTestValue();
    
    // Test çalıştırma butonu
    document.getElementById('runTestBtn').addEventListener('click', runFormulaTest);
    
    // Formül uygulama butonu
    document.getElementById('applyFormulaBtn').addEventListener('click', applyFormula);
    
    // Formülleri kaydetme butonu
    document.getElementById('saveFormulasBtn').addEventListener('click', saveFormulasToFile);
    
    // Formülleri yükleme butonu
    document.getElementById('loadFormulasBtn').addEventListener('click', loadFormulasFromFile);
    
    // Formül yardımcısı butonları
    document.querySelectorAll('.btn-formula').forEach(button => {
        button.addEventListener('click', function() {
            showFormulaHelp(this.textContent);
        });
    });
    
    // Formül arama
    document.getElementById('helperSearch').addEventListener('input', searchFormulas);
});

// Excel dosyası seç
async function selectExcelFile() {
    const result = await eel.select_file()();
    
    if (result.success) {
        // Excel dosyasını yükle
        const excelData = await eel.load_excel(result.file_path)();
        
        if (excelData.success) {
            // Dosya bilgilerini göster
            document.getElementById('fileInfo').classList.remove('d-none');
            document.getElementById('fileName').textContent = result.file_path.split(/[\\/]/).pop();
            document.getElementById('sheetCount').textContent = excelData.sheet_names.length;
            document.getElementById('activeSheet').textContent = excelData.active_sheet;
            
            // Sayfa seçici
            const sheetSelector = document.getElementById('sheetSelector');
            sheetSelector.classList.remove('d-none');
            
            const sheetSelect = document.getElementById('sheetSelect');
            sheetSelect.innerHTML = '';
            
            excelData.sheet_names.forEach(sheet => {
                const option = document.createElement('option');
                option.value = sheet;
                option.textContent = sheet;
                if (sheet === excelData.active_sheet) {
                    option.selected = true;
                }
                sheetSelect.appendChild(option);
            });
            
            // Uygulama sayfası seçici
            const applySheet = document.getElementById('applySheet');
            applySheet.innerHTML = '';
            
            excelData.sheet_names.forEach(sheet => {
                const option = document.createElement('option');
                option.value = sheet;
                option.textContent = sheet;
                if (sheet === excelData.active_sheet) {
                    option.selected = true;
                }
                applySheet.appendChild(option);
            });
            
            // Sayfa değiştiğinde veri yükle
            sheetSelect.addEventListener('change', function() {
                loadSheetData(this.value);
            });
            
            // İlk sayfanın verilerini yükle
            loadSheetData(excelData.active_sheet);
            
            // Formül uygulama formunu göster
            document.getElementById('applyFormulaForm').classList.remove('d-none');
            document.querySelector('#apply .alert').classList.add('d-none');
            
            // Formül kaydetme butonunu etkinleştir
            document.getElementById('saveFormulasBtn').disabled = false;
        } else {
            alert('Excel dosyası yüklenirken hata oluştu: ' + excelData.error);
        }
    }
}

// Sayfa verilerini yükle
async function loadSheetData(sheetName) {
    const sheetData = await eel.get_sheet_data(sheetName)();
    
    if (sheetData.success) {
        // Veri önizleme
        const dataPreview = document.getElementById('dataPreview');
        dataPreview.innerHTML = '';
        
        if (sheetData.data && sheetData.data.length > 0) {
            const table = document.createElement('table');
            table.className = 'table table-sm table-bordered preview-table';
            
            // Tablo başlığı
            const thead = document.createElement('thead');
            const headerRow = document.createElement('tr');
            
            sheetData.headers.forEach(header => {
                const th = document.createElement('th');
                th.textContent = header;
                headerRow.appendChild(th);
            });
            
            thead.appendChild(headerRow);
            table.appendChild(thead);
            
            // Tablo gövdesi (ilk 5 satır)
            const tbody = document.createElement('tbody');
            
            for (let i = 0; i < Math.min(5, sheetData.data.length); i++) {
                const row = sheetData.data[i];
                const tr = document.createElement('tr');
                
                sheetData.headers.forEach(header => {
                    const td = document.createElement('td');
                    td.textContent = row[header] !== null && row[header] !== undefined ? row[header] : '';
                    tr.appendChild(td);
                });
                
                tbody.appendChild(tr);
            }
            
            table.appendChild(tbody);
            dataPreview.appendChild(table);
            
            // Daha fazla satır varsa bilgi ver
            if (sheetData.data.length > 5) {
                const moreInfo = document.createElement('p');
                moreInfo.className = 'text-muted text-center small mt-2';
                moreInfo.textContent = `Toplam ${sheetData.row_count} satırdan ilk 5'i gösteriliyor.`;
                dataPreview.appendChild(moreInfo);
            }
        } else {
            dataPreview.innerHTML = '<p class="text-muted text-center">Bu sayfada veri bulunamadı</p>';
        }
    } else {
        alert('Sayfa verileri yüklenirken hata oluştu: ' + sheetData.error);
    }
}

// Formül kategorilerini yükle
async function loadFormulaCategories() {
    const result = await eel.get_formula_categories()();
    
    if (result.success) {
        const categoriesContainer = document.getElementById('formulaCategories');
        categoriesContainer.innerHTML = '';
        
        for (const [category, formulas] of Object.entries(result.categories)) {
            const categoryDiv = document.createElement('div');
            categoryDiv.className = 'formula-category';
            
            // Kategori başlığı
            const categoryTitle = document.createElement('h5');
            categoryTitle.textContent = getCategoryName(category);
            categoryDiv.appendChild(categoryTitle);
            
            // Formüller
            const formulasDiv = document.createElement('div');
            formulasDiv.className = 'd-flex flex-wrap';
            
            formulas.forEach(formula => {
                const formulaBtn = document.createElement('button');
                formulaBtn.className = 'btn btn-sm btn-formula';
                formulaBtn.textContent = formula;
                formulaBtn.addEventListener('click', function() {
                    insertFormulaTemplate(formula);
                });
                formulasDiv.appendChild(formulaBtn);
            });
            
            categoryDiv.appendChild(formulasDiv);
            categoriesContainer.appendChild(categoryDiv);
        }
    } else {
        console.error('Formül kategorileri yüklenirken hata oluştu:', result.error);
    }
}

// Formül şablonlarını yükle
async function loadFormulaTemplates() {
    const result = await eel.get_formula_templates()();
    
    if (result.success) {
        window.formulaTemplates = result.templates;
    } else {
        console.error('Formül şablonları yüklenirken hata oluştu:', result.error);
    }
}

// Formül açıklamalarını yükle
async function loadFormulaDescriptions() {
    const result = await eel.get_formula_descriptions()();
    
    if (result.success) {
        window.formulaDescriptions = result.descriptions;
    } else {
        console.error('Formül açıklamaları yüklenirken hata oluştu:', result.error);
    }
}

// Kaydedilmiş formülleri yükle
async function loadSavedFormulas() {
    const result = await eel.get_saved_formulas()();
    
    if (result.success) {
        displaySavedFormulas(result.formulas);
    } else {
        console.error('Kaydedilmiş formüller yüklenirken hata oluştu:', result.error);
    }
}

// Kaydedilmiş formülleri göster
function displaySavedFormulas(formulas) {
    const savedFormulasContainer = document.getElementById('savedFormulas');
    savedFormulasContainer.innerHTML = '';
    
    if (formulas.length === 0) {
        savedFormulasContainer.innerHTML = '<p class="text-muted text-center">Henüz kaydedilmiş formül yok</p>';
        return;
    }
    
    // Formülleri kategorilere göre grupla
    const categorizedFormulas = {};
    
    formulas.forEach(formula => {
        if (!categorizedFormulas[formula.category]) {
            categorizedFormulas[formula.category] = [];
        }
        categorizedFormulas[formula.category].push(formula);
    });
    
    // Her kategori için formülleri göster
    for (const [category, categoryFormulas] of Object.entries(categorizedFormulas)) {
        const categoryDiv = document.createElement('div');
        categoryDiv.className = 'mb-3';
        
        const categoryTitle = document.createElement('h6');
        categoryTitle.textContent = getCategoryName(category);
        categoryDiv.appendChild(categoryTitle);
        
        categoryFormulas.forEach(formula => {
            const formulaItem = document.createElement('div');
            formulaItem.className = 'formula-item';
            formulaItem.dataset.formulaId = formula.id;
            
            const formulaName = document.createElement('div');
            formulaName.className = 'fw-bold';
            formulaName.textContent = formula.name;
            formulaItem.appendChild(formulaName);
            
            const formulaCode = document.createElement('div');
            formulaCode.className = 'small text-muted';
            formulaCode.textContent = formula.formula;
            formulaItem.appendChild(formulaCode);
            
            const formulaActions = document.createElement('div');
            formulaActions.className = 'mt-2 d-flex justify-content-between';
            
            // Formül işlemleri
            const actionButtons = document.createElement('div');
            
            // Düzenle butonu
            const editBtn = document.createElement('button');
            editBtn.className = 'btn btn-sm btn-outline-primary me-1';
            editBtn.innerHTML = '<i class="bi bi-pencil"></i>';
            editBtn.addEventListener('click', () => editFormula(formula.id));
            actionButtons.appendChild(editBtn);
            
            // Test et butonu
            const testBtn = document.createElement('button');
            testBtn.className = 'btn btn-sm btn-outline-success me-1';
            testBtn.innerHTML = '<i class="bi bi-check2-circle"></i>';
            testBtn.addEventListener('click', () => testFormula(formula.id));
            actionButtons.appendChild(testBtn);
            
            // Uygula butonu
            const applyBtn = document.createElement('button');
            applyBtn.className = 'btn btn-sm btn-outline-info me-1';
            applyBtn.innerHTML = '<i class="bi bi-arrow-right-circle"></i>';
            applyBtn.addEventListener('click', () => prepareApplyFormula(formula.id));
            actionButtons.appendChild(applyBtn);
            
            // Sil butonu
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'btn btn-sm btn-outline-danger';
            deleteBtn.innerHTML = '<i class="bi bi-trash"></i>';
            deleteBtn.addEventListener('click', () => deleteFormula(formula.id));
            actionButtons.appendChild(deleteBtn);
            
            formulaActions.appendChild(actionButtons);
            
            // Oluşturulma tarihi
            const createdAt = document.createElement('small');
            createdAt.className = 'text-muted';
            createdAt.textContent = formula.created_at;
            formulaActions.appendChild(createdAt);
            
            formulaItem.appendChild(formulaActions);
            categoryDiv.appendChild(formulaItem);
        });
        
        savedFormulasContainer.appendChild(categoryDiv);
    }
}

// Formül şablonu ekle
function insertFormulaTemplate(formulaName) {
    if (window.formulaTemplates && window.formulaTemplates[formulaName]) {
        // Aktif sekmeye göre hedef belirle
        let targetElement;
        
        if (document.getElementById('create-tab').classList.contains('active')) {
            targetElement = document.getElementById('formulaEditor');
        } else if (document.getElementById('test-tab').classList.contains('active')) {
            targetElement = document.getElementById('testFormula');
        } else if (document.getElementById('apply-tab').classList.contains('active')) {
            targetElement = document.getElementById('applyFormula');
        }
        
        if (targetElement) {
            // = işaretini kaldır
            const template = window.formulaTemplates[formulaName].replace(/^=/, '');
            targetElement.value = template;
            targetElement.focus();
        }
        
        // Formül yardımcısında göster
        showFormulaHelp(formulaName);
    }
}

// Formül yardımcısını göster
function showFormulaHelp(formulaName) {
    const helperDetail = document.getElementById('formulaHelperDetail');
    helperDetail.classList.remove('d-none');
    
    document.getElementById('helperFormulaName').textContent = formulaName;
    
    if (window.formulaDescriptions && window.formulaDescriptions[formulaName]) {
        document.getElementById('helperFormulaDesc').textContent = window.formulaDescriptions[formulaName];
    } else {
        document.getElementById('helperFormulaDesc').textContent = 'Bu formül için açıklama bulunamadı.';
    }
    
    if (window.formulaTemplates && window.formulaTemplates[formulaName]) {
        document.getElementById('helperFormulaSyntax').textContent = window.formulaTemplates[formulaName];
    } else {
        document.getElementById('helperFormulaSyntax').textContent = `=${formulaName}()`;
    }
}

// Formül ara
function searchFormulas() {
    const searchTerm = document.getElementById('helperSearch').value.trim().toUpperCase();
    const helperResults = document.getElementById('helperResults');
    
    if (searchTerm === '') {
        // Varsayılan formülleri göster
        helperResults.innerHTML = `
            <p class="text-muted">Yaygın formüller:</p>
            <div class="d-flex flex-wrap">
                <button class="btn btn-sm btn-formula">TOPLA</button>
                <button class="btn btn-sm btn-formula">ORTALAMA</button>
                <button class="btn btn-sm btn-formula">MIN</button>
                <button class="btn btn-sm btn-formula">MAKS</button>
                <button class="btn btn-sm btn-formula">EĞER</button>
                <button class="btn btn-sm btn-formula">DÜŞEYARA</button>
                <button class="btn btn-sm btn-formula">BİRLEŞTİR</button>
            </div>
        `;
    } else {
        // Arama sonuçlarını göster
        helperResults.innerHTML = `<p class="text-muted">"${searchTerm}" için sonuçlar:</p>`;
        
        const resultsDiv = document.createElement('div');
        resultsDiv.className = 'd-flex flex-wrap';
        
        let foundCount = 0;
        
        // Tüm kategorilerdeki formülleri ara
        if (window.formulaCategories) {
            for (const formulas of Object.values(window.formulaCategories)) {
                formulas.forEach(formula => {
                    if (formula.includes(searchTerm)) {
                        const formulaBtn = document.createElement('button');
                        formulaBtn.className = 'btn btn-sm btn-formula';
                        formulaBtn.textContent = formula;
                        formulaBtn.addEventListener('click', function() {
                            insertFormulaTemplate(formula);
                        });
                        resultsDiv.appendChild(formulaBtn);
                        foundCount++;
                    }
                });
            }
        }
        
        if (foundCount === 0) {
            resultsDiv.innerHTML = '<p class="text-muted">Sonuç bulunamadı</p>';
        }
        
        helperResults.appendChild(resultsDiv);
    }
    
    // Formül butonlarına olay dinleyicileri ekle
    document.querySelectorAll('.btn-formula').forEach(button => {
        button.addEventListener('click', function() {
            showFormulaHelp(this.textContent);
        });
    });
}

// Formül kaydet
async function saveFormula() {
    const name = document.getElementById('formulaName').value.trim();
    const category = document.getElementById('formulaCategory').value;
    const formula = '=' + document.getElementById('formulaEditor').value.trim();
    const description = document.getElementById('formulaDescription').value.trim();
    const example = document.getElementById('formulaExample').value.trim();
    
    if (!name || !category || !formula || !description) {
        alert('Lütfen tüm gerekli alanları doldurun.');
        return;
    }
    
    const result = await eel.create_formula(name, formula, description, category, example)();
    
    if (result.success) {
        alert('Formül başarıyla kaydedildi.');
        clearFormulaForm();
        loadSavedFormulas();
    } else {
        alert('Formül kaydedilirken hata oluştu: ' + result.error);
    }
}

// Formül formunu temizle
function clearFormulaForm() {
    document.getElementById('formulaName').value = '';
    document.getElementById('formulaCategory').selectedIndex = 0;
    document.getElementById('formulaEditor').value = '';
    document.getElementById('formulaDescription').value = '';
    document.getElementById('formulaExample').value = '';
}

// Test değeri ekle
function addTestValue() {
    const testValues = document.getElementById('testValues');
    
    const valueGroup = document.createElement('div');
    valueGroup.className = 'input-group mb-2';
    
    valueGroup.innerHTML = `
        <span class="input-group-text">Değişken</span>
        <input type="text" class="form-control test-var" placeholder="Örn: A1">
        <span class="input-group-text">=</span>
        <input type="text" class="form-control test-val" placeholder="Değer">
        <button class="btn btn-outline-danger remove-test-value" type="button">
            <i class="bi bi-dash"></i>
        </button>
    `;
    
    testValues.appendChild(valueGroup);
    
    // Değer silme butonuna olay dinleyicisi ekle
    valueGroup.querySelector('.remove-test-value').addEventListener('click', function() {
        testValues.removeChild(valueGroup);
    });
}

// Formül testi çalıştır
async function runFormulaTest() {
    const formula = '=' + document.getElementById('testFormula').value.trim();
    
    if (!formula || formula === '=') {
        alert('Lütfen test edilecek bir formül girin.');
        return;
    }
    
    // Test değerlerini topla
    const testValues = {};
    const testVars = document.querySelectorAll('.test-var');
    const testVals = document.querySelectorAll('.test-val');
    
    for (let i = 0; i < testVars.length; i++) {
        const varName = testVars[i].value.trim();
        const varValue = testVals[i].value.trim();
        
        if (varName && varValue) {
            testValues[varName] = varValue;
        }
    }
    
    // Test sonuç alanını göster
    const testResult = document.getElementById('testResult');
    testResult.classList.remove('d-none');
    
    const testResultContent = document.getElementById('testResultContent');
    testResultContent.innerHTML = '<div class="spinner-border spinner-border-sm text-primary" role="status"></div> Test çalıştırılıyor...';
    
    // Testi çalıştır
    const result = await eel.test_formula(formula, testValues)();
    
    if (result.success) {
        testResultContent.className = 'formula-result';
        testResultContent.innerHTML = `
            <strong>Sonuç:</strong> ${result.result !== null && result.result !== undefined ? result.result : 'Boş'}
        `;
    } else {
        testResultContent.className = 'formula-error';
        testResultContent.innerHTML = `
            <strong>Hata:</strong> ${result.error}
        `;
    }
}

// Formül düzenle
function editFormula(formulaId) {
    alert('Formül düzenleme özelliği henüz uygulanmadı.');
}

// Formül test et
function testFormula(formulaId) {
    // Test sekmesine geç
    document.getElementById('test-tab').click();
    
    // Formülü bul
    const formulaElement = document.querySelector(`[data-formula-id="${formulaId}"]`);
    if (formulaElement) {
        const formulaText = formulaElement.querySelector('.text-muted').textContent;
        document.getElementById('testFormula').value = formulaText.replace(/^=/, '');
    }
}

// Formül uygulamaya hazırla
function prepareApplyFormula(formulaId) {
    // Uygula sekmesine geç
    document.getElementById('apply-tab').click();
    
    // Formülü bul
    const formulaElement = document.querySelector(`[data-formula-id="${formulaId}"]`);
    if (formulaElement) {
        const formulaText = formulaElement.querySelector('.text-muted').textContent;
        document.getElementById('applyFormula').value = formulaText.replace(/^=/, '');
    }
}

// Formül sil
async function deleteFormula(formulaId) {
    if (confirm('Bu formülü silmek istediğinizden emin misiniz?')) {
        const result = await eel.delete_formula(formulaId)();
        
        if (result.success) {
            loadSavedFormulas();
        } else {
            alert('Formül silinirken hata oluştu: ' + result.error);
        }
    }
}

// Formül uygula
async function applyFormula() {
    const sheetName = document.getElementById('applySheet').value;
    const cellRange = document.getElementById('applyCellRange').value.trim();
    const formula = '=' + document.getElementById('applyFormula').value.trim();
    
    if (!sheetName || !cellRange || !formula || formula === '=') {
        alert('Lütfen tüm gerekli alanları doldurun.');
        return;
    }
    
    const result = await eel.apply_formula(sheetName, cellRange, formula)();
    
    if (result.success) {
        alert('Formül başarıyla uygulandı.');
        loadSheetData(sheetName);
    } else {
        alert('Formül uygulanırken hata oluştu: ' + result.error);
    }
}

// Formülleri dosyaya kaydet
async function saveFormulasToFile() {
    const result = await eel.select_save_file('excel_formulleri.json')();
    
    if (result.success) {
        const saveResult = await eel.save_formulas_to_file(result.file_path)();
        
        if (saveResult.success) {
            alert('Formüller başarıyla kaydedildi.');
        } else {
            alert('Formüller kaydedilirken hata oluştu: ' + saveResult.error);
        }
    }
}

// Formülleri dosyadan yükle
async function loadFormulasFromFile() {
    const result = await eel.select_file()();
    
    if (result.success) {
        const loadResult = await eel.load_formulas_from_file(result.file_path)();
        
        if (loadResult.success) {
            alert('Formüller başarıyla yüklendi.');
            displaySavedFormulas(loadResult.formulas);
        } else {
            alert('Formüller yüklenirken hata oluştu: ' + loadResult.error);
        }
    }
}

// Kategori adını al
function getCategoryName(category) {
    const categoryNames = {
        'matematik': 'Matematik',
        'metin': 'Metin',
        'mantıksal': 'Mantıksal',
        'arama': 'Arama ve Başvuru',
        'tarih': 'Tarih ve Saat',
        'istatistik': 'İstatistik',
        'finansal': 'Finansal',
        'özel': 'Özel'
    };
    
    return categoryNames[category] || category;
}