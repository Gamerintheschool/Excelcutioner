import os
import sys
import json
import eel
import pandas as pd
import numpy as np
import tkinter as tk
from tkinter import filedialog
from openpyxl import load_workbook, Workbook
from openpyxl.utils.exceptions import InvalidFileException
from datetime import datetime

# Excel köprüsü sınıfı
class ExcelBridge:
    """Excel formül oluşturucu ve yönetici köprüsü"""
    
    def __init__(self):
        """Excel köprüsünü başlat"""
        self.excel_file = None
        self.workbook = None
        self.sheet_names = []
        self.active_sheet = None
        self.formulas = {}
        self.formula_categories = {
            "matematik": ["TOPLA", "ORTALAMA", "MIN", "MAKS", "ÇARPIM", "BÖLÜM", "YUVARLA", "TAMSAYI", "KAREKÖK"],
            "metin": ["BİRLEŞTİR", "SOL", "SAĞ", "ORTA", "UZUNLUK", "BÜYÜKHARF", "KÜÇÜKHARF", "KIRP"],
            "mantıksal": ["EĞER", "VE", "VEYA", "DEĞİL", "DOĞRUYSA", "YANLIŞSA"],
            "arama": ["DÜŞEYARA", "YATAYARA", "İNDİS", "KAÇINCI"],
            "tarih": ["BUGÜN", "ŞİMDİ", "YIL", "AY", "GÜN", "HAFTANINGÜNÜ"],
            "istatistik": ["STANDART.SAPMA", "VAR", "MEDYAN", "MOD", "BÜYÜK", "KÜÇÜK"],
            "finansal": ["NBD", "İÇ_VERİM_ORANI", "ÖDEME", "DEVRESEL_ÖDEME", "AMORTISMAN"]
        }
        self.formula_templates = {
            "TOPLA": "=TOPLA(hücre_aralığı)",
            "ORTALAMA": "=ORTALAMA(hücre_aralığı)",
            "MIN": "=MIN(hücre_aralığı)",
            "MAKS": "=MAKS(hücre_aralığı)",
            "ÇARPIM": "=ÇARPIM(hücre_aralığı)",
            "EĞER": "=EĞER(koşul, doğruysa_değer, yanlışsa_değer)",
            "DÜŞEYARA": "=DÜŞEYARA(arama_değeri, tablo_dizisi, sütun_indeksi, [sıralı])",
            "BİRLEŞTİR": "=BİRLEŞTİR(metin1, metin2, ...)"
        }
        self.formula_descriptions = {
            "TOPLA": "Belirtilen hücre aralığındaki sayıları toplar.",
            "ORTALAMA": "Belirtilen hücre aralığındaki sayıların ortalamasını hesaplar.",
            "MIN": "Belirtilen hücre aralığındaki en küçük sayıyı bulur.",
            "MAKS": "Belirtilen hücre aralığındaki en büyük sayıyı bulur.",
            "ÇARPIM": "Belirtilen hücre aralığındaki sayıları çarpar.",
            "EĞER": "Belirtilen koşul doğruysa bir değer, yanlışsa başka bir değer döndürür.",
            "DÜŞEYARA": "Bir tablonun ilk sütununda bir değer arar ve belirtilen sütundaki karşılık gelen değeri döndürür.",
            "BİRLEŞTİR": "Birden fazla metin parçasını birleştirir."
        }
        self.saved_formulas = []
    
    def load_excel(self, file_path):
        """Excel dosyasını yükle"""
        try:
            self.excel_file = file_path
            self.workbook = load_workbook(file_path, data_only=False)
            self.sheet_names = self.workbook.sheetnames
            self.active_sheet = self.workbook.active.title
            
            return {
                "success": True,
                "sheet_names": self.sheet_names,
                "active_sheet": self.active_sheet
            }
        except InvalidFileException:
            return {"success": False, "error": "Geçersiz Excel dosyası"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_sheet_data(self, sheet_name=None):
        """Belirtilen sayfanın verilerini al"""
        if not self.workbook:
            return {"success": False, "error": "Excel dosyası yüklenmedi"}
        
        if not sheet_name:
            sheet_name = self.active_sheet
        
        try:
            sheet = self.workbook[sheet_name]
            data = []
            headers = []
            
            # Başlıkları al
            for col in range(1, sheet.max_column + 1):
                cell_value = sheet.cell(row=1, column=col).value
                headers.append(cell_value if cell_value else f"Sütun {col}")
            
            # Verileri al
            for row in range(2, min(sheet.max_row + 1, 101)):  # İlk 100 satırı al
                row_data = {}
                for col in range(1, sheet.max_column + 1):
                    cell = sheet.cell(row=row, column=col)
                    row_data[headers[col-1]] = cell.value
                    if cell.data_type == 'f':  # Formül ise
                        row_data[f"{headers[col-1]}_formula"] = cell.value
                data.append(row_data)
            
            return {
                "success": True,
                "headers": headers,
                "data": data,
                "row_count": sheet.max_row,
                "column_count": sheet.max_column
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_cell_address(self, sheet_name, row, col):
        """Hücre adresini al (örn. A1, B2)"""
        if not self.workbook:
            return {"success": False, "error": "Excel dosyası yüklenmedi"}
        
        try:
            from openpyxl.utils import get_column_letter
            col_letter = get_column_letter(col)
            return {"success": True, "address": f"{col_letter}{row}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_formula_categories(self):
        """Formül kategorilerini al"""
        return {"success": True, "categories": self.formula_categories}
    
    def get_formula_templates(self):
        """Formül şablonlarını al"""
        return {"success": True, "templates": self.formula_templates}
    
    def get_formula_descriptions(self):
        """Formül açıklamalarını al"""
        return {"success": True, "descriptions": self.formula_descriptions}
    
    def create_formula(self, name, formula, description, category, example=None):
        """Yeni formül oluştur"""
        formula_id = f"formula_{len(self.saved_formulas) + 1}"
        
        new_formula = {
            "id": formula_id,
            "name": name,
            "formula": formula,
            "description": description,
            "category": category,
            "example": example,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        self.saved_formulas.append(new_formula)
        
        return {"success": True, "formula_id": formula_id}
    
    def get_saved_formulas(self):
        """Kaydedilmiş formülleri al"""
        return {"success": True, "formulas": self.saved_formulas}
    
    def delete_formula(self, formula_id):
        """Formülü sil"""
        for i, formula in enumerate(self.saved_formulas):
            if formula["id"] == formula_id:
                del self.saved_formulas[i]
                return {"success": True}
        
        return {"success": False, "error": "Formül bulunamadı"}
    
    def update_formula(self, formula_id, name=None, formula=None, description=None, category=None, example=None):
        """Formülü güncelle"""
        for i, saved_formula in enumerate(self.saved_formulas):
            if saved_formula["id"] == formula_id:
                if name:
                    self.saved_formulas[i]["name"] = name
                if formula:
                    self.saved_formulas[i]["formula"] = formula
                if description:
                    self.saved_formulas[i]["description"] = description
                if category:
                    self.saved_formulas[i]["category"] = category
                if example:
                    self.saved_formulas[i]["example"] = example
                
                return {"success": True}
        
        return {"success": False, "error": "Formül bulunamadı"}
    
    def test_formula(self, formula, test_values=None):
        """Formülü test et"""
        if not self.workbook:
            return {"success": False, "error": "Excel dosyası yüklenmedi"}
        
        try:
            # Test sayfası oluştur
            test_sheet_name = "FormülTest"
            
            if test_sheet_name in self.workbook.sheetnames:
                test_sheet = self.workbook[test_sheet_name]
            else:
                test_sheet = self.workbook.create_sheet(test_sheet_name)
            
            # Test değerlerini ekle
            if test_values:
                for i, (key, value) in enumerate(test_values.items(), start=1):
                    test_sheet.cell(row=i, column=1).value = key
                    test_sheet.cell(row=i, column=2).value = value
            
            # Formülü ekle
            test_sheet.cell(row=1, column=4).value = "Formül:"
            test_sheet.cell(row=1, column=5).value = formula
            
            # Formülü çalıştır
            test_sheet.cell(row=2, column=4).value = "Sonuç:"
            test_sheet.cell(row=2, column=5).value = formula
            
            # Değişiklikleri kaydet
            self.workbook.save(self.excel_file)
            
            # Sonucu al
            self.workbook = load_workbook(self.excel_file, data_only=True)
            test_sheet = self.workbook[test_sheet_name]
            result = test_sheet.cell(row=2, column=5).value
            
            return {"success": True, "result": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def apply_formula(self, sheet_name, cell_range, formula):
        """Formülü belirtilen hücre aralığına uygula"""
        if not self.workbook:
            return {"success": False, "error": "Excel dosyası yüklenmedi"}
        
        try:
            sheet = self.workbook[sheet_name]
            
            # Hücre aralığını ayrıştır
            from openpyxl.utils import range_boundaries
            min_col, min_row, max_col, max_row = range_boundaries(cell_range)
            
            # Formülü uygula
            for row in range(min_row, max_row + 1):
                for col in range(min_col, max_col + 1):
                    sheet.cell(row=row, column=col).value = formula
            
            # Değişiklikleri kaydet
            self.workbook.save(self.excel_file)
            
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def save_formulas_to_file(self, file_path):
        """Formülleri dosyaya kaydet"""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(self.saved_formulas, f, ensure_ascii=False, indent=4)
            
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def load_formulas_from_file(self, file_path):
        """Formülleri dosyadan yükle"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                self.saved_formulas = json.load(f)
            
            return {"success": True, "formulas": self.saved_formulas}
        except Exception as e:
            return {"success": False, "error": str(e)}

# Excel köprüsü örneği
excel_bridge = None

# Köprüyü başlat
def init_bridge():
    global excel_bridge
    excel_bridge = ExcelBridge()

# Dosya seçme iletişim kutusu
@eel.expose
def select_file():
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    
    file_path = filedialog.askopenfilename(
        title="Excel Dosyası Seç",
        filetypes=[("Excel Dosyaları", "*.xlsx;*.xls")]
    )
    
    if file_path:
        return {"success": True, "file_path": file_path}
    else:
        return {"success": False, "error": "Dosya seçilmedi"}

# Kaydetme iletişim kutusu
@eel.expose
def select_save_file(default_name="formulas.json"):
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    
    file_path = filedialog.asksaveasfilename(
        title="Dosyayı Kaydet",
        defaultextension=".json",
        initialfile=default_name,
        filetypes=[("JSON Dosyaları", "*.json")]
    )
    
    if file_path:
        return {"success": True, "file_path": file_path}
    else:
        return {"success": False, "error": "Dosya yolu seçilmedi"}

# Excel dosyasını yükle
@eel.expose
def load_excel(file_path):
    global excel_bridge
    return excel_bridge.load_excel(file_path)

# Sayfa verilerini al
@eel.expose
def get_sheet_data(sheet_name=None):
    global excel_bridge
    return excel_bridge.get_sheet_data(sheet_name)

# Formül kategorilerini al
@eel.expose
def get_formula_categories():
    global excel_bridge
    return excel_bridge.get_formula_categories()

# Formül şablonlarını al
@eel.expose
def get_formula_templates():
    global excel_bridge
    return excel_bridge.get_formula_templates()

# Formül açıklamalarını al
@eel.expose
def get_formula_descriptions():
    global excel_bridge
    return excel_bridge.get_formula_descriptions()

# Formül oluştur
@eel.expose
def create_formula(name, formula, description, category, example=None):
    global excel_bridge
    return excel_bridge.create_formula(name, formula, description, category, example)

# Kaydedilmiş formülleri al
@eel.expose
def get_saved_formulas():
    global excel_bridge
    return excel_bridge.get_saved_formulas()

# Formül sil
@eel.expose
def delete_formula(formula_id):
    global excel_bridge
    return excel_bridge.delete_formula(formula_id)

# Formül güncelle
@eel.expose
def update_formula(formula_id, name=None, formula=None, description=None, category=None, example=None):
    global excel_bridge
    return excel_bridge.update_formula(formula_id, name, formula, description, category, example)

# Formül test et
@eel.expose
def test_formula(formula, test_values=None):
    global excel_bridge
    return excel_bridge.test_formula(formula, test_values)

# Formül uygula
@eel.expose
def apply_formula(sheet_name, cell_range, formula):
    global excel_bridge
    return excel_bridge.apply_formula(sheet_name, cell_range, formula)

# Formülleri dosyaya kaydet
@eel.expose
def save_formulas_to_file(file_path):
    global excel_bridge
    return excel_bridge.save_formulas_to_file(file_path)

# Formülleri dosyadan yükle
@eel.expose
def load_formulas_from_file(file_path):
    global excel_bridge
    return excel_bridge.load_formulas_from_file(file_path)