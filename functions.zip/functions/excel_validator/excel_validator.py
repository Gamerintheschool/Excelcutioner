import os
import sys
import eel
import json
from PyQt5.QtWidgets import QMainWindow, QVBoxLayout, QHBoxLayout, QWidget, QPushButton, QLabel, QFileDialog
from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtGui import QIcon

class ExcelValidatorWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        # Ana pencere ayarları
        self.setWindowTitle('Excel Veri Doğrulama ve Validasyon')
        self.setGeometry(100, 100, 1200, 800)
        self.setWindowIcon(QIcon('icons/excel_icon.png'))
        
        # Ana widget ve layout
        main_widget = QWidget()
        main_layout = QVBoxLayout(main_widget)
        
        # Başlık
        title_label = QLabel('Excel Veri Doğrulama ve Validasyon')
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet('font-size: 24px; font-weight: bold; margin: 10px;')
        main_layout.addWidget(title_label)
        
        # Alt başlık
        subtitle_label = QLabel('Excel dosyalarınızdaki verileri doğrulayın ve validasyon kuralları oluşturun')
        subtitle_label.setAlignment(Qt.AlignCenter)
        subtitle_label.setStyleSheet('font-size: 14px; margin-bottom: 20px;')
        main_layout.addWidget(subtitle_label)
        
        # Web arayüzü için QWebEngineView
        self.web_view = QWebEngineView()
        
        # Eel başlatma
        eel_path = os.path.dirname(os.path.abspath(__file__))
        web_path = os.path.join(eel_path, 'web')
        sys.path.append(eel_path)
        
        # Eel'i başlat
        eel.init(web_path)
        
        # Bridge modülünü import et
        from .excel_bridge import ExcelBridge
        self.bridge = ExcelBridge()
        
        # HTML dosyasını yükle
        html_path = os.path.join(web_path, 'excel_validator.html')
        self.web_view.load(QUrl.fromLocalFile(html_path))
        
        # Web view'ı layout'a ekle
        main_layout.addWidget(self.web_view)
        
        # Ana widget'ı pencereye ekle
        self.setCentralWidget(main_widget)
        
        # Pencereyi ortala
        self.center()
        
        # Eel'i başlat (ayrı bir thread'de)
        eel.start('excel_validator.html', mode=None, block=False)
    
    def center(self):
        # Pencereyi ekranın ortasına konumlandır
        frame_geometry = self.frameGeometry()
        screen_center = self.screen().availableGeometry().center()
        frame_geometry.moveCenter(screen_center)
        self.move(frame_geometry.topLeft())
    
    def closeEvent(self, event):
        # Pencere kapatıldığında Eel'i durdur
        eel.shutdown()
        event.accept()