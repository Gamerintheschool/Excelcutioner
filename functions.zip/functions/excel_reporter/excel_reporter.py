import os
import sys
import pandas as pd
from datetime import datetime
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QFileDialog, QComboBox, QCheckBox, QGroupBox, 
                             QFormLayout, QLineEdit, QMessageBox, QTabWidget, QTextEdit,
                             QDateEdit, QTimeEdit, QSpinBox, QTableWidget, QTableWidgetItem,
                             QHeaderView)
from PyQt5.QtCore import Qt, QDate, QTime
from PyQt5.QtGui import QFont

from .excel_bridge import ExcelBridge

class ExcelReporterWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.excel_bridge = ExcelBridge()
        self.initUI()
        
    def initUI(self):
        # Ana pencere ayarları
        self.setWindowTitle('Excel Otomatik Raporlama')
        self.setMinimumSize(900, 700)
        
        # Ana widget ve layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Başlık
        title_label = QLabel('Excel Otomatik Raporlama')
        title_font = QFont('Arial', 16, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Dosya seçme bölümü
        file_group = QGroupBox('Veri Kaynağı')
        file_layout = QVBoxLayout()
        
        # Dosya seçme butonu ve etiketi
        file_btn_layout = QHBoxLayout()
        self.file_path_label = QLabel('Dosya seçilmedi')
        self.file_path_label.setWordWrap(True)
        select_file_btn = QPushButton('Excel Dosyası Seç')
        select_file_btn.clicked.connect(self.select_file)
        file_btn_layout.addWidget(select_file_btn)
        file_btn_layout.addWidget(self.file_path_label)
        file_layout.addLayout(file_btn_layout)
        
        file_group.setLayout(file_layout)
        main_layout.addWidget(file_group)
        
        # Rapor yapılandırma sekmeli widget
        self.tab_widget = QTabWidget()
        
        # Rapor Ayarları Sekmesi
        report_settings_tab = QWidget()
        report_settings_layout = QVBoxLayout(report_settings_tab)
        
        # Rapor Temel Ayarları
        basic_settings_group = QGroupBox('Rapor Temel Ayarları')
        basic_form_layout = QFormLayout()
        
        self.report_title_edit = QLineEdit('Otomatik Rapor')
        basic_form_layout.addRow('Rapor Başlığı:', self.report_title_edit)
        
        self.report_desc_edit = QTextEdit()
        self.report_desc_edit.setMaximumHeight(80)
        basic_form_layout.addRow('Rapor Açıklaması:', self.report_desc_edit)
        
        self.report_author_edit = QLineEdit()
        basic_form_layout.addRow('Rapor Hazırlayan:', self.report_author_edit)
        
        self.report_date_edit = QDateEdit(QDate.currentDate())
        basic_form_layout.addRow('Rapor Tarihi:', self.report_date_edit)
        
        basic_settings_group.setLayout(basic_form_layout)
        report_settings_layout.addWidget(basic_settings_group)
        
        # Zamanlama Ayarları
        schedule_group = QGroupBox('Zamanlama Ayarları')
        schedule_layout = QVBoxLayout()
        
        self.schedule_check = QCheckBox('Otomatik Zamanlama Aktif')
        schedule_layout.addWidget(self.schedule_check)
        
        schedule_form = QFormLayout()
        
        self.schedule_frequency = QComboBox()
        self.schedule_frequency.addItems(['Günlük', 'Haftalık', 'Aylık', 'Özel'])
        schedule_form.addRow('Sıklık:', self.schedule_frequency)
        
        self.schedule_time = QTimeEdit(QTime.currentTime())
        schedule_form.addRow('Saat:', self.schedule_time)
        
        schedule_layout.addLayout(schedule_form)
        schedule_group.setLayout(schedule_layout)
        report_settings_layout.addWidget(schedule_group)
        
        # Dağıtım Ayarları
        distribution_group = QGroupBox('Dağıtım Ayarları')
        distribution_layout = QVBoxLayout()
        
        self.email_check = QCheckBox('E-posta ile Gönder')
        distribution_layout.addWidget(self.email_check)
        
        self.email_edit = QLineEdit()
        self.email_edit.setPlaceholderText('Alıcıları virgülle ayırarak girin')
        distribution_layout.addWidget(self.email_edit)
        
        self.save_local_check = QCheckBox('Yerel Olarak Kaydet')
        self.save_local_check.setChecked(True)
        distribution_layout.addWidget(self.save_local_check)
        
        self.output_path_edit = QLineEdit()
        self.output_path_edit.setPlaceholderText('Çıktı klasörü')
        output_path_btn = QPushButton('Klasör Seç')
        output_path_btn.clicked.connect(self.select_output_folder)
        
        output_path_layout = QHBoxLayout()
        output_path_layout.addWidget(self.output_path_edit)
        output_path_layout.addWidget(output_path_btn)
        distribution_layout.addLayout(output_path_layout)
        
        distribution_group.setLayout(distribution_layout)
        report_settings_layout.addWidget(distribution_group)
        
        # Rapor Ayarları sekmesini ekle
        self.tab_widget.addTab(report_settings_tab, 'Rapor Ayarları')
        
        # İçerik Sekmesi
        content_tab = QWidget()
        content_layout = QVBoxLayout(content_tab)
        
        # Veri Seçimi
        data_selection_group = QGroupBox('Veri Seçimi')
        data_selection_layout = QVBoxLayout()
        
        self.sheet_combo = QComboBox()
        data_selection_layout.addWidget(QLabel('Çalışma Sayfası:'))
        data_selection_layout.addWidget(self.sheet_combo)
        
        self.column_selection_label = QLabel('Rapora Dahil Edilecek Sütunlar:')
        data_selection_layout.addWidget(self.column_selection_label)
        
        self.column_table = QTableWidget(0, 2)
        self.column_table.setHorizontalHeaderLabels(['Sütun', 'Dahil Et'])
        self.column_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.column_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        data_selection_layout.addWidget(self.column_table)
        
        data_selection_group.setLayout(data_selection_layout)
        content_layout.addWidget(data_selection_group)
        
        # Filtreleme
        filter_group = QGroupBox('Veri Filtreleme')
        filter_layout = QVBoxLayout()
        
        self.filter_check = QCheckBox('Filtreleme Uygula')
        filter_layout.addWidget(self.filter_check)
        
        self.filter_column = QComboBox()
        filter_layout.addWidget(QLabel('Filtre Sütunu:'))
        filter_layout.addWidget(self.filter_column)
        
        filter_value_layout = QHBoxLayout()
        self.filter_value = QLineEdit()
        self.filter_value.setPlaceholderText('Filtre değeri')
        self.filter_operator = QComboBox()
        self.filter_operator.addItems(['Eşittir', 'İçerir', 'Büyüktür', 'Küçüktür', 'Arasında'])
        filter_value_layout.addWidget(QLabel('Operatör:'))
        filter_value_layout.addWidget(self.filter_operator)
        filter_value_layout.addWidget(QLabel('Değer:'))
        filter_value_layout.addWidget(self.filter_value)
        filter_layout.addLayout(filter_value_layout)
        
        filter_group.setLayout(filter_layout)
        content_layout.addWidget(filter_group)
        
        # Özet İstatistikler
        summary_group = QGroupBox('Özet İstatistikler')
        summary_layout = QVBoxLayout()
        
        self.include_summary_check = QCheckBox('Özet İstatistikleri Dahil Et')
        summary_layout.addWidget(self.include_summary_check)
        
        self.summary_columns = QComboBox()
        self.summary_columns.setEnabled(False)
        self.include_summary_check.toggled.connect(self.summary_columns.setEnabled)
        
        summary_layout.addWidget(QLabel('Özet Sütunu:'))
        summary_layout.addWidget(self.summary_columns)
        
        self.summary_stats = QTableWidget(5, 2)
        self.summary_stats.setVerticalHeaderLabels(['Ortalama', 'Medyan', 'Minimum', 'Maksimum', 'Toplam'])
        self.summary_stats.setHorizontalHeaderLabels(['İstatistik', 'Dahil Et'])
        self.summary_stats.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        
        # Özet istatistikleri için checkbox'ları ekle
        for i in range(5):
            checkbox = QCheckBox()
            self.summary_stats.setCellWidget(i, 1, checkbox)
        
        summary_layout.addWidget(self.summary_stats)
        summary_group.setLayout(summary_layout)
        content_layout.addWidget(summary_group)
        
        # İçerik sekmesini ekle
        self.tab_widget.addTab(content_tab, 'Rapor İçeriği')
        
        # Görselleştirme Sekmesi
        viz_tab = QWidget()
        viz_layout = QVBoxLayout(viz_tab)
        
        # Grafik Ayarları
        chart_group = QGroupBox('Grafik Ayarları')
        chart_layout = QVBoxLayout()
        
        self.include_chart_check = QCheckBox('Grafik Ekle')
        chart_layout.addWidget(self.include_chart_check)
        
        chart_form = QFormLayout()
        
        self.chart_type = QComboBox()
        self.chart_type.addItems(['Çubuk Grafik', 'Çizgi Grafik', 'Pasta Grafik', 'Saçılım Grafiği'])
        chart_form.addRow('Grafik Tipi:', self.chart_type)
        
        self.chart_title = QLineEdit('Veri Grafiği')
        chart_form.addRow('Grafik Başlığı:', self.chart_title)
        
        self.x_column = QComboBox()
        chart_form.addRow('X Ekseni:', self.x_column)
        
        self.y_column = QComboBox()
        chart_form.addRow('Y Ekseni:', self.y_column)
        
        chart_layout.addLayout(chart_form)
        chart_group.setLayout(chart_layout)
        viz_layout.addWidget(chart_group)
        
        # Görselleştirme sekmesini ekle
        self.tab_widget.addTab(viz_tab, 'Görselleştirme')
        
        # Şablonlar Sekmesi
        templates_tab = QWidget()
        templates_layout = QVBoxLayout(templates_tab)
        
        # Şablon Yönetimi
        template_group = QGroupBox('Şablon Yönetimi')
        template_layout = QVBoxLayout()
        
        template_actions = QHBoxLayout()
        self.template_combo = QComboBox()
        self.template_combo.addItems(['Varsayılan Şablon', 'Satış Raporu', 'Finansal Özet', 'Performans Raporu'])
        template_actions.addWidget(QLabel('Şablon:'))
        template_actions.addWidget(self.template_combo)
        
        load_template_btn = QPushButton('Şablonu Yükle')
        load_template_btn.clicked.connect(self.load_template)
        template_actions.addWidget(load_template_btn)
        
        save_template_btn = QPushButton('Mevcut Ayarları Şablon Olarak Kaydet')
        save_template_btn.clicked.connect(self.save_template)
        template_layout.addLayout(template_actions)
        template_layout.addWidget(save_template_btn)
        
        template_group.setLayout(template_layout)
        templates_layout.addWidget(template_group)
        
        # Şablonlar sekmesini ekle
        self.tab_widget.addTab(templates_tab, 'Şablonlar')
        
        # Tab widget'ı ana layout'a ekle
        main_layout.addWidget(self.tab_widget)
        
        # Butonlar
        buttons_layout = QHBoxLayout()
        
        preview_btn = QPushButton('Önizleme')
        preview_btn.clicked.connect(self.preview_report)
        buttons_layout.addWidget(preview_btn)
        
        generate_btn = QPushButton('Rapor Oluştur')
        generate_btn.clicked.connect(self.generate_report)
        buttons_layout.addWidget(generate_btn)
        
        schedule_btn = QPushButton('Zamanla')
        schedule_btn.clicked.connect(self.schedule_report)
        buttons_layout.addWidget(schedule_btn)
        
        main_layout.addLayout(buttons_layout)
    
    def select_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, 'Excel Dosyası Seç', '', 'Excel Dosyaları (*.xlsx *.xls)'
        )
        
        if file_path:
            self.file_path_label.setText(file_path)
            self.load_excel_data(file_path)
    
    def select_output_folder(self):
        folder_path = QFileDialog.getExistingDirectory(
            self, 'Çıktı Klasörü Seç'
        )
        
        if folder_path:
            self.output_path_edit.setText(folder_path)
    
    def load_excel_data(self, file_path):
        try:
            # Excel dosyasındaki sheet'leri yükle
            excel_file = pd.ExcelFile(file_path)
            sheet_names = excel_file.sheet_names
            
            # Sheet combobox'ını güncelle
            self.sheet_combo.clear()
            self.sheet_combo.addItems(sheet_names)
            
            # İlk sheet'i varsayılan olarak seç ve sütunları yükle
            if sheet_names:
                self.sheet_combo.setCurrentIndex(0)
                self.load_sheet_columns(file_path, sheet_names[0])
                
            # Sheet değiştiğinde sütunları güncelle
            self.sheet_combo.currentIndexChanged.connect(
                lambda: self.load_sheet_columns(file_path, self.sheet_combo.currentText())
            )
            
        except Exception as e:
            QMessageBox.critical(self, 'Hata', f'Dosya yüklenirken hata oluştu: {str(e)}')
    
    def load_sheet_columns(self, file_path, sheet_name):
        try:
            # Seçilen sheet'teki sütunları yükle
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            columns = df.columns.tolist()
            
            # Sütun tablosunu güncelle
            self.column_table.setRowCount(len(columns))
            
            for i, column in enumerate(columns):
                # Sütun adı
                item = QTableWidgetItem(column)
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)  # Düzenlemeyi devre dışı bırak
                self.column_table.setItem(i, 0, item)
                
                # Checkbox
                checkbox = QCheckBox()
                checkbox.setChecked(True)  # Varsayılan olarak tüm sütunları seç
                self.column_table.setCellWidget(i, 1, checkbox)
            
            # Filtre ve grafik sütunlarını güncelle
            self.filter_column.clear()
            self.x_column.clear()
            self.y_column.clear()
            self.summary_columns.clear()
            
            self.filter_column.addItems(columns)
            self.x_column.addItems(columns)
            self.y_column.addItems(columns)
            self.summary_columns.addItems(columns)
            
        except Exception as e:
            QMessageBox.critical(self, 'Hata', f'Sütunlar yüklenirken hata oluştu: {str(e)}')
    
    def load_template(self):
        template_name = self.template_combo.currentText()
        QMessageBox.information(self, 'Şablon Yüklendi', f'"{template_name}" şablonu yüklendi.')
        # Burada şablon yükleme işlemleri yapılacak
    
    def save_template(self):
        template_name, ok = QLineEdit.getText(
            self, 'Şablon Kaydet', 'Şablon Adı:'
        )
        
        if ok and template_name:
            QMessageBox.information(self, 'Şablon Kaydedildi', f'"{template_name}" şablonu kaydedildi.')
            # Burada şablon kaydetme işlemleri yapılacak
    
    def preview_report(self):
        if not self.validate_inputs():
            return
        
        QMessageBox.information(self, 'Önizleme', 'Rapor önizleme hazırlanıyor...')
        # Burada rapor önizleme işlemleri yapılacak
    
    def generate_report(self):
        if not self.validate_inputs():
            return
        
        try:
            # Rapor oluşturma parametrelerini hazırla
            params = self.prepare_report_params()
            
            # Excel Bridge üzerinden rapor oluştur
            result = self.excel_bridge.generate_report(params)
            
            if result['success']:
                QMessageBox.information(
                    self, 'Başarılı', 
                    f'Rapor başarıyla oluşturuldu.\n'
                    f'Dosya: {result["output_path"]}'
                )
            else:
                QMessageBox.critical(
                    self, 'Hata', 
                    f'Rapor oluşturulurken hata oluştu:\n{result["error"]}'
                )
                
        except Exception as e:
            QMessageBox.critical(
                self, 'Hata', 
                f'Rapor oluşturulurken beklenmeyen bir hata oluştu:\n{str(e)}'
            )
    
    def schedule_report(self):
        if not self.validate_inputs():
            return
        
        if not self.schedule_check.isChecked():
            QMessageBox.warning(self, 'Uyarı', 'Zamanlama aktif değil. Lütfen önce zamanlama ayarlarını etkinleştirin.')
            return
        
        frequency = self.schedule_frequency.currentText()
        time = self.schedule_time.time().toString('hh:mm')
        
        QMessageBox.information(
            self, 'Rapor Zamanlandı', 
            f'Rapor başarıyla zamanlandı.\n'
            f'Sıklık: {frequency}\n'
            f'Saat: {time}'
        )
        # Burada zamanlama işlemleri yapılacak
    
    def validate_inputs(self):
        # Dosya seçildi mi kontrol et
        if self.file_path_label.text() == 'Dosya seçilmedi':
            QMessageBox.warning(self, 'Uyarı', 'Lütfen bir Excel dosyası seçin.')
            return False
        
        # Rapor başlığı girildi mi kontrol et
        if not self.report_title_edit.text().strip():
            QMessageBox.warning(self, 'Uyarı', 'Lütfen bir rapor başlığı girin.')
            return False
        
        # E-posta gönderimi seçiliyse e-posta adresi girildi mi kontrol et
        if self.email_check.isChecked() and not self.email_edit.text().strip():
            QMessageBox.warning(self, 'Uyarı', 'Lütfen en az bir e-posta adresi girin.')
            return False
        
        # Yerel kayıt seçiliyse çıktı klasörü seçildi mi kontrol et
        if self.save_local_check.isChecked() and not self.output_path_edit.text().strip():
            QMessageBox.warning(self, 'Uyarı', 'Lütfen bir çıktı klasörü seçin.')
            return False
        
        return True
    
    def prepare_report_params(self):
        # Seçilen sütunları belirle
        selected_columns = []
        for i in range(self.column_table.rowCount()):
            column_name = self.column_table.item(i, 0).text()
            checkbox = self.column_table.cellWidget(i, 1)
            if checkbox.isChecked():
                selected_columns.append(column_name)
        
        # Özet istatistikleri belirle
        summary_stats = []
        if self.include_summary_check.isChecked():
            stat_names = ['mean', 'median', 'min', 'max', 'sum']
            for i in range(5):
                checkbox = self.summary_stats.cellWidget(i, 1)
                if checkbox.isChecked():
                    summary_stats.append(stat_names[i])
        
        # Filtreleme parametrelerini belirle
        filter_params = None
        if self.filter_check.isChecked():
            filter_params = {
                'column': self.filter_column.currentText(),
                'operator': self.filter_operator.currentText(),
                'value': self.filter_value.text()
            }
        
        # Grafik parametrelerini belirle
        chart_params = None
        if self.include_chart_check.isChecked():
            chart_params = {
                'type': self.chart_type.currentText(),
                'title': self.chart_title.text(),
                'x_column': self.x_column.currentText(),
                'y_column': self.y_column.currentText()
            }
        
        # Tüm parametreleri bir araya getir
        params = {
            'file_path': self.file_path_label.text(),
            'sheet_name': self.sheet_combo.currentText(),
            'report_title': self.report_title_edit.text(),
            'report_description': self.report_desc_edit.toPlainText(),
            'report_author': self.report_author_edit.text(),
            'report_date': self.report_date_edit.date().toString('yyyy-MM-dd'),
            'selected_columns': selected_columns,
            'filter': filter_params,
            'summary': {
                'column': self.summary_columns.currentText() if self.include_summary_check.isChecked() else None,
                'stats': summary_stats
            },
            'chart': chart_params,
            'output': {
                'save_local': self.save_local_check.isChecked(),
                'output_path': self.output_path_edit.text() if self.save_local_check.isChecked() else None,
                'email': self.email_check.isChecked(),
                'email_recipients': self.email_edit.text().split(',') if self.email_check.isChecked() else None
            },
            'schedule': {
                'enabled': self.schedule_check.isChecked(),
                'frequency': self.schedule_frequency.currentText() if self.schedule_check.isChecked() else None,
                'time': self.schedule_time.time().toString('hh:mm') if self.schedule_check.isChecked() else None
            }
        }
        
        return params