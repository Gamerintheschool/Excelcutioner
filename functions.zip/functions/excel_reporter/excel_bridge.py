import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import schedule
import time
import threading

class ExcelBridge:
    def __init__(self):
        self.scheduled_jobs = {}
    
    def generate_report(self, params):
        """
        Excel raporunu oluşturur.
        
        Args:
            params: Rapor oluşturma parametreleri
            
        Returns:
            dict: İşlem sonucu
        """
        try:
            # Parametreleri al
            file_path = params['file_path']
            sheet_name = params['sheet_name']
            report_title = params['report_title']
            report_description = params['report_description']
            report_author = params['report_author']
            report_date = params['report_date']
            selected_columns = params['selected_columns']
            filter_params = params['filter']
            summary_params = params['summary']
            chart_params = params['chart']
            output_params = params['output']
            
            # Excel dosyasını oku
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            
            # Sadece seçilen sütunları al
            if selected_columns:
                df = df[selected_columns]
            
            # Filtreleme uygula
            if filter_params:
                df = self._apply_filter(df, filter_params)
            
            # Rapor dosyasını oluştur
            output_path = self._create_report_file(
                df, 
                report_title, 
                report_description, 
                report_author, 
                report_date, 
                summary_params, 
                chart_params, 
                output_params
            )
            
            # E-posta gönder
            if output_params['email'] and output_params['email_recipients']:
                self._send_email(
                    output_path, 
                    report_title, 
                    output_params['email_recipients']
                )
            
            return {
                'success': True,
                'output_path': output_path
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def _apply_filter(self, df, filter_params):
        """
        DataFrame'e filtreleme uygular.
        
        Args:
            df: Filtrelenecek DataFrame
            filter_params: Filtreleme parametreleri
            
        Returns:
            DataFrame: Filtrelenmiş DataFrame
        """
        column = filter_params['column']
        operator = filter_params['operator']
        value = filter_params['value']
        
        if operator == 'Eşittir':
            return df[df[column] == value]
        elif operator == 'İçerir':
            return df[df[column].astype(str).str.contains(value, na=False)]
        elif operator == 'Büyüktür':
            try:
                return df[df[column] > float(value)]
            except ValueError:
                return df
        elif operator == 'Küçüktür':
            try:
                return df[df[column] < float(value)]
            except ValueError:
                return df
        elif operator == 'Arasında':
            try:
                values = value.split(',')
                if len(values) == 2:
                    min_val, max_val = float(values[0]), float(values[1])
                    return df[(df[column] >= min_val) & (df[column] <= max_val)]
            except (ValueError, IndexError):
                pass
        
        return df
    
    def _create_report_file(self, df, title, description, author, date, summary_params, chart_params, output_params):
        """
        Rapor dosyasını oluşturur.
        
        Args:
            df: Rapor verisi
            title: Rapor başlığı
            description: Rapor açıklaması
            author: Rapor hazırlayan
            date: Rapor tarihi
            summary_params: Özet istatistik parametreleri
            chart_params: Grafik parametreleri
            output_params: Çıktı parametreleri
            
        Returns:
            str: Oluşturulan rapor dosyasının yolu
        """
        # Çıktı klasörünü kontrol et
        output_dir = output_params['output_path'] if output_params['save_local'] else os.path.dirname(os.path.abspath(__file__))
        os.makedirs(output_dir, exist_ok=True)
        
        # Çıktı dosya adını oluştur
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_filename = f"{title.replace(' ', '_')}_{timestamp}.xlsx"
        output_path = os.path.join(output_dir, output_filename)
        
        # Excel yazıcı oluştur
        with pd.ExcelWriter(output_path, engine='xlsxwriter') as writer:
            # Veri sayfasını yaz
            df.to_excel(writer, sheet_name='Veri', index=False)
            workbook = writer.book
            worksheet = writer.sheets['Veri']
            
            # Başlık formatı
            title_format = workbook.add_format({
                'bold': True,
                'font_size': 16,
                'align': 'center',
                'valign': 'vcenter'
            })
            
            # Başlık bilgilerini ekle
            info_sheet = workbook.add_worksheet('Rapor Bilgileri')
            info_sheet.write(0, 0, 'Rapor Başlığı:', workbook.add_format({'bold': True}))
            info_sheet.write(0, 1, title)
            info_sheet.write(1, 0, 'Açıklama:', workbook.add_format({'bold': True}))
            info_sheet.write(1, 1, description)
            info_sheet.write(2, 0, 'Hazırlayan:', workbook.add_format({'bold': True}))
            info_sheet.write(2, 1, author)
            info_sheet.write(3, 0, 'Tarih:', workbook.add_format({'bold': True}))
            info_sheet.write(3, 1, date)
            info_sheet.write(4, 0, 'Kaynak Dosya:', workbook.add_format({'bold': True}))
            info_sheet.write(4, 1, os.path.basename(output_path))
            
            # Özet istatistikleri ekle
            if summary_params['column'] and summary_params['stats']:
                summary_sheet = workbook.add_worksheet('Özet İstatistikler')
                summary_sheet.write(0, 0, f"{summary_params['column']} İstatistikleri", title_format)
                summary_sheet.merge_range('A1:B1', f"{summary_params['column']} İstatistikleri", title_format)
                
                row = 2
                for stat in summary_params['stats']:
                    stat_name = {
                        'mean': 'Ortalama',
                        'median': 'Medyan',
                        'min': 'Minimum',
                        'max': 'Maksimum',
                        'sum': 'Toplam'
                    }.get(stat, stat)
                    
                    try:
                        if stat == 'mean':
                            value = df[summary_params['column']].mean()
                        elif stat == 'median':
                            value = df[summary_params['column']].median()
                        elif stat == 'min':
                            value = df[summary_params['column']].min()
                        elif stat == 'max':
                            value = df[summary_params['column']].max()
                        elif stat == 'sum':
                            value = df[summary_params['column']].sum()
                        else:
                            continue
                            
                        summary_sheet.write(row, 0, stat_name, workbook.add_format({'bold': True}))
                        summary_sheet.write(row, 1, value)
                        row += 1
                    except:
                        # Sayısal olmayan sütunlar için hata oluşabilir
                        pass
            
            # Grafik ekle
            if chart_params:
                self._add_chart_to_report(df, chart_params, workbook)
        
        return output_path
    
    def _add_chart_to_report(self, df, chart_params, workbook):
        """
        Rapora grafik ekler.
        
        Args:
            df: Veri DataFrame'i
            chart_params: Grafik parametreleri
            workbook: Excel workbook nesnesi
        """
        chart_type = chart_params['type']
        title = chart_params['title']
        x_column = chart_params['x_column']
        y_column = chart_params['y_column']
        
        # Grafik sayfası ekle
        chart_sheet = workbook.add_worksheet('Grafik')
        
        # Grafik verilerini hazırla
        chart_data = df[[x_column, y_column]].copy()
        
        # Grafik verilerini sayfaya yaz
        chart_data.to_excel(workbook, sheet_name='Grafik', startrow=1, index=False)
        
        # Grafik oluştur
        chart = None
        
        if chart_type == 'Çubuk Grafik':
            chart = workbook.add_chart({'type': 'column'})
        elif chart_type == 'Çizgi Grafik':
            chart = workbook.add_chart({'type': 'line'})
        elif chart_type == 'Pasta Grafik':
            chart = workbook.add_chart({'type': 'pie'})
        elif chart_type == 'Saçılım Grafiği':
            chart = workbook.add_chart({'type': 'scatter'})
        
        if chart:
            # Veri serisi ekle
            chart.add_series({
                'name': y_column,
                'categories': ['Grafik', 2, 0, 1 + len(chart_data), 0],
                'values': ['Grafik', 2, 1, 1 + len(chart_data), 1],
            })
            
            # Grafik başlığı ve etiketleri ayarla
            chart.set_title({'name': title})
            chart.set_x_axis({'name': x_column})
            chart.set_y_axis({'name': y_column})
            
            # Grafiği sayfaya yerleştir
            chart_sheet.insert_chart('D2', chart, {'x_scale': 1.5, 'y_scale': 1.5})
    
    def _send_email(self, file_path, subject, recipients):
        """
        Raporu e-posta ile gönderir.
        
        Args:
            file_path: Gönderilecek rapor dosyasının yolu
            subject: E-posta konusu
            recipients: Alıcı e-posta adresleri listesi
        """
        # Bu fonksiyon e-posta gönderme işlemini gerçekleştirecek
        # Gerçek uygulamada SMTP ayarları ve kimlik bilgileri gerekecektir
        pass
    
    def schedule_report(self, params, schedule_params):
        """
        Rapor oluşturmayı zamanlar.
        
        Args:
            params: Rapor oluşturma parametreleri
            schedule_params: Zamanlama parametreleri
            
        Returns:
            dict: İşlem sonucu
        """
        try:
            frequency = schedule_params['frequency']
            time_str = schedule_params['time']
            
            # Zamanlama işlemini oluştur
            job_id = f"report_{datetime.now().strftime('%Y%m%d%H%M%S')}"
            
            # Zamanlanmış işi kaydet
            self.scheduled_jobs[job_id] = {
                'params': params,
                'schedule': schedule_params,
                'job': None
            }
            
            # Zamanlama işlemini başlat
            self._start_scheduler(job_id, frequency, time_str)
            
            return {
                'success': True,
                'job_id': job_id
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def _start_scheduler(self, job_id, frequency, time_str):
        """
        Zamanlama işlemini başlatır.
        
        Args:
            job_id: Zamanlanmış işin ID'si
            frequency: Zamanlama sıklığı
            time_str: Zamanlama saati
        """
        params = self.scheduled_jobs[job_id]['params']
        
        # Zamanlanmış işi oluştur
        job = None
        
        if frequency == 'Günlük':
            job = schedule.every().day.at(time_str).do(self.generate_report, params)
        elif frequency == 'Haftalık':
            job = schedule.every().monday.at(time_str).do(self.generate_report, params)
        elif frequency == 'Aylık':
            # Ayın ilk günü
            job = schedule.every().month.at(time_str).do(self.generate_report, params)
        
        # İşi kaydet
        if job:
            self.scheduled_jobs[job_id]['job'] = job
            
            # Zamanlayıcıyı ayrı bir thread'de çalıştır
            scheduler_thread = threading.Thread(target=self._run_scheduler)
            scheduler_thread.daemon = True
            scheduler_thread.start()
    
    def _run_scheduler(self):
        """
        Zamanlayıcıyı çalıştırır.
        """
        while True:
            schedule.run_pending()
            time.sleep(60)  # Her dakika kontrol et
    
    def cancel_scheduled_report(self, job_id):
        """
        Zamanlanmış rapor oluşturmayı iptal eder.
        
        Args:
            job_id: İptal edilecek işin ID'si
            
        Returns:
            dict: İşlem sonucu
        """
        try:
            if job_id in self.scheduled_jobs:
                job = self.scheduled_jobs[job_id]['job']
                if job:
                    schedule.cancel_job(job)
                del self.scheduled_jobs[job_id]
                
                return {
                    'success': True
                }
            else:
                return {
                    'success': False,
                    'error': 'Belirtilen ID ile zamanlanmış bir iş bulunamadı.'
                }
                
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }