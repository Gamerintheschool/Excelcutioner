// Excel Otomatik Raporlama JavaScript

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', function() {
    // Tarih alanını bugünün tarihine ayarla
    document.getElementById('reportDate').valueAsDate = new Date();
    document.getElementById('scheduleTime').value = '09:00';
    
    // Zamanlama seçeneklerini gizle/göster
    const scheduleEnabled = document.getElementById('scheduleEnabled');
    const scheduleOptions = document.getElementById('scheduleOptions');
    scheduleOptions.style.display = scheduleEnabled.checked ? 'block' : 'none';
    
    scheduleEnabled.addEventListener('change', function() {
        scheduleOptions.style.display = this.checked ? 'block' : 'none';
    });
    
    // E-posta seçeneklerini gizle/göster
    const emailEnabled = document.getElementById('emailEnabled');
    const emailOptions = document.getElementById('emailOptions');
    emailOptions.style.display = emailEnabled.checked ? 'block' : 'none';
    
    emailEnabled.addEventListener('change', function() {
        emailOptions.style.display = this.checked ? 'block' : 'none';
    });
    
    // Yerel kaydetme seçeneklerini gizle/göster
    const saveLocalEnabled = document.getElementById('saveLocalEnabled');
    const saveLocalOptions = document.getElementById('saveLocalOptions');
    saveLocalOptions.style.display = saveLocalEnabled.checked ? 'block' : 'none';
    
    saveLocalEnabled.addEventListener('change', function() {
        saveLocalOptions.style.display = this.checked ? 'block' : 'none';
    });
    
    // Filtreleme seçeneklerini gizle/göster
    const filterEnabled = document.getElementById('filterEnabled');
    const filterOptions = document.getElementById('filterOptions');
    filterOptions.style.display = filterEnabled.checked ? 'block' : 'none';
    
    filterEnabled.addEventListener('change', function() {
        filterOptions.style.display = this.checked ? 'block' : 'none';
    });
    
    // Özet seçeneklerini gizle/göster
    const summaryEnabled = document.getElementById('summaryEnabled');
    const summaryOptions = document.getElementById('summaryOptions');
    summaryOptions.style.display = summaryEnabled.checked ? 'block' : 'none';
    
    summaryEnabled.addEventListener('change', function() {
        summaryOptions.style.display = this.checked ? 'block' : 'none';
    });
    
    // Grafik seçeneklerini gizle/göster
    const chartEnabled = document.getElementById('chartEnabled');
    const chartOptions = document.getElementById('chartOptions');
    chartOptions.style.display = chartEnabled.checked ? 'block' : 'none';
    
    chartEnabled.addEventListener('change', function() {
        chartOptions.style.display = this.checked ? 'block' : 'none';
    });
    
    // Dosya seçme butonu
    document.getElementById('selectFileBtn').addEventListener('click', function() {
        eel.select_file()(function(result) {
            if (result.success) {
                document.getElementById('selectedFilePath').textContent = result.file_path;
                loadExcelData(result.file_path);
            }
        });
    });
    
    // Klasör seçme butonu
    document.getElementById('selectFolderBtn').addEventListener('click', function() {
        eel.select_folder()(function(result) {
            if (result.success) {
                document.getElementById('outputPath').value = result.folder_path;
            }
        });
    });
    
    // Şablon yükleme butonu
    document.getElementById('loadTemplateBtn').addEventListener('click', function() {
        const templateName = document.getElementById('templateSelect').value;
        loadTemplate(templateName);
    });
    
    // Şablon kaydetme butonu
    document.getElementById('saveTemplateBtn').addEventListener('click', function() {
        saveTemplate();
    });
    
    // Önizleme butonu
    document.getElementById('previewBtn').addEventListener('click', function() {
        if (validateInputs()) {
            previewReport();
        }
    });
    
    // Rapor oluşturma butonu
    document.getElementById('generateBtn').addEventListener('click', function() {
        if (validateInputs()) {
            generateReport();
        }
    });
    
    // Zamanlama butonu
    document.getElementById('scheduleBtn').addEventListener('click', function() {
        if (validateInputs()) {
            scheduleReport();
        }
    });
    
    // Sheet değiştiğinde sütunları güncelle
    document.getElementById('sheetSelect').addEventListener('change', function() {
        const filePath = document.getElementById('selectedFilePath').textContent;
        if (filePath !== 'Dosya seçilmedi') {
            loadSheetColumns(filePath, this.value);
        }
    });
});

// Excel dosyasını yükle
function loadExcelData(filePath) {
    eel.load_excel_data(filePath)(function(result) {
        if (result.success) {
            // Sheet combobox'ını güncelle
            const sheetSelect = document.getElementById('sheetSelect');
            sheetSelect.innerHTML = '';
            
            result.sheets.forEach(function(sheet) {
                const option = document.createElement('option');
                option.value = sheet;
                option.textContent = sheet;
                sheetSelect.appendChild(option);
            });
            
            // İlk sheet'i seç ve sütunları yükle
            if (result.sheets.length > 0) {
                loadSheetColumns(filePath, result.sheets[0]);
            }
        } else {
            alert('Dosya yüklenirken hata oluştu: ' + result.error);
        }
    });
}

// Sheet sütunlarını yükle
function loadSheetColumns(filePath, sheetName) {
    eel.load_sheet_columns(filePath, sheetName)(function(result) {
        if (result.success) {
            // Sütun tablosunu güncelle
            const columnsTable = document.getElementById('columnsTable').getElementsByTagName('tbody')[0];
            columnsTable.innerHTML = '';
            
            result.columns.forEach(function(column) {
                const row = columnsTable.insertRow();
                
                // Sütun adı
                const cellName = row.insertCell(0);
                cellName.textContent = column;
                
                // Checkbox
                const cellCheckbox = row.insertCell(1);
                const checkbox = document.createElement('div');
                checkbox.className = 'custom-control custom-checkbox';
                checkbox.innerHTML = `
                    <input type="checkbox" class="custom-control-input" id="col_${column}" checked>
                    <label class="custom-control-label" for="col_${column}"></label>
                `;
                cellCheckbox.appendChild(checkbox);
            });
            
            // Filtre ve grafik sütunlarını güncelle
            updateColumnDropdowns(result.columns);
        } else {
            alert('Sütunlar yüklenirken hata oluştu: ' + result.error);
        }
    });
}

// Sütun dropdown'larını güncelle
function updateColumnDropdowns(columns) {
    const dropdowns = [
        'filterColumn',
        'summaryColumn',
        'xColumn',
        'yColumn'
    ];
    
    dropdowns.forEach(function(dropdownId) {
        const dropdown = document.getElementById(dropdownId);
        dropdown.innerHTML = '';
        
        columns.forEach(function(column) {
            const option = document.createElement('option');
            option.value = column;
            option.textContent = column;
            dropdown.appendChild(option);
        });
    });
}

// Şablon yükle
function loadTemplate(templateName) {
    eel.load_template(templateName)(function(result) {
        if (result.success) {
            // Şablon verilerini form alanlarına doldur
            document.getElementById('reportTitle').value = result.template.report_title;
            document.getElementById('reportDescription').value = result.template.report_description;
            // Diğer alanları da doldur...
            
            alert(`"${templateName}" şablonu yüklendi.`);
        } else {
            alert('Şablon yüklenirken hata oluştu: ' + result.error);
        }
    });
}

// Şablon kaydet
function saveTemplate() {
    // Şablon adını sor
    const templateName = prompt('Şablon Adı:');
    
    if (templateName) {
        // Form verilerini topla
        const templateData = collectFormData();
        
        eel.save_template(templateName, templateData)(function(result) {
            if (result.success) {
                alert(`"${templateName}" şablonu kaydedildi.`);
            } else {
                alert('Şablon kaydedilirken hata oluştu: ' + result.error);
            }
        });
    }
}

// Rapor önizleme
function previewReport() {
    // Form verilerini topla
    const reportParams = collectFormData();
    
    eel.preview_report(reportParams)(function(result) {
        if (result.success) {
            // Önizleme penceresini göster
            alert('Rapor önizleme hazırlanıyor...');
        } else {
            alert('Önizleme oluşturulurken hata oluştu: ' + result.error);
        }
    });
}

// Rapor oluştur
function generateReport() {
    // Form verilerini topla
    const reportParams = collectFormData();
    
    eel.generate_report(reportParams)(function(result) {
        if (result.success) {
            alert(`Rapor başarıyla oluşturuldu.\nDosya: ${result.output_path}`);
        } else {
            alert('Rapor oluşturulurken hata oluştu: ' + result.error);
        }
    });
}

// Rapor zamanla
function scheduleReport() {
    if (!document.getElementById('scheduleEnabled').checked) {
        alert('Zamanlama aktif değil. Lütfen önce zamanlama ayarlarını etkinleştirin.');
        return;
    }
    
    // Form verilerini topla
    const reportParams = collectFormData();
    
    eel.schedule_report(reportParams)(function(result) {
        if (result.success) {
            const frequency = document.getElementById('scheduleFrequency').value;
            const time = document.getElementById('scheduleTime').value;
            
            alert(`Rapor başarıyla zamanlandı.\nSıklık: ${frequency}\nSaat: ${time}`);
        } else {
            alert('Rapor zamanlanırken hata oluştu: ' + result.error);
        }
    });
}

// Form verilerini topla
function collectFormData() {
    // Seçilen sütunları belirle
    const selectedColumns = [];
    const columnsTable = document.getElementById('columnsTable').getElementsByTagName('tbody')[0];
    
    for (let i = 0; i < columnsTable.rows.length; i++) {
        const row = columnsTable.rows[i];
        const columnName = row.cells[0].textContent;
        const checkbox = row.querySelector('input[type="checkbox"]');
        
        if (checkbox.checked) {
            selectedColumns.push(columnName);
        }
    }
    
    // Özet istatistikleri belirle
    const summaryStats = [];
    const statIds = ['statMean', 'statMedian', 'statMin', 'statMax', 'statSum'];
    const statNames = ['mean', 'median', 'min', 'max', 'sum'];
    
    if (document.getElementById('summaryEnabled').checked) {
        for (let i = 0; i < statIds.length; i++) {
            if (document.getElementById(statIds[i]).checked) {
                summaryStats.push(statNames[i]);
            }
        }
    }
    
    // Filtreleme parametrelerini belirle
    let filterParams = null;
    if (document.getElementById('filterEnabled').checked) {
        filterParams = {
            column: document.getElementById('filterColumn').value,
            operator: document.getElementById('filterOperator').value,
            value: document.getElementById('filterValue').value
        };
    }
    
    // Grafik parametrelerini belirle
    let chartParams = null;
    if (document.getElementById('chartEnabled').checked) {
        chartParams = {
            type: document.getElementById('chartType').value,
            title: document.getElementById('chartTitle').value,
            x_column: document.getElementById('xColumn').value,
            y_column: document.getElementById('yColumn').value
        };
    }
    
    // Tüm parametreleri bir araya getir
    const params = {
        file_path: document.getElementById('selectedFilePath').textContent,
        sheet_name: document.getElementById('sheetSelect').value,
        report_title: document.getElementById('reportTitle').value,
        report_description: document.getElementById('reportDescription').value,
        report_author: document.getElementById('reportAuthor').value,
        report_date: document.getElementById('reportDate').value,
        selected_columns: selectedColumns,
        filter: filterParams,
        summary: {
            column: document.getElementById('summaryEnabled').checked ? document.getElementById('summaryColumn').value : null,
            stats: summaryStats
        },
        chart: chartParams,
        output: {
            save_local: document.getElementById('saveLocalEnabled').checked,
            output_path: document.getElementById('saveLocalEnabled').checked ? document.getElementById('outputPath').value : null,
            email: document.getElementById('emailEnabled').checked,
            email_recipients: document.getElementById('emailEnabled').checked ? document.getElementById('emailRecipients').value.split(',') : null
        },
        schedule: {
            enabled: document.getElementById('scheduleEnabled').checked,
            frequency: document.getElementById('scheduleEnabled').checked ? document.getElementById('scheduleFrequency').value : null,
            time: document.getElementById('scheduleEnabled').checked ? document.getElementById('scheduleTime').value : null
        }
    };
    
    return params;
}

// Form doğrulama
function validateInputs() {
    // Dosya seçildi mi kontrol et
    if (document.getElementById('selectedFilePath').textContent === 'Dosya seçilmedi') {
        alert('Lütfen bir Excel dosyası seçin.');
        return false;
    }
    
    // Rapor başlığı girildi mi kontrol et
    if (!document.getElementById('reportTitle').value.trim()) {
        alert('Lütfen bir rapor başlığı girin.');
        return false;
    }
    
    // E-posta gönderimi seçiliyse e-posta adresi girildi mi kontrol et
    if (document.getElementById('emailEnabled').checked && !document.getElementById('emailRecipients').value.trim()) {
        alert('Lütfen en az bir e-posta adresi girin.');
        return false;
    }
    
    // Yerel kayıt seçiliyse çıktı klasörü seçildi mi kontrol et
    if (document.getElementById('saveLocalEnabled').checked && !document.getElementById('outputPath').value.trim()) {
        alert('Lütfen bir çıktı klasörü seçin.');
        return false;
    }
    
    return true;
}