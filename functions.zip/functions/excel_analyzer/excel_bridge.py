import os
import base64
import pandas as pd
import numpy as np
import json
from io import BytesIO
import matplotlib.pyplot as plt

class ExcelBridge:
    @staticmethod
    def save_excel_from_base64(base64_data, output_path):
        """
        Base64 formatındaki Excel verisini dosyaya kaydet
        """
        try:
            # Base64'ten binary veriye dönüştür
            binary_data = base64.b64decode(base64_data)
            
            # BytesIO nesnesi oluştur
            excel_data = BytesIO(binary_data)
            
            # Excel dosyasını oku
            dfs = pd.read_excel(excel_data, sheet_name=None)
            
            # Excel dosyasını kaydet
            with pd.ExcelWriter(output_path) as writer:
                for sheet_name, df in dfs.items():
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            return True, "Excel dosyası başarıyla kaydedildi."
        
        except Exception as e:
            return False, f"Hata: {str(e)}"
    
    @staticmethod
    def analyze_excel(input_file, analysis_type, columns=None, output_file=None, params=None):
        """
        Excel dosyasını analiz et
        """
        try:
            # Excel dosyasını oku
            if isinstance(input_file, str):
                dfs = pd.read_excel(input_file, sheet_name=None)
            else:
                # Base64'ten binary veriye dönüştür
                binary_data = base64.b64decode(input_file)
                excel_data = BytesIO(binary_data)
                dfs = pd.read_excel(excel_data, sheet_name=None)
            
            results = {}
            figures = {}
            
            for sheet_name, df in dfs.items():
                # Seçilen sütunları filtrele
                if columns and len(columns) > 0:
                    cols_to_use = [col for col in columns if col in df.columns]
                    if not cols_to_use:
                        continue
                    df_analysis = df[cols_to_use]
                else:
                    df_analysis = df
                
                # Analiz tipine göre işlem yap
                if analysis_type == "descriptive":
                    # Sayısal sütunları seç
                    numeric_cols = df_analysis.select_dtypes(include=['number']).columns.tolist()
                    if not numeric_cols:
                        results[sheet_name] = {"error": "Sayısal sütun bulunamadı"}
                        continue
                    
                    # Tanımlayıcı istatistikler
                    stats = df_analysis[numeric_cols].describe().to_dict()
                    results[sheet_name] = stats
                
                elif analysis_type == "correlation":
                    # Sayısal sütunları seç
                    numeric_cols = df_analysis.select_dtypes(include=['number']).columns.tolist()
                    if not numeric_cols or len(numeric_cols) < 2:
                        results[sheet_name] = {"error": "Korelasyon için en az 2 sayısal sütun gerekli"}
                        continue
                    
                    # Korelasyon matrisi
                    corr_matrix = df_analysis[numeric_cols].corr().to_dict()
                    results[sheet_name] = corr_matrix
                    
                    # Korelasyon ısı haritası
                    plt.figure(figsize=(10, 8))
                    plt.title(f"{sheet_name} - Korelasyon Isı Haritası")
                    corr_heatmap = plt.imshow(df_analysis[numeric_cols].corr(), cmap='coolwarm', interpolation='none')
                    plt.colorbar(corr_heatmap)
                    plt.xticks(range(len(numeric_cols)), numeric_cols, rotation=90)
                    plt.yticks(range(len(numeric_cols)), numeric_cols)
                    
                    # Figürü kaydet
                    buf = BytesIO()
                    plt.savefig(buf, format='png', bbox_inches='tight')
                    buf.seek(0)
                    figures[f"{sheet_name}_correlation_heatmap"] = buf
                    plt.close()
                
                elif analysis_type == "summary":
                    # Genel özet bilgiler
                    summary = {
                        "row_count": len(df_analysis),
                        "column_count": len(df_analysis.columns),
                        "missing_values": df_analysis.isna().sum().to_dict(),
                        "data_types": {col: str(dtype) for col, dtype in df_analysis.dtypes.items()}
                    }
                    results[sheet_name] = summary
                    
                elif analysis_type == "time_series":
                    # Zaman serisi analizi için parametreleri kontrol et
                    if not params or 'date_column' not in params:
                        results[sheet_name] = {"error": "Zaman serisi analizi için tarih sütunu belirtilmeli"}
                        continue
                        
                    date_column = params['date_column']
                    value_column = params.get('value_column', None)
                    
                    # Tarih sütununu kontrol et
                    if date_column not in df_analysis.columns:
                        results[sheet_name] = {"error": f"Belirtilen tarih sütunu '{date_column}' bulunamadı"}
                        continue
                        
                    # Tarih sütununu dönüştür
                    try:
                        df_analysis[date_column] = pd.to_datetime(df_analysis[date_column])
                        df_analysis = df_analysis.sort_values(by=date_column)
                    except Exception as e:
                        results[sheet_name] = {"error": f"Tarih sütunu dönüştürülemedi: {str(e)}"}
                        continue
                    
                    # Değer sütunu belirtilmişse kontrol et
                    if value_column:
                        if value_column not in df_analysis.columns:
                            results[sheet_name] = {"error": f"Belirtilen değer sütunu '{value_column}' bulunamadı"}
                            continue
                        
                        # Zaman serisi analizi
                        ts_data = df_analysis.set_index(date_column)[value_column]
                        
                        # Temel istatistikler
                        ts_stats = {
                            "mean": ts_data.mean(),
                            "std": ts_data.std(),
                            "min": ts_data.min(),
                            "max": ts_data.max(),
                            "trend": "artan" if ts_data.iloc[-1] > ts_data.iloc[0] else "azalan"
                        }
                        
                        # Hareketli ortalama hesapla
                        window_size = params.get('window_size', 3)
                        ts_data_ma = ts_data.rolling(window=window_size).mean()
                        
                        # Mevsimsellik kontrolü
                        if len(ts_data) >= 12:
                            # Otokorelasyon hesapla
                            autocorr = [ts_data.autocorr(lag=i) for i in range(1, 13)]
                            ts_stats["autocorrelation"] = {f"lag_{i}": autocorr[i-1] for i in range(1, 13)}
                            
                            # Mevsimsellik skoru (basit yaklaşım)
                            seasonality_score = max(autocorr)
                            ts_stats["seasonality_score"] = seasonality_score
                            ts_stats["has_seasonality"] = seasonality_score > 0.5
                        
                        results[sheet_name] = ts_stats
                        
                        # Zaman serisi grafiği
                        plt.figure(figsize=(12, 6))
                        plt.plot(ts_data.index, ts_data.values, label='Orijinal Veri')
                        plt.plot(ts_data_ma.index, ts_data_ma.values, label=f'{window_size} Dönem Hareketli Ortalama', linestyle='--')
                        plt.title(f"{sheet_name} - {value_column} Zaman Serisi Analizi")
                        plt.xlabel('Tarih')
                        plt.ylabel(value_column)
                        plt.legend()
                        plt.grid(True)
                        
                        # Figürü kaydet
                        buf = BytesIO()
                        plt.savefig(buf, format='png', bbox_inches='tight')
                        buf.seek(0)
                        figures[f"{sheet_name}_time_series"] = buf
                        plt.close()
                    else:
                        # Tüm sayısal sütunlar için zaman serisi analizi
                        numeric_cols = df_analysis.select_dtypes(include=['number']).columns.tolist()
                        if not numeric_cols:
                            results[sheet_name] = {"error": "Zaman serisi analizi için sayısal sütun bulunamadı"}
                            continue
                            
                        ts_results = {}
                        for col in numeric_cols:
                            ts_data = df_analysis.set_index(date_column)[col]
                            ts_results[col] = {
                                "mean": ts_data.mean(),
                                "std": ts_data.std(),
                                "min": ts_data.min(),
                                "max": ts_data.max(),
                                "trend": "artan" if ts_data.iloc[-1] > ts_data.iloc[0] else "azalan"
                            }
                        
                        results[sheet_name] = ts_results
                        
                        # Çoklu zaman serisi grafiği
                        plt.figure(figsize=(12, 6))
                        for col in numeric_cols[:5]:  # En fazla 5 sütun göster
                            plt.plot(df_analysis[date_column], df_analysis[col], label=col)
                        plt.title(f"{sheet_name} - Çoklu Zaman Serisi Analizi")
                        plt.xlabel('Tarih')
                        plt.ylabel('Değer')
                        plt.legend()
                        plt.grid(True)
                        
                        # Figürü kaydet
                        buf = BytesIO()
                        plt.savefig(buf, format='png', bbox_inches='tight')
                        buf.seek(0)
                        figures[f"{sheet_name}_multi_time_series"] = buf
                        plt.close()
                        
                elif analysis_type == "regression":
                    # Regresyon analizi için parametreleri kontrol et
                    if not params or 'dependent_var' not in params or 'independent_vars' not in params:
                        results[sheet_name] = {"error": "Regresyon analizi için bağımlı ve bağımsız değişkenler belirtilmeli"}
                        continue
                        
                    dependent_var = params['dependent_var']
                    independent_vars = params['independent_vars']
                    
                    # Değişkenleri kontrol et
                    if dependent_var not in df_analysis.columns:
                        results[sheet_name] = {"error": f"Bağımlı değişken '{dependent_var}' bulunamadı"}
                        continue
                        
                    valid_ind_vars = [var for var in independent_vars if var in df_analysis.columns]
                    if not valid_ind_vars:
                        results[sheet_name] = {"error": "Geçerli bağımsız değişken bulunamadı"}
                        continue
                    
                    # Eksik değerleri temizle
                    reg_cols = [dependent_var] + valid_ind_vars
                    df_reg = df_analysis[reg_cols].dropna()
                    
                    if len(df_reg) < 2:
                        results[sheet_name] = {"error": "Regresyon analizi için yeterli veri yok"}
                        continue
                    
                    try:
                        # Statsmodels ile regresyon analizi
                        import statsmodels.api as sm
                        
                        # Bağımsız değişkenlere sabit ekle
                        X = sm.add_constant(df_reg[valid_ind_vars])
                        y = df_reg[dependent_var]
                        
                        # Model oluştur ve eğit
                        model = sm.OLS(y, X).fit()
                        
                        # Sonuçları kaydet
                        reg_results = {
                            "r_squared": model.rsquared,
                            "adj_r_squared": model.rsquared_adj,
                            "f_statistic": model.fvalue,
                            "f_pvalue": model.f_pvalue,
                            "coefficients": model.params.to_dict(),
                            "p_values": model.pvalues.to_dict(),
                            "confidence_intervals": model.conf_int().to_dict(),
                            "summary": str(model.summary())
                        }
                        
                        results[sheet_name] = reg_results
                        
                        # Gerçek vs Tahmin grafiği
                        plt.figure(figsize=(10, 6))
                        plt.scatter(y, model.predict(), alpha=0.5)
                        plt.plot([y.min(), y.max()], [y.min(), y.max()], 'k--')
                        plt.xlabel('Gerçek Değerler')
                        plt.ylabel('Tahmin Edilen Değerler')
                        plt.title(f"{sheet_name} - Regresyon Analizi: {dependent_var}")
                        
                        # Figürü kaydet
                        buf = BytesIO()
                        plt.savefig(buf, format='png', bbox_inches='tight')
                        buf.seek(0)
                        figures[f"{sheet_name}_regression_fit"] = buf
                        plt.close()
                        
                        # Artık değerler grafiği
                        plt.figure(figsize=(10, 6))
                        plt.scatter(model.predict(), model.resid, alpha=0.5)
                        plt.axhline(y=0, color='k', linestyle='--')
                        plt.xlabel('Tahmin Edilen Değerler')
                        plt.ylabel('Artık Değerler')
                        plt.title(f"{sheet_name} - Regresyon Artık Değerleri")
                        
                        # Figürü kaydet
                        buf = BytesIO()
                        plt.savefig(buf, format='png', bbox_inches='tight')
                        buf.seek(0)
                        figures[f"{sheet_name}_regression_residuals"] = buf
                        plt.close()
                        
                    except Exception as e:
                        results[sheet_name] = {"error": f"Regresyon analizi sırasında hata: {str(e)}"}
                        
                # Görselleştirme kodu ayrı bir modüle taşındı
            
            # Sonuçları Excel'e kaydet
            if output_file:
                with pd.ExcelWriter(output_file) as writer:
                    for sheet_name, result in results.items():
                        # Sonuçları DataFrame'e dönüştür
                        if isinstance(result, dict):
                            if "error" in result:
                                pd.DataFrame({"Error": [result["error"]]}).to_excel(writer, sheet_name=sheet_name, index=False)
                            else:
                                # Farklı analiz tipleri için farklı DataFrame yapıları
                                if analysis_type == "descriptive":
                                    dfs_to_write = {}
                                    for col, stats in result.items():
                                        df_stats = pd.DataFrame(stats, index=[0]).T
                                        df_stats.columns = [col]
                                        dfs_to_write[col] = df_stats
                                    
                                    # Tüm sütunları birleştir
                                    df_combined = pd.concat(dfs_to_write.values(), axis=1)
                                    df_combined.to_excel(writer, sheet_name=sheet_name)
                                
                                elif analysis_type == "correlation":
                                    # Korelasyon matrisini DataFrame'e dönüştür
                                    df_corr = pd.DataFrame(result)
                                    df_corr.to_excel(writer, sheet_name=sheet_name)
                                
                                elif analysis_type == "summary":
                                    # Özet bilgileri DataFrame'e dönüştür
                                    df_summary = pd.DataFrame({
                                        "Metrik": ["Satır Sayısı", "Sütun Sayısı"],
                                        "Değer": [result["row_count"], result["column_count"]]
                                    })
                                    df_summary.to_excel(writer, sheet_name=f"{sheet_name}_Özet", index=False)
                                    
                                    # Eksik değerler
                                    df_missing = pd.DataFrame({
                                        "Sütun": list(result["missing_values"].keys()),
                                        "Eksik Değer Sayısı": list(result["missing_values"].values())
                                    })
                                    df_missing.to_excel(writer, sheet_name=f"{sheet_name}_Eksik", index=False)
                                    
                                    # Veri tipleri
                                    df_types = pd.DataFrame({
                                        "Sütun": list(result["data_types"].keys()),
                                        "Veri Tipi": list(result["data_types"].values())
                                    })
                                    df_types.to_excel(writer, sheet_name=f"{sheet_name}_Tipler", index=False)
                
                return True, "Analiz sonuçları başarıyla kaydedildi.", results
            
            return True, "Analiz başarıyla tamamlandı.", results
        
        except Exception as e:
            return False, f"Hata: {str(e)}", None