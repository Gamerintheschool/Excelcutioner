import os
import sys
import json
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel,
                             QFileDialog, QListWidget, QHBoxLayout, QMessageBox,
                             QLineEdit, QFormLayout, QGroupBox, QApplication, QComboBox,
                             QCheckBox, QListWidgetItem)
from .excel_bridge import ExcelBridge
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class ExcelAnalyzerWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.input_file = ""
        self.output_file = ""
        self.selected_columns = []
        self.initUI()
        
    def initUI(self):
        # Ana pencere ayarları
        self.setWindowTitle('Excel Veri Analizi')
        self.setMinimumSize(700, 600)
        
        # Ana widget ve layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Başlık
        title_label = QLabel('Excel Veri Analizi')
        title_font = QFont('Arial', 18, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Dosya seçim bölümü
        file_group = QGroupBox("Dosya Seçimi")
        file_layout = QVBoxLayout()
        
        # Dosya seçim butonu
        self.select_file_button = QPushButton('Excel Dosyası Seç')
        self.select_file_button.clicked.connect(self.select_file)
        file_layout.addWidget(self.select_file_button)
        
        # Seçilen dosyayı göster
        self.file_path = QLineEdit()
        self.file_path.setReadOnly(True)
        self.file_path.setPlaceholderText("Dosya seçilmedi")
        file_layout.addWidget(self.file_path)
        
        file_group.setLayout(file_layout)
        main_layout.addWidget(file_group)
        
        # Analiz seçenekleri bölümü
        analysis_group = QGroupBox("Analiz Seçenekleri")
        analysis_layout = QVBoxLayout()
        
        # Analiz tipi seçimi
        analysis_type_layout = QFormLayout()
        self.analysis_type = QComboBox()
        self.analysis_type.addItems(["Tanımlayıcı İstatistikler", "Korelasyon Analizi", "Veri Özeti", 
                                   "Zaman Serisi Analizi", "Regresyon Analizi"])
        analysis_type_layout.addRow("Analiz Tipi:", self.analysis_type)
        analysis_layout.addLayout(analysis_type_layout)
        
        # Analiz tipi değiştiğinde UI'ı güncelle
        self.analysis_type.currentIndexChanged.connect(self.update_analysis_options)
        
        # Sütun seçimi bölümü
        column_group = QGroupBox("Sütun Seçimi")
        column_layout = QVBoxLayout()
        
        self.column_list = QListWidget()
        self.column_list.setSelectionMode(QListWidget.MultiSelection)
        column_layout.addWidget(self.column_list)
        
        column_group.setLayout(column_layout)
        analysis_layout.addWidget(column_group)
        
        analysis_group.setLayout(analysis_layout)
        main_layout.addWidget(analysis_group)
        
        # Çıktı dosyası seçim bölümü
        output_group = QGroupBox("Çıktı Dosyası")
        output_layout = QFormLayout()
        
        self.output_path = QLineEdit()
        self.output_path.setReadOnly(True)
        self.output_path.setPlaceholderText("Çıktı dosyası seçilmedi")
        
        output_button_layout = QHBoxLayout()
        self.select_output_button = QPushButton('Çıktı Dosyası Seç')
        self.select_output_button.clicked.connect(self.select_output)
        output_button_layout.addWidget(self.output_path)
        output_button_layout.addWidget(self.select_output_button)
        
        output_layout.addRow(output_button_layout)
        output_group.setLayout(output_layout)
        main_layout.addWidget(output_group)
        
        # Analiz butonu
        self.analyze_button = QPushButton('Analiz Et')
        self.analyze_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
            }
        """)
        self.analyze_button.clicked.connect(self.analyze_data)
        self.analyze_button.setEnabled(False)
        main_layout.addWidget(self.analyze_button)
    
    def select_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Excel Dosyası Seç", "", "Excel Dosyaları (*.xlsx *.xls)")
        
        if file_path:
            self.input_file = file_path
            self.file_path.setText(file_path)
            self.load_columns()
            self.check_analyze_button()
    
    def load_columns(self):
        try:
            # Excel dosyasını oku ve sütunları al
            import pandas as pd
            df = pd.read_excel(self.input_file, sheet_name=0)  # İlk sayfayı oku
            
            # Sütun listesini temizle ve yeni sütunları ekle
            self.column_list.clear()
            for column in df.columns:
                self.column_list.addItem(column)
        
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Sütunlar yüklenirken hata oluştu: {str(e)}")
    
    def select_output(self):
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Çıktı Dosyasını Seç", "", "Excel Dosyaları (*.xlsx)")
        
        if file_path:
            # Dosya uzantısını kontrol et ve gerekirse ekle
            if not file_path.endswith('.xlsx'):
                file_path += '.xlsx'
            
            self.output_file = file_path
            self.output_path.setText(file_path)
            self.check_analyze_button()
    
    def check_analyze_button(self):
        # Analiz butonu için gerekli koşulları kontrol et
        if self.input_file and self.output_file:
            self.analyze_button.setEnabled(True)
        else:
            self.analyze_button.setEnabled(False)
    
    def update_analysis_options(self):
        """Seçilen analiz tipine göre UI'ı güncelle"""
        current_analysis = self.analysis_type.currentText()
        
        # Zaman serisi analizi için ek seçenekler göster
        if "Zaman Serisi" in current_analysis:
            # Eğer daha önce oluşturulmadıysa, zaman serisi seçeneklerini ekle
            if not hasattr(self, 'time_series_options'):
                self.time_series_options = QGroupBox("Zaman Serisi Seçenekleri")
                ts_layout = QFormLayout()
                
                self.date_column = QComboBox()
                ts_layout.addRow("Tarih Sütunu:", self.date_column)
                
                self.time_series_options.setLayout(ts_layout)
                
                # Analiz seçenekleri bölümüne ekle
                analysis_group = self.findChild(QGroupBox, "Analiz Seçenekleri")
                if analysis_group and analysis_group.layout():
                    analysis_group.layout().addWidget(self.time_series_options)
            
            self.time_series_options.setVisible(True)
        else:
            # Zaman serisi seçeneklerini gizle
            if hasattr(self, 'time_series_options'):
                self.time_series_options.setVisible(False)
        
        # Regresyon analizi için ek seçenekler göster
        if "Regresyon" in current_analysis:
            # Eğer daha önce oluşturulmadıysa, regresyon seçeneklerini ekle
            if not hasattr(self, 'regression_options'):
                self.regression_options = QGroupBox("Regresyon Seçenekleri")
                reg_layout = QFormLayout()
                
                self.dependent_var = QComboBox()
                reg_layout.addRow("Bağımlı Değişken:", self.dependent_var)
                
                self.regression_options.setLayout(reg_layout)
                
                # Analiz seçenekleri bölümüne ekle
                analysis_group = self.findChild(QGroupBox, "Analiz Seçenekleri")
                if analysis_group and analysis_group.layout():
                    analysis_group.layout().addWidget(self.regression_options)
            
            self.regression_options.setVisible(True)
        else:
            # Regresyon seçeneklerini gizle
            if hasattr(self, 'regression_options'):
                self.regression_options.setVisible(False)
        
        # Görselleştirme seçenekleri kaldırıldı - ayrı bir modül olarak taşındı
        
        # Sütunlar yüklendiyse, combobox'ları güncelle
        if self.column_list.count() > 0:
            self.update_column_dropdowns()
    
    def update_column_dropdowns(self):
        """Sütun listesine göre dropdown'ları güncelle"""
        # Mevcut sütunları al
        columns = [self.column_list.item(i).text() for i in range(self.column_list.count())]
        
        # Tarih sütunu dropdown'ını güncelle
        if hasattr(self, 'date_column'):
            current_text = self.date_column.currentText()
            self.date_column.clear()
            self.date_column.addItems(columns)
            # Önceki seçimi koru
            index = self.date_column.findText(current_text)
            if index >= 0:
                self.date_column.setCurrentIndex(index)
        
        # Bağımlı değişken dropdown'ını güncelle
        if hasattr(self, 'dependent_var'):
            current_text = self.dependent_var.currentText()
            self.dependent_var.clear()
            self.dependent_var.addItems(columns)
            # Önceki seçimi koru
            index = self.dependent_var.findText(current_text)
            if index >= 0:
                self.dependent_var.setCurrentIndex(index)
        
        # X ve Y ekseni dropdown'ları görselleştirme modülüne taşındı
    
    def analyze_data(self):
        # Seçilen sütunları al
        selected_columns = [self.column_list.item(i).text() for i in range(self.column_list.count()) 
                           if self.column_list.item(i).isSelected()]
        self.selected_columns = selected_columns
        
        # Analiz tipini belirle
        analysis_type_text = self.analysis_type.currentText()
        analysis_type_map = {
            "Tanımlayıcı İstatistikler": "descriptive",
            "Korelasyon Analizi": "correlation",
            "Veri Özeti": "summary",
            "Zaman Serisi Analizi": "time_series",
            "Regresyon Analizi": "regression"
        }
        
        analysis_type = analysis_type_map.get(analysis_type_text, "descriptive")
        
        # Analiz parametrelerini hazırla
        params = {}
        
        # Zaman serisi analizi için parametreler
        if analysis_type == "time_series" and hasattr(self, 'date_column'):
            params['date_column'] = self.date_column.currentText()
        
        # Regresyon analizi için parametreler
        if analysis_type == "regression" and hasattr(self, 'dependent_var'):
            params['dependent_var'] = self.dependent_var.currentText()
        
        # Görselleştirme parametreleri ayrı modüle taşındı
        
        try:
            # Analizi gerçekleştir
            bridge = ExcelBridge()
            success, message, results = bridge.analyze_excel(
                self.input_file, analysis_type, selected_columns, self.output_file, params=params)
            
            if success:
                QMessageBox.information(self, "Başarılı", message)
            else:
                QMessageBox.critical(self, "Hata", message)
        
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Analiz sırasında hata oluştu: {str(e)}")

# Test için
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ExcelAnalyzerWindow()
    window.show()
    sys.exit(app.exec_())