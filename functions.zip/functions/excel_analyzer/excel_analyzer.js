// Excel Veri Analizi JavaScript

let excelFile = null;
let columns = [];
let selectedColumns = [];
let analysisType = null;
let analysisResults = null;

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', function() {
    // Dosya seçimi değiştiğinde
    document.getElementById('excel-file').addEventListener('change', handleFileSelect);
});

// Dosya seçimi işlemi
function handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    excelFile = file;
    document.getElementById('file-info').textContent = `Seçilen dosya: ${file.name}`;
    
    // Dosya içeriğini oku ve sütunları çıkar
    readExcelFile(file, function(sheets) {
        // İlk sayfadaki sütunları al
        if (sheets && sheets.length > 0) {
            const firstSheet = sheets[0];
            columns = firstSheet.columns;
            
            // Sütunları listele
            displayColumns(columns);
            
            // Analiz seçeneklerini göster
            document.getElementById('analysis-options').style.display = 'block';
            document.getElementById('column-selection').style.display = 'block';
        }
    });
}

// Excel dosyasını oku
function readExcelFile(file, callback) {
    const reader = new FileReader();
    
    reader.onload = function(e) {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, {type: 'array'});
        
        const sheets = [];
        
        // Her sayfayı işle
        workbook.SheetNames.forEach(function(sheetName) {
            const worksheet = workbook.Sheets[sheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet, {header: 1});
            
            if (jsonData.length > 0) {
                const columns = jsonData[0];
                sheets.push({
                    name: sheetName,
                    columns: columns
                });
            }
        });
        
        callback(sheets);
    };
    
    reader.readAsArrayBuffer(file);
}

// Sütunları görüntüle
function displayColumns(columns) {
    const columnsList = document.getElementById('columns-list');
    columnsList.innerHTML = '';
    
    columns.forEach(function(column, index) {
        const columnItem = document.createElement('div');
        columnItem.className = 'file-item';
        
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `column-${index}`;
        checkbox.value = column;
        checkbox.addEventListener('change', function() {
            updateSelectedColumns();
        });
        
        const label = document.createElement('label');
        label.htmlFor = `column-${index}`;
        label.textContent = column;
        
        columnItem.appendChild(checkbox);
        columnItem.appendChild(label);
        columnsList.appendChild(columnItem);
    });
    
    // Analiz butonunu göster
    document.getElementById('analyze-section').style.display = 'block';
    
    // Dropdown'ları güncelle
    updateDropdowns(columns);
}

// Dropdown'ları güncelle
function updateDropdowns(columns) {
    // Tarih sütunu dropdown'ını güncelle
    const dateColumn = document.getElementById('date_column');
    if (dateColumn) {
        dateColumn.innerHTML = '';
        columns.forEach(function(column) {
            const option = document.createElement('option');
            option.value = column;
            option.textContent = column;
            dateColumn.appendChild(option);
        });
    }
    
    // Bağımlı değişken dropdown'ını güncelle
    const dependentVar = document.getElementById('dependent_var');
    if (dependentVar) {
        dependentVar.innerHTML = '';
        columns.forEach(function(column) {
            const option = document.createElement('option');
            option.value = column;
            option.textContent = column;
            dependentVar.appendChild(option);
        });
    }
    
    // X ve Y ekseni dropdown'larını güncelle
    const xAxis = document.getElementById('x_axis');
    if (xAxis) {
        xAxis.innerHTML = '';
        columns.forEach(function(column) {
            const option = document.createElement('option');
            option.value = column;
            option.textContent = column;
            xAxis.appendChild(option);
        });
    }
    
    const yAxis = document.getElementById('y_axis');
    if (yAxis) {
        yAxis.innerHTML = '';
        columns.forEach(function(column) {
            const option = document.createElement('option');
            option.value = column;
            option.textContent = column;
            yAxis.appendChild(option);
        });
    }
}

// Tüm sütunları seç
function selectAllColumns() {
    const checkboxes = document.querySelectorAll('#columns-list input[type="checkbox"]');
    checkboxes.forEach(function(checkbox) {
        checkbox.checked = true;
    });
    updateSelectedColumns();
}

// Tüm sütunların seçimini kaldır
function deselectAllColumns() {
    const checkboxes = document.querySelectorAll('#columns-list input[type="checkbox"]');
    checkboxes.forEach(function(checkbox) {
        checkbox.checked = false;
    });
    updateSelectedColumns();
}

// Seçili sütunları güncelle
function updateSelectedColumns() {
    selectedColumns = [];
    const checkboxes = document.querySelectorAll('#columns-list input[type="checkbox"]:checked');
    checkboxes.forEach(function(checkbox) {
        selectedColumns.push(checkbox.value);
    });
}

// Analiz tipini seç
function selectAnalysisType(element) {
    // Önceki seçimi kaldır
    const options = document.querySelectorAll('.analysis-option');
    options.forEach(function(option) {
        option.classList.remove('selected');
    });
    
    // Yeni seçimi işaretle
    element.classList.add('selected');
    analysisType = element.getAttribute('data-type');
    
    // Analiz tipine özel seçenekleri göster/gizle
    document.querySelectorAll('.analysis-specific-options').forEach(option => {
        option.style.display = 'none';
    });
    
    if (analysisType === 'time_series') {
        document.getElementById('time_series_options').style.display = 'block';
    } else if (analysisType === 'regression') {
        document.getElementById('regression_options').style.display = 'block';
    } else if (analysisType === 'visualization') {
        document.getElementById('visualization_options').style.display = 'block';
    }
}

// Veriyi analiz et
function analyzeData() {
    if (!excelFile || !analysisType) {
        alert('Lütfen bir dosya ve analiz tipi seçin.');
        return;
    }
    
    // İlerleme bölümünü göster
    document.getElementById('progress-section').style.display = 'block';
    document.getElementById('status').textContent = 'Analiz yapılıyor...';
    document.getElementById('progress-bar').style.width = '50%';
    
    // Dosyayı Base64'e dönüştür
    const reader = new FileReader();
    reader.onload = function(e) {
        const base64data = e.target.result.split(',')[1];
        
        // Analiz parametrelerini hazırla
        let analysisParams = {
            action: 'analyze',
            file_data: base64data,
            analysis_type: analysisType,
            selected_columns: selectedColumns
        };
        
        // Zaman serisi analizi için parametreler
        if (analysisType === 'time_series') {
            const dateColumn = document.getElementById('date_column');
            if (dateColumn && dateColumn.value) {
                analysisParams.date_column = dateColumn.value;
            }
        }
        
        // Regresyon analizi için parametreler
        if (analysisType === 'regression') {
            const dependentVar = document.getElementById('dependent_var');
            if (dependentVar && dependentVar.value) {
                analysisParams.dependent_var = dependentVar.value;
            }
        }
        
        // Görselleştirme için parametreler
        if (analysisType === 'visualization') {
            const chartType = document.getElementById('chart_type');
            if (chartType && chartType.value) {
                analysisParams.chart_type = chartType.value;
            }
            
            const xAxis = document.getElementById('x_axis');
            if (xAxis && xAxis.value) {
                analysisParams.x_column = xAxis.value;
            }
            
            const yAxis = document.getElementById('y_axis');
            if (yAxis && yAxis.value) {
                analysisParams.y_column = yAxis.value;
            }
        }
        
        // Python tarafına gönder
        sendToPython(analysisParams);
    };
    reader.readAsDataURL(excelFile);
}

// Python'a veri gönder
function sendToPython(data) {
    // Bu fonksiyon PyQt tarafından enjekte edilecek
    if (window.pywebview) {
        window.pywebview.api.process_data(JSON.stringify(data));
    } else {
        console.error('PyWebView API bulunamadı');
    }
}

// Python'dan gelen yanıtı işle
function handlePythonResponse(response) {
    try {
        const result = JSON.parse(response);
        
        if (result.status === 'success') {
            // İlerleme çubuğunu güncelle
            document.getElementById('progress-bar').style.width = '100%';
            document.getElementById('status').textContent = 'Analiz tamamlandı!';
            
            // Sonuçları göster
            analysisResults = result.data;
            displayResults(analysisResults);
            
            // Sonuç bölümünü göster
            document.getElementById('result-section').style.display = 'block';
        } else {
            document.getElementById('status').textContent = `Hata: ${result.message}`;
        }
    } catch (e) {
        console.error('Yanıt işlenirken hata oluştu:', e);
        document.getElementById('status').textContent = 'Yanıt işlenirken hata oluştu';
    }
}

// Sonuçları görüntüle
function displayResults(results) {
    const resultContainer = document.getElementById('result-container');
    resultContainer.innerHTML = '';
    
    // Her sayfa için sonuçları göster
    for (const sheetName in results) {
        const sheetResult = results[sheetName];
        
        const sheetTitle = document.createElement('div');
        sheetTitle.className = 'result-title';
        sheetTitle.textContent = `Sayfa: ${sheetName}`;
        resultContainer.appendChild(sheetTitle);
        
        if (sheetResult.error) {
            const errorItem = document.createElement('div');
            errorItem.className = 'result-item';
            errorItem.textContent = sheetResult.error;
            resultContainer.appendChild(errorItem);
            continue;
        }
        
        // Analiz tipine göre sonuçları göster
        if (analysisType === 'descriptive') {
            displayDescriptiveStats(sheetResult, resultContainer);
        } else if (analysisType === 'correlation') {
            displayCorrelationMatrix(sheetResult, resultContainer);
        } else if (analysisType === 'summary') {
            displaySummary(sheetResult, resultContainer);
        } else if (analysisType === 'time_series') {
            displayTimeSeriesAnalysis(sheetResult, resultContainer);
        } else if (analysisType === 'regression') {
            displayRegressionAnalysis(sheetResult, resultContainer);
        } else if (analysisType === 'visualization') {
            displayVisualizationResults(sheetResult, resultContainer);
        }
    }
}

// Tanımlayıcı istatistikleri görüntüle
function displayDescriptiveStats(stats, container) {
    for (const column in stats) {
        const columnStats = stats[column];
        
        const columnTitle = document.createElement('div');
        columnTitle.className = 'result-title';
        columnTitle.textContent = `Sütun: ${column}`;
        container.appendChild(columnTitle);
        
        const statsTable = document.createElement('table');
        statsTable.style.width = '100%';
        statsTable.style.borderCollapse = 'collapse';
        statsTable.style.marginBottom = '20px';
        
        // Tablo başlığı
        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');
        const metrics = ['count', 'mean', 'std', 'min', '25%', '50%', '75%', 'max'];
        
        const headerCell = document.createElement('th');
        headerCell.textContent = 'Metrik';
        headerCell.style.border = '1px solid #ddd';
        headerCell.style.padding = '8px';
        headerCell.style.textAlign = 'left';
        headerRow.appendChild(headerCell);
        
        const valueCell = document.createElement('th');
        valueCell.textContent = 'Değer';
        valueCell.style.border = '1px solid #ddd';
        valueCell.style.padding = '8px';
        valueCell.style.textAlign = 'left';
        headerRow.appendChild(valueCell);
        
        thead.appendChild(headerRow);
        statsTable.appendChild(thead);
        
        // Tablo içeriği
        const tbody = document.createElement('tbody');
        
        metrics.forEach(function(metric) {
            if (columnStats[metric] !== undefined) {
                const row = document.createElement('tr');
                
                const metricCell = document.createElement('td');
                metricCell.textContent = metric;
                metricCell.style.border = '1px solid #ddd';
                metricCell.style.padding = '8px';
                row.appendChild(metricCell);
                
                const valueCell = document.createElement('td');
                valueCell.textContent = typeof columnStats[metric] === 'number' ? 
                    columnStats[metric].toFixed(4) : columnStats[metric];
                valueCell.style.border = '1px solid #ddd';
                valueCell.style.padding = '8px';
                row.appendChild(valueCell);
                
                tbody.appendChild(row);
            }
        });
        
        statsTable.appendChild(tbody);
        container.appendChild(statsTable);
    }
}

// Korelasyon matrisini görüntüle
function displayCorrelationMatrix(correlations, container) {
    const columns = Object.keys(correlations);
    
    const matrixTable = document.createElement('table');
    matrixTable.style.width = '100%';
    matrixTable.style.borderCollapse = 'collapse';
    matrixTable.style.marginBottom = '20px';
    
    // Tablo başlığı
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    
    const emptyCell = document.createElement('th');
    emptyCell.style.border = '1px solid #ddd';
    emptyCell.style.padding = '8px';
    headerRow.appendChild(emptyCell);
    
    columns.forEach(function(column) {
        const headerCell = document.createElement('th');
        headerCell.textContent = column;
        headerCell.style.border = '1px solid #ddd';
        headerCell.style.padding = '8px';
        headerCell.style.textAlign = 'center';
        headerRow.appendChild(headerCell);
    });
    
    thead.appendChild(headerRow);
    matrixTable.appendChild(thead);
    
    // Tablo içeriği
    const tbody = document.createElement('tbody');
    
    columns.forEach(function(rowColumn) {
        const row = document.createElement('tr');
        
        const rowHeader = document.createElement('th');
        rowHeader.textContent = rowColumn;
        rowHeader.style.border = '1px solid #ddd';
        rowHeader.style.padding = '8px';
        rowHeader.style.textAlign = 'left';
        row.appendChild(rowHeader);
        
        columns.forEach(function(colColumn) {
            const cell = document.createElement('td');
            const value = correlations[rowColumn][colColumn];
            cell.textContent = typeof value === 'number' ? value.toFixed(4) : value;
            
            // Korelasyon değerine göre renklendirme
            if (typeof value === 'number') {
                const intensity = Math.abs(value) * 100;
                if (value > 0) {
                    cell.style.backgroundColor = `rgba(0, 128, 0, ${intensity/100})`;
                } else if (value < 0) {
                    cell.style.backgroundColor = `rgba(255, 0, 0, ${intensity/100})`;
                }
            }
            
            cell.style.border = '1px solid #ddd';
            cell.style.padding = '8px';
            cell.style.textAlign = 'center';
            row.appendChild(cell);
        });
        
        tbody.appendChild(row);
    });
    
    matrixTable.appendChild(tbody);
    container.appendChild(matrixTable);
}

// Veri özetini görüntüle
function displaySummary(summary, container) {
    // Genel bilgiler
    const generalInfo = document.createElement('div');
    generalInfo.innerHTML = `
        <p><strong>Satır Sayısı:</strong> ${summary.row_count}</p>
        <p><strong>Sütun Sayısı:</strong> ${summary.column_count}</p>
    `;
    container.appendChild(generalInfo);
    
    // Eksik değerler
    const missingTitle = document.createElement('div');
    missingTitle.className = 'result-title';
    missingTitle.textContent = 'Eksik Değerler';
    container.appendChild(missingTitle);
    
    const missingTable = document.createElement('table');
    missingTable.style.width = '100%';
    missingTable.style.borderCollapse = 'collapse';
    missingTable.style.marginBottom = '20px';
    
    // Tablo başlığı
    const missingThead = document.createElement('thead');
    const missingHeaderRow = document.createElement('tr');
    
    const columnHeader = document.createElement('th');
    columnHeader.textContent = 'Sütun';
    columnHeader.style.border = '1px solid #ddd';
    columnHeader.style.padding = '8px';
    columnHeader.style.textAlign = 'left';
    missingHeaderRow.appendChild(columnHeader);
    
    const countHeader = document.createElement('th');
    countHeader.textContent = 'Eksik Değer Sayısı';
    countHeader.style.border = '1px solid #ddd';
    countHeader.style.padding = '8px';
    countHeader.style.textAlign = 'left';
    missingHeaderRow.appendChild(countHeader);
    
    missingThead.appendChild(missingHeaderRow);
    missingTable.appendChild(missingThead);
    
    // Tablo içeriği
    const missingTbody = document.createElement('tbody');
    
    for (const column in summary.missing_values) {
        const row = document.createElement('tr');
        
        const columnCell = document.createElement('td');
        columnCell.textContent = column;
        columnCell.style.border = '1px solid #ddd';
        columnCell.style.padding = '8px';
        row.appendChild(columnCell);
        
        const countCell = document.createElement('td');
        countCell.textContent = summary.missing_values[column];
        countCell.style.border = '1px solid #ddd';
        countCell.style.padding = '8px';
        row.appendChild(countCell);
        
        missingTbody.appendChild(row);
    }
    
    missingTable.appendChild(missingTbody);
    container.appendChild(missingTable);
    
    // Veri tipleri
    const typesTitle = document.createElement('div');
    typesTitle.className = 'result-title';
    typesTitle.textContent = 'Veri Tipleri';
    container.appendChild(typesTitle);
    
    const typesTable = document.createElement('table');
    typesTable.style.width = '100%';
    typesTable.style.borderCollapse = 'collapse';
    typesTable.style.marginBottom = '20px';
    
    // Tablo başlığı
    const typesThead = document.createElement('thead');
    const typesHeaderRow = document.createElement('tr');
    
    const typeColumnHeader = document.createElement('th');
    typeColumnHeader.textContent = 'Sütun';
    typeColumnHeader.style.border = '1px solid #ddd';
    typeColumnHeader.style.padding = '8px';
    typeColumnHeader.style.textAlign = 'left';
    typesHeaderRow.appendChild(typeColumnHeader);
    
    const typeHeader = document.createElement('th');
    typeHeader.textContent = 'Veri Tipi';
    typeHeader.style.border = '1px solid #ddd';
    typeHeader.style.padding = '8px';
    typeHeader.style.textAlign = 'left';
    typesHeaderRow.appendChild(typeHeader);
    
    typesThead.appendChild(typesHeaderRow);
    typesTable.appendChild(typesThead);
    
    // Tablo içeriği
    const typesTbody = document.createElement('tbody');
    
    for (const column in summary.data_types) {
        const row = document.createElement('tr');
        
        const columnCell = document.createElement('td');
        columnCell.textContent = column;
        columnCell.style.border = '1px solid #ddd';
        columnCell.style.padding = '8px';
        row.appendChild(columnCell);
        
        const typeCell = document.createElement('td');
        typeCell.textContent = summary.data_types[column];
        typeCell.style.border = '1px solid #ddd';
        typeCell.style.padding = '8px';
        row.appendChild(typeCell);
        
        typesTbody.appendChild(row);
    }
    
    typesTable.appendChild(typesTbody);
    container.appendChild(typesTable);
}

// Sonuçları indir
function downloadResults() {
    if (!analysisResults) return;
    
    // Python'a indir komutu gönder
    sendToPython({
        action: 'download',
        results: analysisResults,
        analysis_type: analysisType
    });
}

// Zaman serisi analiz sonuçlarını görüntüle
function displayTimeSeriesAnalysis(results, container) {
    // Sonuç bilgilerini göster
    const infoDiv = document.createElement('div');
    infoDiv.className = 'result-info';
    
    if (results.trend_analysis) {
        const trendTitle = document.createElement('h3');
        trendTitle.textContent = 'Trend Analizi';
        infoDiv.appendChild(trendTitle);
        
        for (const column in results.trend_analysis) {
            const trendInfo = document.createElement('p');
            trendInfo.innerHTML = `<strong>${column}:</strong> ${results.trend_analysis[column]}`;
            infoDiv.appendChild(trendInfo);
        }
    }
    
    if (results.seasonal_analysis) {
        const seasonalTitle = document.createElement('h3');
        seasonalTitle.textContent = 'Mevsimsellik Analizi';
        infoDiv.appendChild(seasonalTitle);
        
        for (const column in results.seasonal_analysis) {
            const seasonalInfo = document.createElement('p');
            seasonalInfo.innerHTML = `<strong>${column}:</strong> ${results.seasonal_analysis[column]}`;
            infoDiv.appendChild(seasonalInfo);
        }
    }
    
    container.appendChild(infoDiv);
    
    // Grafikler varsa göster
    if (results.figures) {
        const figuresDiv = document.createElement('div');
        figuresDiv.className = 'result-figures';
        
        for (const figName in results.figures) {
            const figureContainer = document.createElement('div');
            figureContainer.className = 'figure-container';
            
            const figureTitle = document.createElement('h4');
            figureTitle.textContent = figName;
            figureContainer.appendChild(figureTitle);
            
            const figure = document.createElement('img');
            figure.src = results.figures[figName];
            figure.alt = figName;
            figure.style.maxWidth = '100%';
            figureContainer.appendChild(figure);
            
            figuresDiv.appendChild(figureContainer);
        }
        
        container.appendChild(figuresDiv);
    }
}

// Regresyon analiz sonuçlarını görüntüle
function displayRegressionAnalysis(results, container) {
    // Model bilgilerini göster
    const modelDiv = document.createElement('div');
    modelDiv.className = 'result-model';
    
    if (results.model_summary) {
        const modelTitle = document.createElement('h3');
        modelTitle.textContent = 'Model Özeti';
        modelDiv.appendChild(modelTitle);
        
        const summaryPre = document.createElement('pre');
        summaryPre.textContent = results.model_summary;
        modelDiv.appendChild(summaryPre);
    }
    
    if (results.coefficients) {
        const coeffTitle = document.createElement('h3');
        coeffTitle.textContent = 'Katsayılar';
        modelDiv.appendChild(coeffTitle);
        
        const coeffTable = document.createElement('table');
        coeffTable.style.width = '100%';
        coeffTable.style.borderCollapse = 'collapse';
        
        // Tablo başlığı
        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');
        
        const varHeader = document.createElement('th');
        varHeader.textContent = 'Değişken';
        varHeader.style.border = '1px solid #ddd';
        varHeader.style.padding = '8px';
        headerRow.appendChild(varHeader);
        
        const coeffHeader = document.createElement('th');
        coeffHeader.textContent = 'Katsayı';
        coeffHeader.style.border = '1px solid #ddd';
        coeffHeader.style.padding = '8px';
        headerRow.appendChild(coeffHeader);
        
        thead.appendChild(headerRow);
        coeffTable.appendChild(thead);
        
        // Tablo içeriği
        const tbody = document.createElement('tbody');
        
        for (const variable in results.coefficients) {
            const row = document.createElement('tr');
            
            const varCell = document.createElement('td');
            varCell.textContent = variable;
            varCell.style.border = '1px solid #ddd';
            varCell.style.padding = '8px';
            row.appendChild(varCell);
            
            const coeffCell = document.createElement('td');
            coeffCell.textContent = results.coefficients[variable].toFixed(4);
            coeffCell.style.border = '1px solid #ddd';
            coeffCell.style.padding = '8px';
            row.appendChild(coeffCell);
            
            tbody.appendChild(row);
        }
        
        coeffTable.appendChild(tbody);
        modelDiv.appendChild(coeffTable);
    }
    
    container.appendChild(modelDiv);
    
    // Grafikler varsa göster
    if (results.figures) {
        const figuresDiv = document.createElement('div');
        figuresDiv.className = 'result-figures';
        
        for (const figName in results.figures) {
            const figureContainer = document.createElement('div');
            figureContainer.className = 'figure-container';
            
            const figureTitle = document.createElement('h4');
            figureTitle.textContent = figName;
            figureContainer.appendChild(figureTitle);
            
            const figure = document.createElement('img');
            figure.src = results.figures[figName];
            figure.alt = figName;
            figure.style.maxWidth = '100%';
            figureContainer.appendChild(figure);
            
            figuresDiv.appendChild(figureContainer);
        }
        
        container.appendChild(figuresDiv);
    }
}

// Görselleştirme sonuçlarını görüntüle
function displayVisualizationResults(results, container) {
    // Grafikler varsa göster
    if (results.figures) {
        const figuresDiv = document.createElement('div');
        figuresDiv.className = 'result-figures';
        
        for (const figName in results.figures) {
            const figureContainer = document.createElement('div');
            figureContainer.className = 'figure-container';
            
            const figureTitle = document.createElement('h4');
            figureTitle.textContent = figName;
            figureContainer.appendChild(figureTitle);
            
            const figure = document.createElement('img');
            figure.src = results.figures[figName];
            figure.alt = figName;
            figure.style.maxWidth = '100%';
            figureContainer.appendChild(figure);
            
            figuresDiv.appendChild(figureContainer);
        }
        
        container.appendChild(figuresDiv);
    } else {
        const noFigures = document.createElement('p');
        noFigures.textContent = 'Görselleştirme sonuçları bulunamadı.';
        container.appendChild(noFigures);
    }
}