import os
import base64
import pandas as pd
import numpy as np
import io
import openpyxl
from openpyxl.styles import PatternFill, Font
from openpyxl.utils import get_column_letter

class ExcelBridge:
    @staticmethod
    def save_excel_from_base64(base64_data, output_path):
        """
        Base64 formatındaki Excel verisini dosyaya kaydet
        """
        try:
            # Base64'ten binary'ye dönüştür
            binary_data = base64.b64decode(base64_data)
            
            # Dosyayı kaydet
            with open(output_path, 'wb') as f:
                f.write(binary_data)
            
            return True, f"Dosya başarıyla kaydedildi: {output_path}"
        except Exception as e:
            return False, f"Dosya kaydedilirken hata oluştu: {str(e)}"
    
    @staticmethod
    def compare_excel_files(file1_path, file2_path, comparison_options, output_path=None):
        """
        İki Excel dosyasını karşılaştır ve farklılıkları raporla
        
        Args:
            file1_path (str): İlk Excel dosyasının yolu
            file2_path (str): İkinci Excel dosyasının yolu
            comparison_options (dict): Karşılaştırma seçenekleri
            output_path (str, optional): Sonuçların kaydedileceği dosya yolu
            
        Returns:
            tuple: (başarı durumu, mesaj, sonuçlar, base64 formatında çıktı dosyası)
        """
        try:
            # Karşılaştırma seçeneklerini al
            sheet_names = comparison_options.get('sheet_names', [])
            ignore_formatting = comparison_options.get('ignore_formatting', True)
            ignore_case = comparison_options.get('ignore_case', False)
            ignore_spaces = comparison_options.get('ignore_spaces', False)
            ignore_empty_cells = comparison_options.get('ignore_empty_cells', False)
            compare_formulas = comparison_options.get('compare_formulas', False)
            
            # Excel dosyalarını oku
            excel1 = pd.ExcelFile(file1_path)
            excel2 = pd.ExcelFile(file2_path)
            
            # Karşılaştırma sonuçları
            results = {
                'summary': {
                    'total_differences': 0,
                    'sheets_compared': 0,
                    'sheets_identical': 0,
                    'sheets_different': 0
                },
                'sheets': {}
            }
            
            # Karşılaştırılacak sayfaları belirle
            if not sheet_names:
                # Tüm ortak sayfaları karşılaştır
                sheet_names = list(set(excel1.sheet_names).intersection(set(excel2.sheet_names)))
            else:
                # Belirtilen sayfaların her iki dosyada da olduğunu kontrol et
                for sheet in sheet_names:
                    if sheet not in excel1.sheet_names or sheet not in excel2.sheet_names:
                        return False, f"'{sheet}' sayfası her iki dosyada da bulunamadı", None, None
            
            # Çıktı için Excel dosyası oluştur
            if output_path:
                output_workbook = openpyxl.Workbook()
                # Varsayılan sayfayı sil
                output_workbook.remove(output_workbook.active)
            
            # Her sayfayı karşılaştır
            for sheet_name in sheet_names:
                # Sayfaları oku
                df1 = excel1.parse(sheet_name)
                df2 = excel2.parse(sheet_name)
                
                # Metin işleme seçenekleri
                if ignore_case:
                    # Metin sütunlarını küçük harfe dönüştür
                    for col in df1.select_dtypes(include=['object']).columns:
                        df1[col] = df1[col].astype(str).str.lower()
                    for col in df2.select_dtypes(include=['object']).columns:
                        df2[col] = df2[col].astype(str).str.lower()
                
                if ignore_spaces:
                    # Metin sütunlarındaki boşlukları kaldır
                    for col in df1.select_dtypes(include=['object']).columns:
                        df1[col] = df1[col].astype(str).str.strip()
                    for col in df2.select_dtypes(include=['object']).columns:
                        df2[col] = df2[col].astype(str).str.strip()
                
                if ignore_empty_cells:
                    # Boş hücreleri NaN ile değiştir ve karşılaştırmada yoksay
                    df1 = df1.replace('', np.nan)
                    df2 = df2.replace('', np.nan)
                
                # Sütun ve satır farklılıklarını kontrol et
                columns_only_in_df1 = set(df1.columns) - set(df2.columns)
                columns_only_in_df2 = set(df2.columns) - set(df1.columns)
                
                # Ortak sütunları bul
                common_columns = list(set(df1.columns).intersection(set(df2.columns)))
                
                # Ortak sütunlara sahip verileri karşılaştır
                df1_common = df1[common_columns].copy()
                df2_common = df2[common_columns].copy()
                
                # Farklılıkları bul
                differences = []
                
                # Satır sayılarını kontrol et
                if len(df1_common) != len(df2_common):
                    differences.append({
                        'type': 'row_count',
                        'description': f"Satır sayısı farklı: Dosya 1: {len(df1_common)}, Dosya 2: {len(df2_common)}"
                    })
                
                # Hücre değerlerini karşılaştır
                comparison_df = pd.DataFrame(index=range(max(len(df1_common), len(df2_common))), columns=common_columns)
                
                for col in common_columns:
                    for i in range(min(len(df1_common), len(df2_common))):
                        val1 = df1_common.iloc[i][col]
                        val2 = df2_common.iloc[i][col]
                        
                        # NaN değerleri kontrol et
                        if pd.isna(val1) and pd.isna(val2):
                            comparison_df.at[i, col] = 'identical'
                        elif pd.isna(val1) or pd.isna(val2):
                            comparison_df.at[i, col] = 'different'
                            differences.append({
                                'type': 'cell_value',
                                'row': i + 1,  # 1-indexed
                                'column': col,
                                'value1': 'NaN' if pd.isna(val1) else val1,
                                'value2': 'NaN' if pd.isna(val2) else val2
                            })
                        elif val1 != val2:
                            comparison_df.at[i, col] = 'different'
                            differences.append({
                                'type': 'cell_value',
                                'row': i + 1,  # 1-indexed
                                'column': col,
                                'value1': val1,
                                'value2': val2
                            })
                        else:
                            comparison_df.at[i, col] = 'identical'
                
                # Eksik satırları işaretle
                if len(df1_common) > len(df2_common):
                    for i in range(len(df2_common), len(df1_common)):
                        for col in common_columns:
                            comparison_df.at[i, col] = 'missing_in_file2'
                            differences.append({
                                'type': 'missing_row',
                                'file': 'file2',
                                'row': i + 1,  # 1-indexed
                                'value': df1_common.iloc[i][col]
                            })
                elif len(df2_common) > len(df1_common):
                    for i in range(len(df1_common), len(df2_common)):
                        for col in common_columns:
                            comparison_df.at[i, col] = 'missing_in_file1'
                            differences.append({
                                'type': 'missing_row',
                                'file': 'file1',
                                'row': i + 1,  # 1-indexed
                                'value': df2_common.iloc[i][col]
                            })
                
                # Eksik sütunları işaretle
                for col in columns_only_in_df1:
                    differences.append({
                        'type': 'missing_column',
                        'file': 'file2',
                        'column': col
                    })
                
                for col in columns_only_in_df2:
                    differences.append({
                        'type': 'missing_column',
                        'file': 'file1',
                        'column': col
                    })
                
                # Sonuçları kaydet
                sheet_result = {
                    'differences_count': len(differences),
                    'differences': differences,
                    'columns_only_in_file1': list(columns_only_in_df1),
                    'columns_only_in_file2': list(columns_only_in_df2),
                    'rows_count_file1': len(df1),
                    'rows_count_file2': len(df2),
                    'is_identical': len(differences) == 0
                }
                
                results['sheets'][sheet_name] = sheet_result
                
                # Özet bilgileri güncelle
                results['summary']['total_differences'] += len(differences)
                results['summary']['sheets_compared'] += 1
                if len(differences) == 0:
                    results['summary']['sheets_identical'] += 1
                else:
                    results['summary']['sheets_different'] += 1
                
                # Çıktı dosyasına sonuçları yaz
                if output_path and differences:
                    ExcelBridge._write_comparison_results_to_excel(
                        output_workbook, sheet_name, file1_path, file2_path, 
                        df1_common, df2_common, common_columns, comparison_df, differences
                    )
            
            # Özet sayfası oluştur
            if output_path:
                ExcelBridge._create_summary_sheet(
                    output_workbook, file1_path, file2_path, results
                )
                
                # Dosyayı kaydet
                output_workbook.save(output_path)
                
                # Base64 formatında dosyayı döndür
                with open(output_path, 'rb') as f:
                    output_base64 = base64.b64encode(f.read()).decode('utf-8')
            else:
                output_base64 = None
            
            return True, "Karşılaştırma başarıyla tamamlandı", results, output_base64
            
        except Exception as e:
            return False, f"Karşılaştırma sırasında hata oluştu: {str(e)}", None, None
    
    @staticmethod
    def _write_comparison_results_to_excel(workbook, sheet_name, file1_path, file2_path, 
                                          df1, df2, common_columns, comparison_df, differences):
        """Karşılaştırma sonuçlarını Excel dosyasına yazar"""
        # Karşılaştırma sonuçlarını içeren bir sayfa oluştur
        output_sheet = workbook.create_sheet(sheet_name)
        
        # Başlık satırı
        output_sheet.cell(row=1, column=1, value="Karşılaştırma Sonuçları")
        output_sheet.cell(row=2, column=1, value=f"Dosya 1: {os.path.basename(file1_path)}")
        output_sheet.cell(row=3, column=1, value=f"Dosya 2: {os.path.basename(file2_path)}")
        output_sheet.cell(row=4, column=1, value=f"Sayfa: {sheet_name}")
        output_sheet.cell(row=5, column=1, value=f"Farklılık Sayısı: {len(differences)}")
        
        # Stil tanımları
        header_font = Font(bold=True)
        identical_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        different_fill = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")
        missing1_fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
        missing2_fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
        
        # Veri başlıkları
        row_offset = 7
        for i, col in enumerate(['Satır', 'Sütun'] + common_columns):
            cell = output_sheet.cell(row=row_offset, column=i+1, value=col)
            cell.font = header_font
        
        # Veri satırları
        for i in range(max(len(df1), len(df2))):
            # Satır numarası
            output_sheet.cell(row=i+row_offset+1, column=1, value=i+1)
            
            # Sütun değerleri
            for j, col in enumerate(common_columns):
                # Sütun adı
                if i == 0:
                    output_sheet.cell(row=row_offset, column=j+3, value=col).font = header_font
                
                # Değerler
                cell1 = output_sheet.cell(row=i+row_offset+1, column=j+3)
                
                # Değer ve stil
                if i < len(df1):
                    val1 = df1.iloc[i][col]
                    if not pd.isna(val1):
                        cell1.value = val1
                
                if i < len(df2):
                    val2 = df2.iloc[i][col]
                else:
                    val2 = None
                
                # Karşılaştırma sonucuna göre hücre stilini ayarla
                if i < comparison_df.shape[0] and col in comparison_df.columns:
                    comparison_result = comparison_df.at[i, col]
                    if comparison_result == 'identical':
                        cell1.fill = identical_fill
                    elif comparison_result == 'different':
                        cell1.fill = different_fill
                    elif comparison_result == 'missing_in_file1':
                        cell1.fill = missing1_fill
                    elif comparison_result == 'missing_in_file2':
                        cell1.fill = missing2_fill
        
        # Sütun genişliklerini ayarla
        for i, col in enumerate(common_columns):
            column_letter = get_column_letter(i+3)
            output_sheet.column_dimensions[column_letter].width = 15
        
        # Farklılıklar listesi
        if differences:
            diff_row = max(len(df1), len(df2)) + row_offset + 3
            output_sheet.cell(row=diff_row, column=1, value="Farklılıklar Listesi").font = header_font
            
            # Farklılık başlıkları
            headers = ["Tür", "Satır", "Sütun", "Dosya 1 Değeri", "Dosya 2 Değeri"]
            for i, header in enumerate(headers):
                output_sheet.cell(row=diff_row+1, column=i+1, value=header).font = header_font
            
            # Farklılık detayları
            for i, diff in enumerate(differences):
                diff_type = diff['type']
                row = diff_row + i + 2
                
                output_sheet.cell(row=row, column=1, value=diff_type)
                
                if diff_type == 'cell_value':
                    output_sheet.cell(row=row, column=2, value=diff['row'])
                    output_sheet.cell(row=row, column=3, value=diff['column'])
                    output_sheet.cell(row=row, column=4, value=str(diff['value1']))
                    output_sheet.cell(row=row, column=5, value=str(diff['value2']))
                elif diff_type == 'missing_row':
                    output_sheet.cell(row=row, column=2, value=diff['row'])
                    output_sheet.cell(row=row, column=3, value="Tüm sütunlar")
                    if diff['file'] == 'file1':
                        output_sheet.cell(row=row, column=4, value="Eksik")
                        output_sheet.cell(row=row, column=5, value=str(diff['value']))
                    else:
                        output_sheet.cell(row=row, column=4, value=str(diff['value']))
                        output_sheet.cell(row=row, column=5, value="Eksik")
                elif diff_type == 'missing_column':
                    output_sheet.cell(row=row, column=2, value="Tüm satırlar")
                    output_sheet.cell(row=row, column=3, value=diff['column'])
                    if diff['file'] == 'file1':
                        output_sheet.cell(row=row, column=4, value="Eksik")
                        output_sheet.cell(row=row, column=5, value="Var")
                    else:
                        output_sheet.cell(row=row, column=4, value="Var")
                        output_sheet.cell(row=row, column=5, value="Eksik")
    
    @staticmethod
    def _create_summary_sheet(workbook, file1_path, file2_path, results):
        """Özet sayfasını oluşturur"""
        summary_sheet = workbook.create_sheet("Özet", 0)
        header_font = Font(bold=True)
        identical_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        different_fill = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")
        
        summary_sheet.cell(row=1, column=1, value="Karşılaştırma Özeti").font = header_font
        summary_sheet.cell(row=2, column=1, value=f"Dosya 1: {os.path.basename(file1_path)}")
        summary_sheet.cell(row=3, column=1, value=f"Dosya 2: {os.path.basename(file2_path)}")
        summary_sheet.cell(row=4, column=1, value=f"Toplam Farklılık Sayısı: {results['summary']['total_differences']}")
        summary_sheet.cell(row=5, column=1, value=f"Karşılaştırılan Sayfa Sayısı: {results['summary']['sheets_compared']}")
        summary_sheet.cell(row=6, column=1, value=f"Aynı Olan Sayfa Sayısı: {results['summary']['sheets_identical']}")
        summary_sheet.cell(row=7, column=1, value=f"Farklı Olan Sayfa Sayısı: {results['summary']['sheets_different']}")
        
        # Sayfa bazında özet
        summary_sheet.cell(row=9, column=1, value="Sayfa Bazında Özet").font = header_font
        headers = ["Sayfa Adı", "Farklılık Sayısı", "Durum"]
        for i, header in enumerate(headers):
            summary_sheet.cell(row=10, column=i+1, value=header).font = header_font
        
        for i, (sheet_name, sheet_result) in enumerate(results['sheets'].items()):
            row = 11 + i
            summary_sheet.cell(row=row, column=1, value=sheet_name)
            summary_sheet.cell(row=row, column=2, value=sheet_result['differences_count'])
            status = "Aynı" if sheet_result['is_identical'] else "Farklı"
            status_cell = summary_sheet.cell(row=row, column=3, value=status)
            if status == "Aynı":
                status_cell.fill = identical_fill
            else:
                status_cell.fill = different_fill
        
        # Sütun genişliklerini ayarla
        for i in range(1, 4):
            column_letter = get_column_letter(i)
            summary_sheet.column_dimensions[column_letter].width = 20