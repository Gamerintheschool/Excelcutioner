import os
import sys
import json
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel,
                             QFileDialog, QListWidget, QHBoxLayout, QMessageBox,
                             QLineEdit, QFormLayout, QGroupBox, QApplication, QComboBox,
                             QCheckBox, QListWidgetItem, QTabWidget)
from .excel_bridge import ExcelBridge
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class ExcelComparerWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.file1 = ""
        self.file2 = ""
        self.output_file = ""
        self.comparison_options = {}
        self.initUI()
        
    def initUI(self):
        # Ana pencere ayarları
        self.setWindowTitle('Excel Dosya Karşılaştırma')
        self.setMinimumSize(800, 600)
        
        # Ana widget ve layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Başlık
        title_label = QLabel('Excel Dosya Karşılaştırma')
        title_font = QFont('Arial', 18, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Dosya seçim bölümü
        file_group = QGroupBox("Dosya Seçimi")
        file_layout = QVBoxLayout()
        
        # İlk dosya seçimi
        file1_layout = QHBoxLayout()
        self.select_file1_button = QPushButton('1. Excel Dosyasını Seç')
        self.select_file1_button.clicked.connect(self.select_file1)
        self.file1_path = QLineEdit()
        self.file1_path.setReadOnly(True)
        self.file1_path.setPlaceholderText("1. dosya seçilmedi")
        file1_layout.addWidget(self.select_file1_button)
        file1_layout.addWidget(self.file1_path)
        file_layout.addLayout(file1_layout)
        
        # İkinci dosya seçimi
        file2_layout = QHBoxLayout()
        self.select_file2_button = QPushButton('2. Excel Dosyasını Seç')
        self.select_file2_button.clicked.connect(self.select_file2)
        self.file2_path = QLineEdit()
        self.file2_path.setReadOnly(True)
        self.file2_path.setPlaceholderText("2. dosya seçilmedi")
        file2_layout.addWidget(self.select_file2_button)
        file2_layout.addWidget(self.file2_path)
        file_layout.addLayout(file2_layout)
        
        file_group.setLayout(file_layout)
        main_layout.addWidget(file_group)
        
        # Karşılaştırma seçenekleri
        options_group = QGroupBox("Karşılaştırma Seçenekleri")
        options_layout = QVBoxLayout()
        
        # Sayfa seçimi
        self.sheet_selection_check = QCheckBox("Belirli Sayfaları Karşılaştır")
        self.sheet_selection_check.stateChanged.connect(self.toggle_sheet_selection)
        options_layout.addWidget(self.sheet_selection_check)
        
        # Sayfa listesi
        self.sheet_list = QListWidget()
        self.sheet_list.setSelectionMode(QListWidget.MultiSelection)
        self.sheet_list.setEnabled(False)
        options_layout.addWidget(self.sheet_list)
        
        # Diğer seçenekler
        self.ignore_formatting = QCheckBox("Biçimlendirmeyi Yoksay")
        self.ignore_formatting.setChecked(True)
        options_layout.addWidget(self.ignore_formatting)
        
        self.ignore_case = QCheckBox("Büyük/Küçük Harf Duyarlılığını Yoksay")
        options_layout.addWidget(self.ignore_case)
        
        self.ignore_spaces = QCheckBox("Boşlukları Yoksay")
        options_layout.addWidget(self.ignore_spaces)
        
        self.ignore_empty_cells = QCheckBox("Boş Hücreleri Yoksay")
        options_layout.addWidget(self.ignore_empty_cells)
        
        self.compare_formulas = QCheckBox("Formülleri Karşılaştır")
        options_layout.addWidget(self.compare_formulas)
        
        options_group.setLayout(options_layout)
        main_layout.addWidget(options_group)
        
        # Çıktı dosyası seçim bölümü
        output_group = QGroupBox("Çıktı Dosyası")
        output_layout = QFormLayout()
        
        self.output_path = QLineEdit()
        self.output_path.setReadOnly(True)
        self.output_path.setPlaceholderText("Çıktı dosyası seçilmedi")
        
        output_button_layout = QHBoxLayout()
        self.select_output_button = QPushButton('Çıktı Dosyası Seç')
        self.select_output_button.clicked.connect(self.select_output)
        output_button_layout.addWidget(self.output_path)
        output_button_layout.addWidget(self.select_output_button)
        
        output_layout.addRow(output_button_layout)
        output_group.setLayout(output_layout)
        main_layout.addWidget(output_group)
        
        # Karşılaştırma butonu
        self.compare_button = QPushButton('Dosyaları Karşılaştır')
        self.compare_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
            }
        """)
        self.compare_button.clicked.connect(self.compare_files)
        self.compare_button.setEnabled(False)
        main_layout.addWidget(self.compare_button)
    
    def select_file1(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "1. Excel Dosyasını Seç", "", "Excel Dosyaları (*.xlsx *.xls)")
        
        if file_path:
            self.file1 = file_path
            self.file1_path.setText(file_path)
            self.load_sheets()
            self.check_compare_button()
    
    def select_file2(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "2. Excel Dosyasını Seç", "", "Excel Dosyaları (*.xlsx *.xls)")
        
        if file_path:
            self.file2 = file_path
            self.file2_path.setText(file_path)
            self.load_sheets()
            self.check_compare_button()
    
    def select_output(self):
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Çıktı Dosyasını Seç", "", "Excel Dosyaları (*.xlsx)")
        
        if file_path:
            # Dosya uzantısını kontrol et ve gerekirse ekle
            if not file_path.endswith('.xlsx'):
                file_path += '.xlsx'
            
            self.output_file = file_path
            self.output_path.setText(file_path)
            self.check_compare_button()
    
    def load_sheets(self):
        """Her iki dosyadan da sayfa isimlerini yükle"""
        self.sheet_list.clear()
        
        if not self.file1 or not self.file2:
            return
        
        try:
            import pandas as pd
            
            # Her iki dosyadan da sayfa isimlerini al
            excel1 = pd.ExcelFile(self.file1)
            excel2 = pd.ExcelFile(self.file2)
            
            # Ortak sayfaları bul
            common_sheets = list(set(excel1.sheet_names).intersection(set(excel2.sheet_names)))
            
            # Sayfa listesini doldur
            for sheet in common_sheets:
                self.sheet_list.addItem(sheet)
            
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Sayfa isimleri yüklenirken hata oluştu: {str(e)}")
    
    def toggle_sheet_selection(self, state):
        """Sayfa seçimini etkinleştir/devre dışı bırak"""
        self.sheet_list.setEnabled(state == Qt.Checked)
    
    def check_compare_button(self):
        """Karşılaştırma butonu için gerekli koşulları kontrol et"""
        if self.file1 and self.file2 and self.output_file:
            self.compare_button.setEnabled(True)
        else:
            self.compare_button.setEnabled(False)
    
    def get_comparison_options(self):
        """Karşılaştırma seçeneklerini topla"""
        options = {}
        
        # Sayfa seçimi
        if self.sheet_selection_check.isChecked():
            selected_sheets = [item.text() for item in self.sheet_list.selectedItems()]
            options['sheet_names'] = selected_sheets
        
        # Diğer seçenekler
        options['ignore_formatting'] = self.ignore_formatting.isChecked()
        options['ignore_case'] = self.ignore_case.isChecked()
        options['ignore_spaces'] = self.ignore_spaces.isChecked()
        options['ignore_empty_cells'] = self.ignore_empty_cells.isChecked()
        options['compare_formulas'] = self.compare_formulas.isChecked()
        
        return options
    
    def compare_files(self):
        """Dosyaları karşılaştır"""
        if not self.file1 or not self.file2:
            QMessageBox.warning(self, "Uyarı", "Lütfen karşılaştırılacak iki Excel dosyasını seçin.")
            return
        
        if not self.output_file:
            QMessageBox.warning(self, "Uyarı", "Lütfen çıktı dosyasını seçin.")
            return
        
        # Karşılaştırma seçeneklerini al
        comparison_options = self.get_comparison_options()
        
        try:
            # Karşılaştırma işlemini gerçekleştir
            success, message, results, _ = ExcelBridge.compare_excel_files(
                self.file1, self.file2, comparison_options, self.output_file)
            
            if success:
                # Sonuçları göster
                result_message = f"{message}\n\nKarşılaştırma Sonuçları:\n"
                result_message += f"Toplam Farklılık Sayısı: {results['summary']['total_differences']}\n"
                result_message += f"Karşılaştırılan Sayfa Sayısı: {results['summary']['sheets_compared']}\n"
                result_message += f"Aynı Olan Sayfa Sayısı: {results['summary']['sheets_identical']}\n"
                result_message += f"Farklı Olan Sayfa Sayısı: {results['summary']['sheets_different']}\n\n"
                
                for sheet_name, sheet_results in results['sheets'].items():
                    result_message += f"Sayfa: {sheet_name}\n"
                    result_message += f"Farklılık Sayısı: {sheet_results['differences_count']}\n"
                    
                    if sheet_results['columns_only_in_file1']:
                        result_message += f"Sadece 1. Dosyada Bulunan Sütunlar: {', '.join(sheet_results['columns_only_in_file1'])}\n"
                    
                    if sheet_results['columns_only_in_file2']:
                        result_message += f"Sadece 2. Dosyada Bulunan Sütunlar: {', '.join(sheet_results['columns_only_in_file2'])}\n"
                    
                    result_message += f"1. Dosya Satır Sayısı: {sheet_results['rows_count_file1']}\n"
                    result_message += f"2. Dosya Satır Sayısı: {sheet_results['rows_count_file2']}\n\n"
                
                result_message += f"Detaylı sonuçlar '{self.output_file}' dosyasına kaydedildi."
                
                QMessageBox.information(self, "Başarılı", result_message)
            else:
                QMessageBox.critical(self, "Hata", message)
        
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Karşılaştırma sırasında hata oluştu: {str(e)}")

# Test için
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ExcelComparerWindow()
    window.show()
    sys.exit(app.exec_())