document.addEventListener('DOMContentLoaded', function() {
    // DOM elementlerini seç
    const fileInput = document.getElementById('fileInput');
    const fileInfo = document.getElementById('fileInfo');
    const columnsContainer = document.getElementById('columnsContainer');
    const rowsInput = document.getElementById('rowsInput');
    const columnsInput = document.getElementById('columnsInput');
    const rangeFilter = document.getElementById('rangeFilter');
    const singleFilter = document.getElementById('singleFilter');
    const rangeFilterOptions = document.getElementById('rangeFilterOptions');
    const singleFilterOptions = document.getElementById('singleFilterOptions');
    const lowerBound = document.getElementById('lowerBound');
    const upperBound = document.getElementById('upperBound');
    const singleValue = document.getElementById('singleValue');
    const filterButton = document.getElementById('filterButton');
    const statusMessage = document.getElementById('statusMessage');
    
    // Değişkenler
    let workbook = null;
    let sheetNames = [];
    let activeSheet = null;
    let columns = [];
    
    // Filtreleme tipi değiştiğinde gösterilen seçenekleri güncelle
    rangeFilter.addEventListener('change', updateFilterOptions);
    singleFilter.addEventListener('change', updateFilterOptions);
    
    function updateFilterOptions() {
        if (rangeFilter.checked) {
            rangeFilterOptions.style.display = 'block';
            singleFilterOptions.style.display = 'none';
        } else {
            rangeFilterOptions.style.display = 'none';
            singleFilterOptions.style.display = 'block';
        }
    }
    
    // Dosya seçildiğinde
    fileInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        // Dosya bilgilerini göster
        fileInfo.style.display = 'none';
        statusMessage.style.display = 'none';
        columnsContainer.innerHTML = '';
        filterButton.disabled = true;
        
        // Dosyayı oku
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                // Excel dosyasını oku
                const data = new Uint8Array(e.target.result);
                workbook = XLSX.read(data, {type: 'array'});
                sheetNames = workbook.SheetNames;
                
                if (sheetNames.length > 0) {
                    // İlk sayfayı aktif sayfa olarak ayarla
                    activeSheet = workbook.Sheets[sheetNames[0]];
                    
                    // Sütunları çıkar
                    const worksheet = XLSX.utils.sheet_to_json(activeSheet, {header: 1});
                    if (worksheet.length > 0) {
                        columns = worksheet[0];
                        
                        // Sütunları listele
                        columns.forEach((column, index) => {
                            const columnItem = document.createElement('div');
                            columnItem.className = 'column-item';
                            columnItem.textContent = `${column} (Sütun ${index})`;
                            columnsContainer.appendChild(columnItem);
                        });
                        
                        // Dosya bilgilerini göster
                        fileInfo.style.display = 'block';
                        filterButton.disabled = false;
                    } else {
                        showStatus('Dosya boş veya geçersiz format.', 'error');
                    }
                } else {
                    showStatus('Dosyada hiç sayfa bulunamadı.', 'error');
                }
            } catch (error) {
                console.error('Dosya okuma hatası:', error);
                showStatus('Dosya okunamadı: ' + error.message, 'error');
            }
        };
        
        reader.onerror = function() {
            showStatus('Dosya okuma hatası.', 'error');
        };
        
        reader.readAsArrayBuffer(file);
    });
    
    // Filtreleme butonuna tıklandığında
    filterButton.addEventListener('click', function() {
        if (!workbook || !activeSheet) {
            showStatus('Lütfen önce bir Excel dosyası seçin.', 'error');
            return;
        }
        
        try {
            // Verileri JSON'a dönüştür
            let data = XLSX.utils.sheet_to_json(activeSheet);
            
            // Satır filtreleme
            const rows = rowsInput.value.trim();
            if (rows.toLowerCase() !== 'all') {
                try {
                    const rowIndices = rows.split(',').map(r => parseInt(r.trim()));
                    data = data.filter((_, index) => rowIndices.includes(index));
                } catch (e) {
                    showStatus('Geçersiz satır formatı. Örnek: 0,1,2 veya All', 'error');
                    return;
                }
            }
            
            // Sütun filtreleme
            const cols = columnsInput.value.trim();
            if (cols.toLowerCase() !== 'all') {
                const colNames = cols.split(',').map(c => c.trim());
                data = data.map(row => {
                    const filteredRow = {};
                    colNames.forEach(col => {
                        if (row.hasOwnProperty(col)) {
                            filteredRow[col] = row[col];
                        }
                    });
                    return filteredRow;
                });
            }
            
            // Değer filtreleme
            if (rangeFilter.checked) {
                // Aralık filtresi
                const lower = parseFloat(lowerBound.value);
                const upper = parseFloat(upperBound.value);
                
                if (isNaN(lower) || isNaN(upper)) {
                    showStatus('Lütfen geçerli alt ve üst sınır değerleri girin.', 'error');
                    return;
                }
                
                // Tüm sayısal sütunlara filtre uygula
                data = data.filter(row => {
                    return Object.values(row).some(value => {
                        const numValue = parseFloat(value);
                        return !isNaN(numValue) && numValue >= lower && numValue <= upper;
                    });
                });
            } else {
                // Tek değer filtresi
                const value = parseFloat(singleValue.value);
                
                if (isNaN(value)) {
                    showStatus('Lütfen geçerli bir değer girin.', 'error');
                    return;
                }
                
                // Tüm sayısal sütunlara filtre uygula
                data = data.filter(row => {
                    return Object.values(row).some(cellValue => {
                        const numValue = parseFloat(cellValue);
                        return !isNaN(numValue) && numValue === value;
                    });
                });
            }
            
            // Sonuç boş mu kontrol et
            if (data.length === 0) {
                showStatus('Filtreleme sonucunda hiç veri kalmadı.', 'error');
                return;
            }
            
            // Yeni bir çalışma kitabı oluştur
            const newWorkbook = XLSX.utils.book_new();
            const newWorksheet = XLSX.utils.json_to_sheet(data);
            XLSX.utils.book_append_sheet(newWorkbook, newWorksheet, 'Filtrelenmiş Veri');
            
            // Dosyayı indir
            XLSX.writeFile(newWorkbook, 'filtrelenmis_veri.xlsx');
            
            showStatus('Filtreleme başarılı! Dosya indiriliyor...', 'success');
        } catch (error) {
            console.error('Filtreleme hatası:', error);
            showStatus('Filtreleme sırasında bir hata oluştu: ' + error.message, 'error');
        }
    });
    
    // Durum mesajını göster
    function showStatus(message, type) {
        statusMessage.textContent = message;
        statusMessage.className = 'status ' + type;
        statusMessage.style.display = 'block';
    }
});