import os
import sys
import pandas as pd
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel,
                             QFileDialog, QHBoxLayout, QMessageBox, QGroupBox, QFormLayout,
                             QLineEdit, QRadioButton, QListWidget, QApplication)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class ExcelFilterWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        # Ana pencere ayarları
        self.setWindowTitle('Excel Dosyası Filtreleme')
        self.setMinimumSize(700, 500)
        
        # Ana widget ve layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Başlık
        title_label = QLabel('Excel Dosyası Filtreleme')
        title_font = QFont('Arial', 18, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Açıklama
        desc_label = QLabel('Bu araç, Excel dosyalarındaki verileri filtrelemenizi sağlar.')
        desc_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(desc_label)
        
        # WebView başlatma butonu
        button_layout = QHBoxLayout()
        self.start_button = QPushButton('Filtreleme Aracını Başlat')
        self.start_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        self.start_button.clicked.connect(self.start_webview)
        button_layout.addStretch()
        button_layout.addWidget(self.start_button)
        button_layout.addStretch()
        main_layout.addLayout(button_layout)
        
        # Kullanım talimatları
        instructions_group = QGroupBox("Kullanım Talimatları")
        instructions_layout = QVBoxLayout()
        
        instructions = [
            "1. 'Filtreleme Aracını Başlat' butonuna tıklayın.",
            "2. Excel dosyanızı seçin.",
            "3. Filtrelemek istediğiniz satır ve sütunları belirtin.",
            "4. Aralık filtresi veya tek değer filtresi seçin.",
            "5. Filtreleme değerlerini girin.",
            "6. 'Filtrele ve İndir' butonuna tıklayarak sonucu alın."
        ]
        
        for instruction in instructions:
            instruction_label = QLabel(instruction)
            instructions_layout.addWidget(instruction_label)
        
        instructions_group.setLayout(instructions_layout)
        main_layout.addWidget(instructions_group)
        
        # Boşluk ekle
        main_layout.addStretch()
    
    def start_webview(self):
        try:
            # Doğrudan filtreleme penceresini aç
            self.filter_dialog = ExcelFilterDialog()
            self.filter_dialog.show()
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Filtreleme aracı başlatılamadı: {str(e)}")

class ExcelFilterDialog(QMainWindow):
    def __init__(self):
        super().__init__()
        self.selected_file = ""
        self.df = None
        self.initUI()
        
    def initUI(self):
        # Ana pencere ayarları
        self.setWindowTitle('Excel Dosyası Filtreleme')
        self.setMinimumSize(700, 600)
        
        # Ana widget ve layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Başlık
        title_label = QLabel('Excel Dosyası Filtreleme')
        title_font = QFont('Arial', 18, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Dosya seçim bölümü
        file_group = QGroupBox("Dosya Seçimi")
        file_layout = QVBoxLayout()
        
        # Dosya seçim butonu ve gösterge
        file_button_layout = QHBoxLayout()
        self.file_path_label = QLineEdit()
        self.file_path_label.setReadOnly(True)
        self.file_path_label.setPlaceholderText("Excel dosyası seçilmedi")
        
        self.select_file_button = QPushButton('Excel Dosyası Seç')
        self.select_file_button.clicked.connect(self.select_file)
        
        file_button_layout.addWidget(self.file_path_label)
        file_button_layout.addWidget(self.select_file_button)
        file_layout.addLayout(file_button_layout)
        
        file_group.setLayout(file_layout)
        main_layout.addWidget(file_group)
        
        # Sütun listesi
        columns_group = QGroupBox("Sütunlar")
        columns_layout = QVBoxLayout()
        
        self.columns_list = QListWidget()
        columns_layout.addWidget(self.columns_list)
        
        columns_group.setLayout(columns_layout)
        main_layout.addWidget(columns_group)
        
        # Filtreleme seçenekleri
        filter_group = QGroupBox("Filtreleme Seçenekleri")
        filter_layout = QVBoxLayout()
        
        # Satır giriş kutusu
        rows_layout = QHBoxLayout()
        rows_label = QLabel("İşlem Yapılacak Satırlar (Virgülle Ayırın veya 'All' Yazın):")
        self.rows_input = QLineEdit("All")
        rows_layout.addWidget(rows_label)
        rows_layout.addWidget(self.rows_input)
        filter_layout.addLayout(rows_layout)
        
        # Sütun giriş kutusu
        columns_input_layout = QHBoxLayout()
        columns_label = QLabel("İşlem Yapılacak Sütunlar (Virgülle Ayırın veya 'All' Yazın):")
        self.columns_input = QLineEdit("All")
        columns_input_layout.addWidget(columns_label)
        columns_input_layout.addWidget(self.columns_input)
        filter_layout.addLayout(columns_input_layout)
        
        # Filtreleme tipi
        filter_type_layout = QHBoxLayout()
        filter_type_label = QLabel("Filtreleme Tipi:")
        self.range_filter = QRadioButton("Aralık Filtresi")
        self.single_filter = QRadioButton("Tek Değer Filtresi")
        self.range_filter.setChecked(True)
        filter_type_layout.addWidget(filter_type_label)
        filter_type_layout.addWidget(self.range_filter)
        filter_type_layout.addWidget(self.single_filter)
        filter_layout.addLayout(filter_type_layout)
        
        # Aralık filtresi seçenekleri
        self.range_options = QWidget()
        range_layout = QHBoxLayout(self.range_options)
        
        lower_label = QLabel("Alt Sınır:")
        self.lower_bound = QLineEdit()
        upper_label = QLabel("Üst Sınır:")
        self.upper_bound = QLineEdit()
        
        range_layout.addWidget(lower_label)
        range_layout.addWidget(self.lower_bound)
        range_layout.addWidget(upper_label)
        range_layout.addWidget(self.upper_bound)
        
        filter_layout.addWidget(self.range_options)
        
        # Tek değer filtresi seçenekleri
        self.single_options = QWidget()
        single_layout = QHBoxLayout(self.single_options)
        
        single_label = QLabel("Tek Değer:")
        self.single_value = QLineEdit()
        
        single_layout.addWidget(single_label)
        single_layout.addWidget(self.single_value)
        
        self.single_options.setVisible(False)
        filter_layout.addWidget(self.single_options)
        
        # Filtreleme tipi değiştiğinde gösterilen seçenekleri güncelle
        self.range_filter.toggled.connect(self.update_filter_options)
        
        filter_group.setLayout(filter_layout)
        main_layout.addWidget(filter_group)
        
        # Filtreleme butonu
        self.filter_button = QPushButton('Filtrele ve Kaydet')
        self.filter_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
            }
        """)
        self.filter_button.clicked.connect(self.filter_data)
        self.filter_button.setEnabled(False)
        main_layout.addWidget(self.filter_button)
    
    def update_filter_options(self):
        self.range_options.setVisible(self.range_filter.isChecked())
        self.single_options.setVisible(self.single_filter.isChecked())
    
    def select_file(self):
        filepath = QFileDialog.getOpenFileName(self, "Excel Dosyası Seç", "", "Excel files (*.xlsx *.xls)")
        if filepath[0]:
            self.selected_file = filepath[0]
            self.file_path_label.setText(filepath[0])
            self.load_excel_file()
    
    def load_excel_file(self):
        try:
            # Excel dosyasını oku
            self.df = pd.read_excel(self.selected_file)
            
            # Sütunları listele
            self.columns_list.clear()
            for col in self.df.columns:
                self.columns_list.addItem(str(col))
            
            # Filtreleme butonunu etkinleştir
            self.filter_button.setEnabled(True)
            
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Dosya okunamadı: {str(e)}")
            self.filter_button.setEnabled(False)
    
    def filter_data(self):
        try:
            if self.df is None:
                QMessageBox.warning(self, "Uyarı", "Lütfen önce bir Excel dosyası seçin.")
                return
            
            # Filtrelenecek veriyi kopyala
            filtered_df = self.df.copy()
            
            # Satır filtreleme
            rows = self.rows_input.text().strip()
            if rows.lower() != "all":
                try:
                    row_indices = list(map(int, rows.split(',')))
                    if any(idx >= len(filtered_df) or idx < 0 for idx in row_indices):
                        QMessageBox.warning(self, "Uyarı", "Girilen satır değerlerinden biri geçersiz.")
                        return
                    filtered_df = filtered_df.iloc[row_indices]
                except ValueError:
                    QMessageBox.warning(self, "Uyarı", "Satır değerleri geçerli tam sayılar olmalıdır.")
                    return
            
            # Sütun filtreleme
            columns = self.columns_input.text().strip()
            if columns.lower() != "all":
                column_names = columns.split(',')
                column_names = [col.strip() for col in column_names]
                if any(col not in filtered_df.columns for col in column_names):
                    QMessageBox.warning(self, "Uyarı", "Girilen sütun değerlerinden biri geçersiz.")
                    return
                filtered_df = filtered_df[column_names]
            
            # Değer filtreleme
            if self.range_filter.isChecked():
                # Aralık filtresi
                try:
                    lower = float(self.lower_bound.text())
                    upper = float(self.upper_bound.text())
                except ValueError:
                    QMessageBox.warning(self, "Uyarı", "Lütfen geçerli alt ve üst sınır değerleri girin.")
                    return
                
                # Sayısal sütunları filtrele
                numeric_filtered = False
                for col in filtered_df.columns:
                    if pd.api.types.is_numeric_dtype(filtered_df[col]):
                        filtered_df = filtered_df[(filtered_df[col] >= lower) & (filtered_df[col] <= upper)]
                        numeric_filtered = True
                
                if not numeric_filtered:
                    QMessageBox.warning(self, "Uyarı", "Sayısal sütun bulunamadı.")
                    return
                
            else:
                # Tek değer filtresi
                try:
                    value = float(self.single_value.text())
                except ValueError:
                    QMessageBox.warning(self, "Uyarı", "Lütfen geçerli bir değer girin.")
                    return
                
                # Sayısal sütunları filtrele
                numeric_filtered = False
                for col in filtered_df.columns:
                    if pd.api.types.is_numeric_dtype(filtered_df[col]):
                        filtered_df = filtered_df[filtered_df[col] == value]
                        numeric_filtered = True
                
                if not numeric_filtered:
                    QMessageBox.warning(self, "Uyarı", "Sayısal sütun bulunamadı.")
                    return
            
            # Sonuç boş mu kontrol et
            if filtered_df.empty:
                QMessageBox.warning(self, "Uyarı", "Filtreleme sonucunda hiç veri kalmadı.")
                return
            
            # Yeni dosyayı kaydet
            save_path = QFileDialog.getSaveFileName(self, "Filtrelenmiş Dosyayı Kaydet", "", "Excel files (*.xlsx)")
            if save_path[0]:
                filtered_df.to_excel(save_path[0], index=False)
                QMessageBox.information(self, "Başarılı", "Filtrelenmiş dosya başarıyla kaydedildi.")
            
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Filtreleme sırasında bir hata oluştu: {str(e)}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ExcelFilterWindow()
    window.show()
    sys.exit(app.exec_())