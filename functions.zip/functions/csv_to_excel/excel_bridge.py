import os
import base64
import pandas as pd
import json
from io import BytesIO

class ExcelBridge:
    @staticmethod
    def save_excel_from_base64(base64_data, output_path):
        """
        Base64 formatındaki Excel verisini dosyaya kaydet
        """
        try:
            # Base64'ten binary veriye dönüştür
            binary_data = base64.b64decode(base64_data)
            
            # BytesIO nesnesi oluştur
            excel_data = BytesIO(binary_data)
            
            # Excel dosyasını oku
            dfs = pd.read_excel(excel_data, sheet_name=None)
            
            # Excel dosyasını kaydet
            with pd.ExcelWriter(output_path) as writer:
                for sheet_name, df in dfs.items():
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            return True, "Excel dosyası başarıyla kaydedildi."
        
        except Exception as e:
            return False, f"Hata: {str(e)}"
    
    @staticmethod
    def merge_excel_files(input_files, output_file):
        """
        Excel dosyalarını birleştir
        """
        try:
            # Birleştirilmiş Excel için writer oluştur
            with pd.ExcelWriter(output_file) as writer:
                # Her bir dosyayı işle
                for file_path in input_files:
                    file_name = os.path.basename(file_path).split('.')[0]
                    
                    # Excel dosyasını oku (tüm sayfaları)
                    dfs = pd.read_excel(file_path, sheet_name=None)
                    
                    # Her bir sayfayı işle
                    for sheet_name, df in dfs.items():
                        # Benzersiz sayfa adı oluştur
                        unique_sheet_name = f"{file_name}_{sheet_name}"
                        
                        # Excel'in sayfa adı sınırlaması (31 karakter)
                        if len(unique_sheet_name) > 31:
                            unique_sheet_name = unique_sheet_name[:31]
                        
                        # Sayfayı birleştirilmiş Excel'e ekle
                        df.to_excel(writer, sheet_name=unique_sheet_name, index=False)
            
            return True, "Excel dosyaları başarıyla birleştirildi."
        
        except Exception as e:
            return False, f"Hata: {str(e)}"