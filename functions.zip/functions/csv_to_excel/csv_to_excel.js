/**
 * CSV'den Excel'e dönüştürme işlevini sağlayan JavaScript dosyası
 */

// CSV dosyasını Excel'e dönüştürme işlevi
function convertCsvToExcel() {
    const fileInput = document.getElementById('csvFile');
    const statusDiv = document.getElementById('status');
    const progressBar = document.getElementById('progressBar');
    const progressContainer = document.getElementById('progressContainer');
    
    if (!fileInput.files.length) {
        statusDiv.textContent = 'Lütfen bir CSV dosyası seçin.';
        return;
    }
    
    const file = fileInput.files[0];
    
    // Dosya uzantısını kontrol et
    if (!file.name.toLowerCase().endsWith('.csv')) {
        statusDiv.textContent = 'Lütfen geçerli bir CSV dosyası seçin.';
        return;
    }
    
    statusDiv.textContent = 'CSV dosyası okunuyor...';
    progressContainer.style.display = 'block';
    progressBar.style.width = '20%';
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        try {
            progressBar.style.width = '40%';
            statusDiv.textContent = 'CSV verisi işleniyor...';
            
            // CSV verisini oku
            const csvData = e.target.result;
            
            // CSV'yi Excel'e dönüştür
            const workbook = XLSX.utils.book_new();
            
            // CSV ayırıcı karakteri (varsayılan olarak virgül)
            const delimiter = document.getElementById('delimiter').value || ',';
            
            // CSV'yi çalışma sayfasına dönüştür
            const worksheet = XLSX.utils.csv_to_sheet(csvData, { delimiter: delimiter });
            
            progressBar.style.width = '70%';
            statusDiv.textContent = 'Excel dosyası oluşturuluyor...';
            
            // Çalışma sayfasını çalışma kitabına ekle
            XLSX.utils.book_append_sheet(workbook, worksheet, 'CSV Verileri');
            
            progressBar.style.width = '90%';
            
            // Excel dosyasını oluştur ve indir
            const outputFileName = file.name.replace('.csv', '') + '.xlsx';
            XLSX.writeFile(workbook, outputFileName);
            
            progressBar.style.width = '100%';
            statusDiv.textContent = 'Dönüştürme tamamlandı! Excel dosyası indiriliyor: ' + outputFileName;
            
            // 3 saniye sonra progress bar'ı gizle
            setTimeout(() => {
                progressContainer.style.display = 'none';
                progressBar.style.width = '0%';
            }, 3000);
            
        } catch (error) {
            console.error('Dönüştürme hatası:', error);
            statusDiv.textContent = 'Hata: ' + error.message;
            progressContainer.style.display = 'none';
        }
    };
    
    reader.onerror = function() {
        statusDiv.textContent = 'Dosya okuma hatası!';
        progressContainer.style.display = 'none';
    };
    
    // CSV dosyasını metin olarak oku
    reader.readAsText(file);
}

// Dosya seçildiğinde bilgi göster
function updateFileInfo() {
    const fileInput = document.getElementById('csvFile');
    const fileInfo = document.getElementById('fileInfo');
    
    if (fileInput.files.length) {
        const file = fileInput.files[0];
        fileInfo.textContent = `Seçilen dosya: ${file.name} (${formatFileSize(file.size)})`;
    } else {
        fileInfo.textContent = '';
    }
}

// Dosya boyutunu formatla
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Sayfa yüklendiğinde event listener'ları ekle
window.addEventListener('DOMContentLoaded', () => {
    document.getElementById('csvFile').addEventListener('change', updateFileInfo);
    document.getElementById('convertButton').addEventListener('click', convertCsvToExcel);
});