import os
import sys
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel,
                             QFileDialog, QHBoxLayout, QMessageBox, QGroupBox, QFormLayout,
                             QLineEdit, QApplication)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
import webview

class CsvToExcelWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        # Ana pencere ayarları
        self.setWindowTitle('CSV Dosyasını Excel\'e Dönüştürme')
        self.setMinimumSize(700, 500)
        
        # Ana widget ve layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Başlık
        title_label = QLabel('CSV Dosyasını Excel\'e Dönüştürme')
        title_font = QFont('Arial', 18, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Açıklama
        desc_label = QLabel('Bu araç, CSV dosyalarını Excel (.xlsx) formatına dönüştürmenizi sağlar.')
        desc_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(desc_label)
        
        # WebView başlatma butonu
        button_layout = QHBoxLayout()
        self.start_button = QPushButton('Dönüştürme Aracını Başlat')
        self.start_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        self.start_button.clicked.connect(self.start_webview)
        button_layout.addStretch()
        button_layout.addWidget(self.start_button)
        button_layout.addStretch()
        main_layout.addLayout(button_layout)
        
        # Kullanım talimatları
        instructions_group = QGroupBox("Kullanım Talimatları")
        instructions_layout = QVBoxLayout()
        
        instructions = [
            "1. 'Dönüştürme Aracını Başlat' butonuna tıklayın.",
            "2. CSV dosyanızı seçin.",
            "3. Gerekirse CSV ayırıcı karakterini belirtin (varsayılan: virgül).",
            "4. 'Dönüştür' butonuna tıklayarak Excel dosyasını oluşturun."
        ]
        
        for instruction in instructions:
            instruction_label = QLabel(instruction)
            instructions_layout.addWidget(instruction_label)
        
        instructions_group.setLayout(instructions_layout)
        main_layout.addWidget(instructions_group)
        
        # Boşluk ekle
        main_layout.addStretch()
    
    def start_webview(self):
        try:
            # HTML dosyasının yolunu belirle
            current_dir = os.path.dirname(os.path.abspath(__file__))
            html_path = os.path.join(current_dir, 'csv_to_excel.html')
            
            # HTML dosyasının varlığını kontrol et
            if not os.path.exists(html_path):
                raise FileNotFoundError(f"HTML dosyası bulunamadı: {html_path}")
            
            # WebView penceresini başlat
            webview.create_window('CSV Dosyasını Excel\'e Dönüştürme', 
                                url=html_path,
                                width=800, 
                                height=600, 
                                resizable=True)
            webview.start()
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Dönüştürme aracı başlatılamadı: {str(e)}")

# Test için
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CsvToExcelWindow()
    window.show()
    sys.exit(app.exec_())