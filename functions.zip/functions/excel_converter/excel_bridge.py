import os
import base64
import pandas as pd
import numpy as np
import tempfile
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.utils import get_column_letter

class ExcelBridge:
    @staticmethod
    def save_excel_from_base64(base64_data, output_path):
        """
        Base64 formatındaki Excel verisini dosyaya kaydet
        """
        try:
            # Base64 verisini çöz
            excel_data = base64.b64decode(base64_data)
            
            # Dosyaya kaydet
            with open(output_path, 'wb') as f:
                f.write(excel_data)
            
            return True, f"Dosya başarıyla kaydedildi: {output_path}"
        except Exception as e:
            return False, f"Dosya kaydedilirken hata oluştu: {str(e)}"
    
    @staticmethod
    def convert_excel(input_file, output_format, output_file=None, options=None):
        """
        Excel dosyasını belirtilen formata dönüştürür
        
        Args:
            input_file (str): Dönüştürülecek Excel dosyasının yolu
            output_format (str): Çıktı formatı ('csv', 'json', 'html', 'xlsx', 'xls', 'pdf', 'txt')
            output_file (str, optional): Çıktı dosyasının yolu. Belirtilmezse otomatik oluşturulur.
            options (dict, optional): Dönüştürme seçenekleri
                - sheet_name (str): Dönüştürülecek sayfa adı
                - encoding (str): Çıktı dosyası için karakter kodlaması (CSV için)
                - separator (str): CSV için ayırıcı karakter
                - include_index (bool): İndeks sütununu dahil et
                - include_header (bool): Başlık satırını dahil et
                - table_style (str): HTML için tablo stili
                - orientation (str): PDF için sayfa yönü ('portrait' veya 'landscape')
        
        Returns:
            tuple: (başarı durumu, mesaj, çıktı dosya yolu)
        """
        try:
            # Varsayılan seçenekleri ayarla
            if options is None:
                options = {}
            
            sheet_name = options.get('sheet_name', 0)  # Varsayılan olarak ilk sayfa
            encoding = options.get('encoding', 'utf-8')
            separator = options.get('separator', ',')
            include_index = options.get('include_index', False)
            include_header = options.get('include_header', True)
            table_style = options.get('table_style', 'table table-bordered')
            orientation = options.get('orientation', 'portrait')
            
            # Excel dosyasını oku
            df = pd.read_excel(input_file, sheet_name=sheet_name)
            
            # Çıktı dosya yolunu oluştur (belirtilmemişse)
            if output_file is None:
                base_name = os.path.splitext(os.path.basename(input_file))[0]
                output_file = f"{base_name}.{output_format}"
            
            # Formatına göre dönüştür
            if output_format.lower() == 'csv':
                df.to_csv(output_file, sep=separator, encoding=encoding, 
                          index=include_index, header=include_header)
                
            elif output_format.lower() == 'json':
                orient = 'records' if not include_index else 'index'
                df.to_json(output_file, orient=orient)
                
            elif output_format.lower() == 'html':
                html_content = df.to_html(index=include_index, classes=table_style)
                with open(output_file, 'w', encoding=encoding) as f:
                    f.write(f"""<!DOCTYPE html>
                    <html>
                    <head>
                        <meta charset="{encoding}">
                        <title>Excel to HTML</title>
                        <style>
                            body {{ font-family: Arial, sans-serif; margin: 20px; }}
                            table {{ border-collapse: collapse; width: 100%; }}
                            th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                            th {{ background-color: #f2f2f2; }}
                        </style>
                    </head>
                    <body>
                        <h2>Excel to HTML Conversion</h2>
                        {html_content}
                    </body>
                    </html>""")
                
            elif output_format.lower() == 'xlsx':
                df.to_excel(output_file, sheet_name=sheet_name, index=include_index)
                
            elif output_format.lower() == 'xls':
                df.to_excel(output_file, sheet_name=sheet_name, index=include_index, engine='xlwt')
                
            elif output_format.lower() == 'pdf':
                try:
                    import pdfkit
                    # Önce HTML'e dönüştür
                    html_content = df.to_html(index=include_index)
                    # PDF seçenekleri
                    pdf_options = {
                        'page-size': 'A4',
                        'orientation': orientation,
                        'margin-top': '0.75in',
                        'margin-right': '0.75in',
                        'margin-bottom': '0.75in',
                        'margin-left': '0.75in',
                        'encoding': encoding,
                        'no-outline': None
                    }
                    # HTML'den PDF oluştur
                    pdfkit.from_string(html_content, output_file, options=pdf_options)
                except ImportError:
                    return False, "PDF dönüşümü için pdfkit kütüphanesi gereklidir", None
                
            elif output_format.lower() == 'txt':
                with open(output_file, 'w', encoding=encoding) as f:
                    if include_header:
                        f.write('\t'.join(df.columns) + '\n')
                    for _, row in df.iterrows():
                        f.write('\t'.join([str(x) for x in row]) + '\n')
            
            else:
                return False, f"Desteklenmeyen çıktı formatı: {output_format}", None
            
            return True, f"Dosya başarıyla dönüştürüldü: {output_file}", output_file
            
        except Exception as e:
            return False, f"Dönüştürme sırasında hata oluştu: {str(e)}", None