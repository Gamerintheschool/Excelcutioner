// Excel Dosya Dönüştürme JavaScript

// DOM yüklendikten sonra çalışacak
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elementleri
    const selectInputButton = document.getElementById('selectInputButton');
    const selectOutputButton = document.getElementById('selectOutputButton');
    const inputPathSpan = document.getElementById('inputPath');
    const outputPathSpan = document.getElementById('outputPath');
    const convertButton = document.getElementById('convertButton');
    const statusDiv = document.getElementById('status');
    const formatCombo = document.getElementById('formatCombo');
    
    // Dosya yolları
    let inputFile = '';
    let outputFile = '';
    
    // Dosya seçimi olayları
    selectInputButton.addEventListener('click', function() {
        eel.select_file('Excel Dosyaları (*.xlsx;*.xls)', false)(function(result) {
            if (result && result.length > 0) {
                inputFile = result[0];
                inputPathSpan.textContent = inputFile;
                updateOutputPath();
                checkConvertButton();
            }
        });
    });
    
    selectOutputButton.addEventListener('click', function() {
        const format = formatCombo.value;
        const fileFilter = `${format.toUpperCase()} Dosyaları (*.${format})`;
        
        eel.select_file(fileFilter, true)(function(result) {
            if (result) {
                outputFile = result;
                // Dosya uzantısını kontrol et ve gerekirse ekle
                if (!outputFile.toLowerCase().endsWith(`.${format}`)) {
                    outputFile += `.${format}`;
                }
                outputPathSpan.textContent = outputFile;
                checkConvertButton();
            }
        });
    });
    
    // Format değişikliği olayı
    formatCombo.addEventListener('change', function() {
        updateOutputPath();
    });
    
    // Çıktı dosya yolunu güncelle
    function updateOutputPath() {
        if (inputFile) {
            const format = formatCombo.value;
            const baseName = inputFile.substring(inputFile.lastIndexOf('\\') + 1, inputFile.lastIndexOf('.'));
            const directory = inputFile.substring(0, inputFile.lastIndexOf('\\') + 1);
            outputFile = `${directory}${baseName}.${format}`;
            outputPathSpan.textContent = outputFile;
        }
    }
    
    // Dönüştürme butonu durumu kontrolü
    function checkConvertButton() {
        if (inputFile) {
            convertButton.disabled = false;
        } else {
            convertButton.disabled = true;
        }
    }
    
    // Dönüştürme seçeneklerini topla
    function getOptions() {
        const options = {};
        
        // Sayfa adı
        const sheetName = document.getElementById('sheetName').value.trim();
        if (sheetName) {
            options.sheet_name = sheetName;
        }
        
        // Kodlama
        options.encoding = document.getElementById('encodingCombo').value;
        
        // CSV ayırıcı
        options.separator = document.getElementById('separatorCombo').value;
        
        // İndeks ve başlık
        options.include_index = document.getElementById('includeIndex').checked;
        options.include_header = document.getElementById('includeHeader').checked;
        
        // PDF yönlendirme
        options.orientation = document.getElementById('orientationCombo').value;
        
        return options;
    }
    
    // Dönüştürme butonu olayı
    convertButton.addEventListener('click', function() {
        if (!inputFile) {
            showStatus('Lütfen bir Excel dosyası seçin.', 'error');
            return;
        }
        
        // Çıktı dosyası seçilmemişse, varsayılan bir isim oluştur
        if (!outputFile) {
            updateOutputPath();
        }
        
        // Durum mesajını göster
        showStatus('Dosya dönüştürülüyor...', 'loading');
        
        // Dönüştürme seçeneklerini al
        const options = getOptions();
        const format = formatCombo.value;
        
        // Python'da dönüştürme işlemini çağır
        eel.convert_excel_file(inputFile, format, outputFile, options)(function(result) {
            if (result && result.success) {
                showStatus(result.message, 'success');
            } else {
                showStatus(result.message || 'Dönüştürme sırasında bir hata oluştu.', 'error');
            }
        });
    });
    
    // Durum mesajını göster
    function showStatus(message, type) {
        statusDiv.textContent = message;
        statusDiv.className = 'status ' + type;
    }
});

// Python fonksiyonları için eel bağlantıları
eel.expose(showMessage);
function showMessage(message, type) {
    const statusDiv = document.getElementById('status');
    statusDiv.textContent = message;
    statusDiv.className = 'status ' + (type || 'info');
}