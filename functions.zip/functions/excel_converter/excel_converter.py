import os
import sys
import json
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel,
                             QFileDialog, QHBoxLayout, QMessageBox, QComboBox,
                             QLineEdit, QFormLayout, QGroupBox, QApplication, QCheckBox)
from .excel_bridge import ExcelBridge
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class ExcelConverterWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.input_file = ""
        self.output_file = ""
        self.output_format = "csv"
        self.options = {}
        self.initUI()
        
    def initUI(self):
        # Ana pencere ayarları
        self.setWindowTitle('Excel Dosya Dönüştürme')
        self.setMinimumSize(700, 500)
        
        # Ana widget ve layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Başlık
        title_label = QLabel('Excel Dosya Dönüştürme')
        title_font = QFont('Arial', 18, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Dosya seçim bölümü
        file_group = QGroupBox("Dosya Seçimi")
        file_layout = QVBoxLayout()
        
        # Giriş dosyası seçimi
        input_layout = QHBoxLayout()
        self.select_input_button = QPushButton('Excel Dosyasını Seç')
        self.select_input_button.clicked.connect(self.select_input_file)
        self.input_path = QLineEdit()
        self.input_path.setReadOnly(True)
        self.input_path.setPlaceholderText("Excel dosyası seçilmedi")
        input_layout.addWidget(self.select_input_button)
        input_layout.addWidget(self.input_path)
        file_layout.addLayout(input_layout)
        
        file_group.setLayout(file_layout)
        main_layout.addWidget(file_group)
        
        # Dönüştürme seçenekleri
        options_group = QGroupBox("Dönüştürme Seçenekleri")
        options_layout = QFormLayout()
        
        # Format seçimi
        self.format_combo = QComboBox()
        self.format_combo.addItems(['CSV', 'JSON', 'HTML', 'XLSX', 'XLS', 'PDF', 'TXT'])
        self.format_combo.currentTextChanged.connect(self.update_format)
        options_layout.addRow("Çıktı Formatı:", self.format_combo)
        
        # Sayfa adı
        self.sheet_name = QLineEdit()
        self.sheet_name.setPlaceholderText("Varsayılan: İlk sayfa")
        options_layout.addRow("Sayfa Adı:", self.sheet_name)
        
        # Kodlama
        self.encoding_combo = QComboBox()
        self.encoding_combo.addItems(['utf-8', 'utf-16', 'ascii', 'latin1', 'cp1252'])
        options_layout.addRow("Karakter Kodlaması:", self.encoding_combo)
        
        # CSV ayırıcı
        self.separator_combo = QComboBox()
        self.separator_combo.addItems([',', ';', '\t', '|', ' '])
        options_layout.addRow("CSV Ayırıcı:", self.separator_combo)
        
        # İndeks ve başlık seçenekleri
        self.include_index = QCheckBox("İndeks Sütununu Dahil Et")
        options_layout.addRow("", self.include_index)
        
        self.include_header = QCheckBox("Başlık Satırını Dahil Et")
        self.include_header.setChecked(True)
        options_layout.addRow("", self.include_header)
        
        # PDF yönlendirme
        self.orientation_combo = QComboBox()
        self.orientation_combo.addItems(['portrait', 'landscape'])
        options_layout.addRow("PDF Sayfa Yönü:", self.orientation_combo)
        
        options_group.setLayout(options_layout)
        main_layout.addWidget(options_group)
        
        # Çıktı dosyası seçim bölümü
        output_group = QGroupBox("Çıktı Dosyası")
        output_layout = QHBoxLayout()
        
        self.output_path = QLineEdit()
        self.output_path.setReadOnly(True)
        self.output_path.setPlaceholderText("Çıktı dosyası seçilmedi")
        
        self.select_output_button = QPushButton('Çıktı Dosyası Seç')
        self.select_output_button.clicked.connect(self.select_output_file)
        
        output_layout.addWidget(self.output_path)
        output_layout.addWidget(self.select_output_button)
        
        output_group.setLayout(output_layout)
        main_layout.addWidget(output_group)
        
        # Dönüştürme butonu
        self.convert_button = QPushButton('Dönüştür')
        self.convert_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
            }
        """)
        self.convert_button.clicked.connect(self.convert_file)
        self.convert_button.setEnabled(False)
        main_layout.addWidget(self.convert_button)
    
    def select_input_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Excel Dosyasını Seç", "", "Excel Dosyaları (*.xlsx *.xls)")
        
        if file_path:
            self.input_file = file_path
            self.input_path.setText(file_path)
            self.check_convert_button()
            
            # Çıktı dosya adını otomatik oluştur
            base_name = os.path.splitext(os.path.basename(file_path))[0]
            output_format = self.format_combo.currentText().lower()
            suggested_output = f"{base_name}.{output_format}"
            self.output_file = os.path.join(os.path.dirname(file_path), suggested_output)
            self.output_path.setText(self.output_file)
    
    def select_output_file(self):
        output_format = self.format_combo.currentText().lower()
        file_filter = f"{output_format.upper()} Dosyaları (*.{output_format})"
        
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Çıktı Dosyasını Seç", "", file_filter)
        
        if file_path:
            # Dosya uzantısını kontrol et ve gerekirse ekle
            if not file_path.lower().endswith(f'.{output_format}'):
                file_path += f'.{output_format}'
            
            self.output_file = file_path
            self.output_path.setText(file_path)
            self.check_convert_button()
    
    def update_format(self, format_text):
        self.output_format = format_text.lower()
        
        # Eğer giriş dosyası seçilmişse, çıktı dosya adını güncelle
        if self.input_file:
            base_name = os.path.splitext(os.path.basename(self.input_file))[0]
            suggested_output = f"{base_name}.{self.output_format}"
            self.output_file = os.path.join(os.path.dirname(self.input_file), suggested_output)
            self.output_path.setText(self.output_file)
    
    def check_convert_button(self):
        """Dönüştürme butonu için gerekli koşulları kontrol et"""
        if self.input_file:
            self.convert_button.setEnabled(True)
        else:
            self.convert_button.setEnabled(False)
    
    def get_options(self):
        """Dönüştürme seçeneklerini topla"""
        options = {}
        
        # Sayfa adı
        sheet_name = self.sheet_name.text().strip()
        if sheet_name:
            options['sheet_name'] = sheet_name
        
        # Kodlama
        options['encoding'] = self.encoding_combo.currentText()
        
        # CSV ayırıcı
        options['separator'] = self.separator_combo.currentText()
        
        # İndeks ve başlık
        options['include_index'] = self.include_index.isChecked()
        options['include_header'] = self.include_header.isChecked()
        
        # PDF yönlendirme
        options['orientation'] = self.orientation_combo.currentText()
        
        return options
    
    def convert_file(self):
        """Dosyayı dönüştür"""
        if not self.input_file:
            QMessageBox.warning(self, "Uyarı", "Lütfen bir Excel dosyası seçin.")
            return
        
        # Çıktı dosyası seçilmemişse, varsayılan bir isim oluştur
        if not self.output_file:
            base_name = os.path.splitext(os.path.basename(self.input_file))[0]
            self.output_file = f"{base_name}.{self.output_format}"
        
        # Dönüştürme seçeneklerini al
        options = self.get_options()
        
        try:
            # Dönüştürme işlemini gerçekleştir
            success, message, output_path = ExcelBridge.convert_excel(
                self.input_file, self.output_format, self.output_file, options)
            
            if success:
                QMessageBox.information(self, "Başarılı", message)
            else:
                QMessageBox.critical(self, "Hata", message)
        
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Dönüştürme sırasında hata oluştu: {str(e)}")

# Test için
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ExcelConverterWindow()
    window.show()
    sys.exit(app.exec_())