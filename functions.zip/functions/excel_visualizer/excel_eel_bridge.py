import eel
import os
import tempfile
import pandas as pd
import base64
from .excel_bridge import ExcelBridge

@eel.expose
def get_excel_columns(base64_data):
    """
    Excel dosyasındaki sütunları döndürür.
    
    Args:
        base64_data (str): Base64 formatındaki Excel verisi
        
    Returns:
        list: Sütun isimleri listesi
    """
    try:
        # Base64 veriyi geçici dosyaya kaydet
        temp_file = ExcelBridge.save_excel_from_base64(base64_data)
        if not temp_file:
            return []
        
        # Excel dosyasını oku
        excel_data = pd.ExcelFile(temp_file)
        # İlk sayfadaki sütunları al
        df = excel_data.parse(excel_data.sheet_names[0])
        
        # Geçici dosyayı sil
        os.remove(temp_file)
        
        return df.columns.tolist()
    except Exception as e:
        print(f"Hata: {str(e)}")
        return []

@eel.expose
def visualize_excel(base64_data, selected_columns, chart_type, params):
    """
    Excel dosyasını görselleştirir.
    
    Args:
        base64_data (str): Base64 formatındaki Excel verisi
        selected_columns (list): Görselleştirilecek sütunlar
        chart_type (str): Grafik tipi
        params (dict): Ek parametreler
        
    Returns:
        dict: Görselleştirme sonuçları
    """
    try:
        # Base64 veriyi geçici dosyaya kaydet
        temp_file = ExcelBridge.save_excel_from_base64(base64_data)
        if not temp_file:
            return {"success": False, "message": "Excel dosyası kaydedilemedi."}
        
        # Excel dosyasını görselleştir
        success, message, results = ExcelBridge.visualize_excel(
            temp_file, 
            selected_columns, 
            chart_type, 
            params
        )
        
        # Geçici dosyayı sil
        os.remove(temp_file)
        
        return {"success": success, "message": message, "results": results}
    except Exception as e:
        return {"success": False, "message": f"Hata: {str(e)}", "results": None}