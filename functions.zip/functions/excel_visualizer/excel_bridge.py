import os
import base64
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import io
import tempfile
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

class ExcelBridge:
    """
    Excel dosyalarını görselleştirmek için köprü sınıfı.
    """
    
    @staticmethod
    def save_excel_from_base64(base64_data, output_path=None):
        """
        Base64 formatındaki Excel verisini kaydeder ve dosya yolunu döndürür.
        
        Args:
            base64_data (str): Base64 formatındaki Excel verisi
            output_path (str, optional): Kaydedilecek dosya yolu. Belirtilmezse geçici dosya oluşturulur.
            
        Returns:
            str: Kaydedilen dosyanın yolu
        """
        try:
            # Base64'ten binary veriye dönüştür
            binary_data = base64.b64decode(base64_data)
            
            # Eğer output_path belirtilmemişse, geçici dosya oluştur
            if not output_path:
                fd, output_path = tempfile.mkstemp(suffix='.xlsx')
                os.close(fd)
            
            # Dosyayı kaydet
            with open(output_path, 'wb') as f:
                f.write(binary_data)
                
            return output_path
        except Exception as e:
            print(f"Hata: {str(e)}")
            return None
    
    @staticmethod
    def visualize_excel(file_path, selected_columns=None, chart_type='bar', params=None):
        """
        Excel dosyasını görselleştirir.
        
        Args:
            file_path (str): Excel dosyasının yolu
            selected_columns (list): Görselleştirilecek sütunlar
            chart_type (str): Grafik tipi (bar, line, scatter, pie, histogram, box)
            params (dict): Ek parametreler (x_column, y_column, title, figsize, etc.)
            
        Returns:
            tuple: (başarı durumu, mesaj, sonuçlar)
        """
        try:
            # Parametreleri ayarla
            params = params or {}
            x_column = params.get('x_column')
            y_column = params.get('y_column')
            title = params.get('title', 'Excel Veri Görselleştirme')
            figsize = params.get('figsize', (10, 6))
            dpi = params.get('dpi', 100)
            style = params.get('style', 'default')
            palette = params.get('palette', 'tab10')
            orientation = params.get('orientation', 'vertical')
            bins = params.get('bins', 10)
            
            # Excel dosyasını oku
            excel_data = pd.ExcelFile(file_path)
            results = {}
            
            # Her sayfa için görselleştirme yap
            for sheet_name in excel_data.sheet_names:
                df = excel_data.parse(sheet_name)
                
                # Seçili sütunları filtrele
                if selected_columns:
                    available_columns = [col for col in selected_columns if col in df.columns]
                    if not available_columns:
                        results[sheet_name] = {'error': f"Seçili sütunlar bulunamadı: {selected_columns}"}
                        continue
                    df = df[available_columns]
                
                # Görselleştirme için figür oluştur
                plt.style.use(style)
                fig = Figure(figsize=figsize, dpi=dpi)
                canvas = FigureCanvas(fig)
                ax = fig.add_subplot(111)
                
                # Grafik tipine göre görselleştirme yap
                if chart_type == 'bar':
                    if x_column and y_column and x_column in df.columns and y_column in df.columns:
                        df.plot(kind='bar', x=x_column, y=y_column, ax=ax, colormap=palette)
                    else:
                        df.plot(kind='bar', ax=ax, colormap=palette)
                
                elif chart_type == 'line':
                    if x_column and y_column and x_column in df.columns and y_column in df.columns:
                        df.plot(kind='line', x=x_column, y=y_column, ax=ax, colormap=palette)
                    else:
                        df.plot(kind='line', ax=ax, colormap=palette)
                
                elif chart_type == 'scatter':
                    if x_column and y_column and x_column in df.columns and y_column in df.columns:
                        df.plot(kind='scatter', x=x_column, y=y_column, ax=ax, colormap=palette)
                    else:
                        # Scatter plot için en az iki sütun gerekli
                        if len(df.columns) < 2:
                            results[sheet_name] = {'error': "Scatter plot için en az iki sütun gerekli"}
                            continue
                        df.plot(kind='scatter', x=df.columns[0], y=df.columns[1], ax=ax, colormap=palette)
                
                elif chart_type == 'pie':
                    if x_column and y_column and x_column in df.columns and y_column in df.columns:
                        df.plot(kind='pie', y=y_column, labels=df[x_column], ax=ax, colormap=palette)
                    else:
                        # Pie chart için bir sütun gerekli
                        if len(df.columns) < 1:
                            results[sheet_name] = {'error': "Pie chart için en az bir sütun gerekli"}
                            continue
                        df.iloc[:, 0].plot(kind='pie', ax=ax, colormap=palette)
                
                elif chart_type == 'histogram':
                    if y_column and y_column in df.columns:
                        df[y_column].plot(kind='hist', bins=bins, ax=ax, colormap=palette)
                    else:
                        # Tüm sayısal sütunlar için histogram çiz
                        numeric_cols = df.select_dtypes(include=[np.number]).columns
                        if len(numeric_cols) == 0:
                            results[sheet_name] = {'error': "Histogram için sayısal sütun bulunamadı"}
                            continue
                        df[numeric_cols].plot(kind='hist', bins=bins, ax=ax, colormap=palette)
                
                elif chart_type == 'box':
                    if orientation == 'horizontal':
                        df.plot(kind='box', vert=False, ax=ax, colormap=palette)
                    else:
                        df.plot(kind='box', ax=ax, colormap=palette)
                
                else:
                    results[sheet_name] = {'error': f"Bilinmeyen grafik tipi: {chart_type}"}
                    continue
                
                # Grafik başlığı ve etiketleri ayarla
                ax.set_title(title)
                if x_column:
                    ax.set_xlabel(x_column)
                if y_column:
                    ax.set_ylabel(y_column)
                
                # Grafiği base64 formatına dönüştür
                buf = io.BytesIO()
                fig.savefig(buf, format='png')
                buf.seek(0)
                img_str = base64.b64encode(buf.read()).decode('utf-8')
                
                # Sonuçları kaydet
                results[sheet_name] = {
                    'chart': f"data:image/png;base64,{img_str}",
                    'chart_type': chart_type,
                    'columns': df.columns.tolist(),
                    'data_shape': df.shape
                }
            
            return True, "Görselleştirme başarılı", results
        
        except Exception as e:
            return False, f"Görselleştirme sırasında hata oluştu: {str(e)}", None