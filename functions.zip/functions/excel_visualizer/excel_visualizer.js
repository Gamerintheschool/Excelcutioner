/**
 * Excel Görselleştirme JavaScript Dosyası
 */

// Sayfa yüklendiğinde çalışacak fonksiyon
document.addEventListener('DOMContentLoaded', function() {
    // HTML elementlerini seç
    const fileInput = document.getElementById('fileInput');
    const fileList = document.getElementById('fileList');
    const columnsContainer = document.getElementById('columnsContainer');
    const chartType = document.getElementById('chartType');
    const xColumn = document.getElementById('xColumn');
    const yColumn = document.getElementById('yColumn');
    const bins = document.getElementById('bins');
    const orientation = document.getElementById('orientation');
    const chartTitle = document.getElementById('chartTitle');
    const visualizeButton = document.getElementById('visualizeButton');
    const downloadButton = document.getElementById('downloadButton');
    const resultsContainer = document.getElementById('resultsContainer');
    const chartContainer = document.getElementById('chartContainer');
    const progress = document.getElementById('progress');
    const status = document.getElementById('status');
    
    // Histogram ve kutu grafiği seçeneklerini gizle
    document.getElementById('histogramOptions').classList.add('hidden');
    document.getElementById('boxplotOptions').classList.add('hidden');
    
    // Grafik tipi değiştiğinde seçenekleri güncelle
    chartType.addEventListener('change', updateChartOptions);
    
    // Dosya seçildiğinde çalışacak fonksiyon
    fileInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            // Dosya adını göster
            fileList.innerHTML = `<div>${file.name}</div>`;
            
            // Dosyayı base64 formatına dönüştür
            const reader = new FileReader();
            reader.onload = function(event) {
                const base64data = event.target.result.split(',')[1];
                // Sütunları listele
                listColumns(base64data);
            };
            reader.readAsDataURL(file);
        }
    });
    
    // Görselleştir butonuna tıklandığında çalışacak fonksiyon
    visualizeButton.addEventListener('click', function() {
        visualizeData();
    });
    
    // İndir butonuna tıklandığında çalışacak fonksiyon
    downloadButton.addEventListener('click', function() {
        downloadChart();
    });
    
    /**
     * Grafik tipine göre seçenekleri günceller
     */
    function updateChartOptions() {
        const selectedType = chartType.value;
        
        // Histogram seçeneklerini göster/gizle
        if (selectedType === 'histogram') {
            document.getElementById('histogramOptions').classList.remove('hidden');
        } else {
            document.getElementById('histogramOptions').classList.add('hidden');
        }
        
        // Kutu grafiği seçeneklerini göster/gizle
        if (selectedType === 'box') {
            document.getElementById('boxplotOptions').classList.remove('hidden');
        } else {
            document.getElementById('boxplotOptions').classList.add('hidden');
        }
    }
    
    /**
     * Excel dosyasındaki sütunları listeler
     * @param {string} base64data - Base64 formatındaki Excel verisi
     */
    function listColumns(base64data) {
        // İlerleme çubuğunu güncelle
        updateProgress(10, 'Sütunlar yükleniyor...');
        
        // Python tarafından sütunları al
        eel.get_excel_columns(base64data)(function(columns) {
            // İlerleme çubuğunu güncelle
            updateProgress(100, 'Sütunlar yüklendi');
            
            // Sütunları listele
            columnsContainer.innerHTML = '';
            xColumn.innerHTML = '';
            yColumn.innerHTML = '';
            
            columns.forEach(function(column, index) {
                // Sütun seçim kutusuna ekle
                const checkbox = document.createElement('div');
                checkbox.className = 'column-item';
                checkbox.innerHTML = `
                    <input type="checkbox" id="col-${index}" value="${column}" ${index === 0 ? 'checked' : ''}>
                    <label for="col-${index}">${column}</label>
                `;
                columnsContainer.appendChild(checkbox);
                
                // X ve Y ekseni dropdown'larına ekle
                const xOption = document.createElement('option');
                xOption.value = column;
                xOption.textContent = column;
                xColumn.appendChild(xOption);
                
                const yOption = document.createElement('option');
                yOption.value = column;
                yOption.textContent = column;
                if (index === 1) {
                    yOption.selected = true;
                }
                yColumn.appendChild(yOption);
            });
            
            // Görselleştir butonunu etkinleştir
            visualizeButton.disabled = false;
        });
    }
    
    /**
     * Veriyi görselleştirir
     */
    function visualizeData() {
        // Seçili dosyayı kontrol et
        const file = fileInput.files[0];
        if (!file) {
            alert('Lütfen bir Excel dosyası seçin.');
            return;
        }
        
        // Seçili sütunları al
        const selectedColumns = [];
        const columnCheckboxes = columnsContainer.querySelectorAll('input[type="checkbox"]');
        columnCheckboxes.forEach(function(checkbox) {
            if (checkbox.checked) {
                selectedColumns.push(checkbox.value);
            }
        });
        
        if (selectedColumns.length === 0) {
            alert('Lütfen en az bir sütun seçin.');
            return;
        }
        
        // İlerleme çubuğunu güncelle
        updateProgress(10, 'Görselleştirme yapılıyor...');
        
        // Dosyayı base64 formatına dönüştür
        const reader = new FileReader();
        reader.onload = function(event) {
            const base64data = event.target.result.split(',')[1];
            
            // Parametreleri hazırla
            const params = {
                'x_column': xColumn.value,
                'y_column': yColumn.value,
                'title': chartTitle.value,
                'bins': parseInt(bins.value),
                'orientation': orientation.value
            };
            
            // Python tarafından görselleştir
            eel.visualize_excel(base64data, selectedColumns, chartType.value, params)(function(result) {
                // İlerleme çubuğunu güncelle
                updateProgress(100, 'Görselleştirme tamamlandı');
                
                if (result.success) {
                    // Sonuçları göster
                    displayResults(result.results);
                    // İndir butonunu etkinleştir
                    downloadButton.disabled = false;
                } else {
                    // Hata mesajını göster
                    status.textContent = 'Hata: ' + result.message;
                    chartContainer.innerHTML = `<div class="error">${result.message}</div>`;
                }
            });
        };
        reader.readAsDataURL(file);
    }
    
    /**
     * Görselleştirme sonuçlarını gösterir
     * @param {Object} results - Görselleştirme sonuçları
     */
    function displayResults(results) {
        // İlk sayfanın sonuçlarını al
        const firstSheet = Object.keys(results)[0];
        const sheetResult = results[firstSheet];
        
        if (sheetResult.error) {
            chartContainer.innerHTML = `<div class="error">${sheetResult.error}</div>`;
            return;
        }
        
        // Grafiği göster
        if (sheetResult.chart) {
            chartContainer.innerHTML = `<img class="chart-image" src="${sheetResult.chart}" alt="Görselleştirme">`;
        }
    }
    
    /**
     * Grafiği indirir
     */
    function downloadChart() {
        const chartImage = chartContainer.querySelector('.chart-image');
        if (!chartImage) {
            alert('İndirilecek görsel bulunamadı.');
            return;
        }
        
        // İndirme bağlantısı oluştur
        const downloadLink = document.createElement('a');
        downloadLink.href = chartImage.src;
        downloadLink.download = 'excel_visualization.png';
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
    }
    
    /**
     * İlerleme çubuğunu günceller
     * @param {number} value - İlerleme değeri (0-100)
     * @param {string} message - Durum mesajı
     */
    function updateProgress(value, message) {
        progress.style.width = value + '%';
        status.textContent = message;
    }
});