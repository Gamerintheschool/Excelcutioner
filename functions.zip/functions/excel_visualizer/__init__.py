# Excel Visualizer modülü
from .excel_visualizer import ExcelVisualizerWindow