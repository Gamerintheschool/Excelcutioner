import os
import sys
import pandas as pd
import base64
import tempfile
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QPushButton, QLabel, QFileDialog, QComboBox, 
                             QCheckBox, QListWidget, QListWidgetItem, QProgressBar,
                             QGroupBox, QRadioButton, QButtonGroup, QSpinBox,
                             QLineEdit, QMessageBox, QSplitter, QApplication)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QPixmap
from .excel_bridge import ExcelBridge

class VisualizationWorker(QThread):
    """
    Excel görselleştirme işlemlerini arka planda çalıştırmak için QThread sınıfı.
    """
    finished = pyqtSignal(bool, str, object)
    progress = pyqtSignal(int)
    
    def __init__(self, file_path, selected_columns, chart_type, params):
        super().__init__()
        self.file_path = file_path
        self.selected_columns = selected_columns
        self.chart_type = chart_type
        self.params = params
    
    def run(self):
        try:
            self.progress.emit(10)
            # Excel köprüsünü kullanarak görselleştirme yap
            success, message, results = ExcelBridge.visualize_excel(
                self.file_path, 
                self.selected_columns, 
                self.chart_type, 
                self.params
            )
            self.progress.emit(100)
            self.finished.emit(success, message, results)
        except Exception as e:
            self.finished.emit(False, f"Hata: {str(e)}", None)

class ExcelVisualizerWindow(QMainWindow):
    """
    Excel görselleştirme için ana pencere sınıfı.
    """
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Excel Görselleştirme")
        self.setGeometry(100, 100, 1000, 600)
        self.init_ui()
    
    def init_ui(self):
        """
        Kullanıcı arayüzünü başlatır.
        """
        # Ana widget ve layout
        main_widget = QWidget()
        main_layout = QVBoxLayout(main_widget)
        
        # Dosya seçimi bölümü
        file_group = QGroupBox("Dosya Seçimi")
        file_layout = QHBoxLayout()
        
        self.file_path_label = QLabel("Dosya seçilmedi")
        self.browse_button = QPushButton("Dosya Seç")
        self.browse_button.clicked.connect(self.browse_file)
        
        file_layout.addWidget(self.file_path_label)
        file_layout.addWidget(self.browse_button)
        file_group.setLayout(file_layout)
        
        # Görselleştirme seçenekleri bölümü
        options_group = QGroupBox("Görselleştirme Seçenekleri")
        options_layout = QVBoxLayout()
        
        # Grafik tipi seçimi
        chart_layout = QHBoxLayout()
        chart_layout.addWidget(QLabel("Grafik Tipi:"))
        self.chart_type = QComboBox()
        self.chart_type.addItems(["Çubuk Grafik", "Çizgi Grafik", "Saçılım Grafiği", 
                                 "Pasta Grafik", "Histogram", "Kutu Grafiği"])
        self.chart_type.currentIndexChanged.connect(self.update_options)
        chart_layout.addWidget(self.chart_type)
        options_layout.addLayout(chart_layout)
        
        # X ve Y ekseni seçimi
        axes_layout = QHBoxLayout()
        
        x_layout = QVBoxLayout()
        x_layout.addWidget(QLabel("X Ekseni:"))
        self.x_column = QComboBox()
        x_layout.addWidget(self.x_column)
        
        y_layout = QVBoxLayout()
        y_layout.addWidget(QLabel("Y Ekseni:"))
        self.y_column = QComboBox()
        y_layout.addWidget(self.y_column)
        
        axes_layout.addLayout(x_layout)
        axes_layout.addLayout(y_layout)
        options_layout.addLayout(axes_layout)
        
        # Ek seçenekler
        extra_options_layout = QHBoxLayout()
        
        # Histogram için bin sayısı
        self.bins_layout = QHBoxLayout()
        self.bins_layout.addWidget(QLabel("Bin Sayısı:"))
        self.bins_spinbox = QSpinBox()
        self.bins_spinbox.setRange(5, 100)
        self.bins_spinbox.setValue(10)
        self.bins_layout.addWidget(self.bins_spinbox)
        extra_options_layout.addLayout(self.bins_layout)
        
        # Kutu grafiği için yönlendirme
        self.orientation_layout = QHBoxLayout()
        self.orientation_layout.addWidget(QLabel("Yönlendirme:"))
        self.orientation = QComboBox()
        self.orientation.addItems(["Dikey", "Yatay"])
        self.orientation_layout.addWidget(self.orientation)
        extra_options_layout.addLayout(self.orientation_layout)
        
        # Grafik başlığı
        self.title_layout = QHBoxLayout()
        self.title_layout.addWidget(QLabel("Başlık:"))
        self.title_input = QLineEdit("Excel Veri Görselleştirme")
        self.title_layout.addWidget(self.title_input)
        extra_options_layout.addLayout(self.title_layout)
        
        options_layout.addLayout(extra_options_layout)
        options_group.setLayout(options_layout)
        
        # Sütun seçimi bölümü
        columns_group = QGroupBox("Sütun Seçimi")
        columns_layout = QVBoxLayout()
        
        self.columns_list = QListWidget()
        self.columns_list.setSelectionMode(QListWidget.MultiSelection)
        columns_layout.addWidget(self.columns_list)
        
        columns_group.setLayout(columns_layout)
        
        # Çıktı dosyası seçimi
        output_group = QGroupBox("Çıktı Dosyası")
        output_layout = QHBoxLayout()
        
        self.output_path_label = QLabel("Çıktı dosyası seçilmedi")
        self.output_browse_button = QPushButton("Çıktı Dosyası Seç")
        self.output_browse_button.clicked.connect(self.browse_output_file)
        
        output_layout.addWidget(self.output_path_label)
        output_layout.addWidget(self.output_browse_button)
        output_group.setLayout(output_layout)
        
        # İşlem durumu ve butonlar
        status_layout = QHBoxLayout()
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        status_layout.addWidget(self.progress_bar)
        
        self.status_label = QLabel("Hazır")
        status_layout.addWidget(self.status_label)
        
        # Butonlar
        buttons_layout = QHBoxLayout()
        
        self.visualize_button = QPushButton("Görselleştir")
        self.visualize_button.clicked.connect(self.visualize_excel)
        self.visualize_button.setEnabled(False)
        buttons_layout.addWidget(self.visualize_button)
        
        self.save_button = QPushButton("Kaydet")
        self.save_button.clicked.connect(self.save_results)
        self.save_button.setEnabled(False)
        buttons_layout.addWidget(self.save_button)
        
        # Sonuç alanı
        self.result_label = QLabel()
        self.result_label.setAlignment(Qt.AlignCenter)
        self.result_label.setMinimumHeight(300)
        self.result_label.setStyleSheet("background-color: white; border: 1px solid gray;")
        
        # Ana layout'a ekle
        main_layout.addWidget(file_group)
        main_layout.addWidget(options_group)
        main_layout.addWidget(columns_group)
        main_layout.addWidget(output_group)
        main_layout.addLayout(status_layout)
        main_layout.addLayout(buttons_layout)
        main_layout.addWidget(self.result_label)
        
        self.setCentralWidget(main_widget)
        self.update_options()
        
        # Sonuçları saklamak için değişken
        self.results = None
        self.excel_data = None
        self.output_path = None
    
    def browse_file(self):
        """
        Excel dosyası seçmek için dosya diyaloğunu açar.
        """
        options = QFileDialog.Options()
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Excel Dosyası Seç", "", "Excel Dosyaları (*.xlsx *.xls);;Tüm Dosyalar (*)",
            options=options
        )
        
        if file_path:
            self.file_path_label.setText(file_path)
            self.load_excel_columns(file_path)
            self.visualize_button.setEnabled(True)
    
    def browse_output_file(self):
        """
        Çıktı dosyası seçmek için dosya diyaloğunu açar.
        """
        options = QFileDialog.Options()
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Çıktı Dosyası Seç", "", "PNG Dosyaları (*.png);;JPG Dosyaları (*.jpg);;PDF Dosyaları (*.pdf)",
            options=options
        )
        
        if file_path:
            self.output_path_label.setText(file_path)
            self.output_path = file_path
    
    def load_excel_columns(self, file_path):
        """
        Excel dosyasındaki sütunları yükler.
        
        Args:
            file_path (str): Excel dosyasının yolu
        """
        try:
            self.excel_data = pd.ExcelFile(file_path)
            # İlk sayfadaki sütunları al
            df = self.excel_data.parse(self.excel_data.sheet_names[0])
            
            # Sütunları listele
            self.columns_list.clear()
            self.x_column.clear()
            self.y_column.clear()
            
            for column in df.columns:
                self.columns_list.addItem(column)
                self.x_column.addItem(column)
                self.y_column.addItem(column)
            
            # İlk sütunu seç
            if len(df.columns) > 0:
                self.columns_list.item(0).setSelected(True)
                if len(df.columns) > 1:
                    self.y_column.setCurrentIndex(1)
            
            self.status_label.setText(f"{len(df.columns)} sütun yüklendi")
        except Exception as e:
            self.status_label.setText(f"Hata: {str(e)}")
    
    def update_options(self):
        """
        Seçilen grafik tipine göre seçenekleri günceller.
        """
        chart_type = self.chart_type.currentText()
        
        # Histogram için bin sayısı seçeneğini göster/gizle
        if chart_type == "Histogram":
            for i in range(self.bins_layout.count()):
                self.bins_layout.itemAt(i).widget().setVisible(True)
        else:
            for i in range(self.bins_layout.count()):
                self.bins_layout.itemAt(i).widget().setVisible(False)
        
        # Kutu grafiği için yönlendirme seçeneğini göster/gizle
        if chart_type == "Kutu Grafiği":
            for i in range(self.orientation_layout.count()):
                self.orientation_layout.itemAt(i).widget().setVisible(True)
        else:
            for i in range(self.orientation_layout.count()):
                self.orientation_layout.itemAt(i).widget().setVisible(False)
    
    def get_chart_type_code(self):
        """
        Seçilen grafik tipinin kodunu döndürür.
        
        Returns:
            str: Grafik tipi kodu
        """
        chart_map = {
            "Çubuk Grafik": "bar",
            "Çizgi Grafik": "line",
            "Saçılım Grafiği": "scatter",
            "Pasta Grafik": "pie",
            "Histogram": "histogram",
            "Kutu Grafiği": "box"
        }
        return chart_map.get(self.chart_type.currentText(), "bar")
    
    def visualize_excel(self):
        """
        Excel dosyasını görselleştirir.
        """
        file_path = self.file_path_label.text()
        if file_path == "Dosya seçilmedi":
            QMessageBox.warning(self, "Uyarı", "Lütfen bir Excel dosyası seçin.")
            return
        
        # Seçili sütunları al
        selected_columns = [item.text() for item in self.columns_list.selectedItems()]
        if not selected_columns:
            QMessageBox.warning(self, "Uyarı", "Lütfen en az bir sütun seçin.")
            return
        
        # Grafik tipini al
        chart_type = self.get_chart_type_code()
        
        # Parametreleri hazırla
        params = {
            'x_column': self.x_column.currentText(),
            'y_column': self.y_column.currentText(),
            'title': self.title_input.text(),
            'bins': self.bins_spinbox.value(),
            'orientation': 'horizontal' if self.orientation.currentText() == "Yatay" else 'vertical'
        }
        
        # İşlemi başlat
        self.status_label.setText("Görselleştirme yapılıyor...")
        self.progress_bar.setValue(0)
        self.visualize_button.setEnabled(False)
        
        # Arka plan işçisi oluştur
        self.worker = VisualizationWorker(file_path, selected_columns, chart_type, params)
        self.worker.progress.connect(self.update_progress)
        self.worker.finished.connect(self.visualization_finished)
        self.worker.start()
    
    def update_progress(self, value):
        """
        İlerleme çubuğunu günceller.
        
        Args:
            value (int): İlerleme değeri (0-100)
        """
        self.progress_bar.setValue(value)
    
    def visualization_finished(self, success, message, results):
        """
        Görselleştirme işlemi tamamlandığında çağrılır.
        
        Args:
            success (bool): İşlem başarılı mı?
            message (str): İşlem mesajı
            results (dict): Görselleştirme sonuçları
        """
        self.visualize_button.setEnabled(True)
        self.status_label.setText(message)
        
        if success and results:
            self.results = results
            self.save_button.setEnabled(True)
            
            # İlk sayfanın sonuçlarını göster
            first_sheet = list(results.keys())[0]
            sheet_result = results[first_sheet]
            
            if 'error' in sheet_result:
                QMessageBox.warning(self, "Hata", sheet_result['error'])
                return
            
            # Grafiği göster
            if 'chart' in sheet_result:
                pixmap = self.base64_to_pixmap(sheet_result['chart'])
                if pixmap:
                    self.result_label.setPixmap(pixmap.scaled(
                        self.result_label.width(), 
                        self.result_label.height(),
                        Qt.KeepAspectRatio,
                        Qt.SmoothTransformation
                    ))
        else:
            self.save_button.setEnabled(False)
            QMessageBox.warning(self, "Hata", message)
    
    def base64_to_pixmap(self, base64_str):
        """
        Base64 formatındaki resmi QPixmap'e dönüştürür.
        
        Args:
            base64_str (str): Base64 formatındaki resim
            
        Returns:
            QPixmap: Dönüştürülen resim
        """
        try:
            # "data:image/png;base64," kısmını kaldır
            if "," in base64_str:
                base64_str = base64_str.split(",")[1]
            
            # Base64'ten QPixmap'e dönüştür
            pixmap = QPixmap()
            pixmap.loadFromData(base64.b64decode(base64_str))
            return pixmap
        except Exception as e:
            print(f"Resim dönüştürme hatası: {str(e)}")
            return None
    
    def save_results(self):
        """
        Görselleştirme sonuçlarını kaydeder.
        """
        if not self.results:
            QMessageBox.warning(self, "Uyarı", "Kaydedilecek sonuç bulunamadı.")
            return
        
        if not self.output_path:
            self.browse_output_file()
            if not self.output_path:
                return
        
        try:
            # İlk sayfanın sonuçlarını kaydet
            first_sheet = list(self.results.keys())[0]
            sheet_result = self.results[first_sheet]
            
            if 'chart' in sheet_result:
                # Base64'ten binary'ye dönüştür
                base64_str = sheet_result['chart']
                if "," in base64_str:
                    base64_str = base64_str.split(",")[1]
                
                binary_data = base64.b64decode(base64_str)
                
                # Dosyayı kaydet
                with open(self.output_path, 'wb') as f:
                    f.write(binary_data)
                
                self.status_label.setText(f"Görsel kaydedildi: {self.output_path}")
                QMessageBox.information(self, "Bilgi", f"Görsel başarıyla kaydedildi:\n{self.output_path}")
        except Exception as e:
            self.status_label.setText(f"Kaydetme hatası: {str(e)}")
            QMessageBox.warning(self, "Hata", f"Görsel kaydedilemedi:\n{str(e)}")

# Test için
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ExcelVisualizerWindow()
    window.show()
    sys.exit(app.exec_())