// Excel Birleştirme Fonksiyonu

// Python'dan gelen verileri al
let inputData = null;
let fileList = [];
let outputFile = "";

// DOM elementleri
const progressBar = document.getElementById('progressBar');
const statusElement = document.getElementById('status');
const fileListElement = document.getElementById('fileList');

// Sayfa yüklendiğinde çalışacak fonksiyon
window.addEventListener('pywebviewready', function() {
    // Python'dan veri al
    pywebview.api.get_data().then(function(data) {
        inputData = JSON.parse(data);
        fileList = inputData.inputFiles;
        outputFile = inputData.outputFile;
        
        // Dosya listesini göster
        displayFileList();
        
        // Birleştirme işlemini başlat
        setTimeout(mergeExcelFiles, 500);
    });
});

// Dosya listesini göster
function displayFileList() {
    fileListElement.innerHTML = '';
    fileList.forEach(function(file, index) {
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        fileItem.textContent = `${index + 1}. ${getFileName(file)}`;
        fileListElement.appendChild(fileItem);
    });
}

// Dosya adını yoldan ayıkla
function getFileName(filePath) {
    return filePath.split(/[\\\/]/).pop();
}

// Excel dosyalarını birleştir
async function mergeExcelFiles() {
    try {
        updateStatus('Dosyalar yükleniyor...', 10);
        
        // Tüm dosyaları oku ve verileri topla
        const workbooks = [];
        const totalFiles = fileList.length;
        
        for (let i = 0; i < totalFiles; i++) {
            const filePath = fileList[i];
            updateStatus(`Dosya yükleniyor: ${getFileName(filePath)}`, 10 + (i / totalFiles) * 40);
            
            try {
                const workbook = await readExcelFile(filePath);
                workbooks.push({
                    path: filePath,
                    workbook: workbook
                });
            } catch (error) {
                console.error(`Dosya okunamadı: ${filePath}`, error);
                throw new Error(`Dosya okunamadı: ${getFileName(filePath)}`);
            }
        }
        
        updateStatus('Veriler birleştiriliyor...', 50);
        
        // Birleştirilmiş veri için yeni bir workbook oluştur
        const mergedWorkbook = XLSX.utils.book_new();
        
        // Her bir workbook'u işle
        for (let i = 0; i < workbooks.length; i++) {
            const { path, workbook } = workbooks[i];
            const fileName = getFileName(path);
            
            updateStatus(`Birleştiriliyor: ${fileName}`, 50 + (i / workbooks.length) * 40);
            
            // Workbook'taki her bir sheet'i işle
            const sheetNames = workbook.SheetNames;
            
            for (let j = 0; j < sheetNames.length; j++) {
                const sheetName = sheetNames[j];
                const worksheet = workbook.Sheets[sheetName];
                
                // Sheet adını benzersiz yap (dosya adı + sheet adı)
                const uniqueSheetName = `${fileName.split('.')[0]}_${sheetName}`;
                
                // Sheet'i birleştirilmiş workbook'a ekle
                XLSX.utils.book_append_sheet(mergedWorkbook, worksheet, uniqueSheetName.substring(0, 31)); // Excel sheet adı max 31 karakter
            }
        }
        
        updateStatus('Birleştirilmiş dosya kaydediliyor...', 90);
        
        // Birleştirilmiş workbook'u kaydet
        const wbout = XLSX.write(mergedWorkbook, { bookType: 'xlsx', type: 'array' });
        
        // Dosyayı indir (bu kısım tarayıcıda çalışır, PyWebView ile farklı şekilde ele alınmalı)
        // Normalde burada dosyayı indirme işlemi yapılır, ancak PyWebView ile çalıştığımız için
        // Python tarafına veriyi gönderip orada kaydetmemiz gerekiyor
        
        // Base64 formatına dönüştür
        const base64Data = arrayBufferToBase64(wbout);
        
        // Python'a başarı mesajı gönder
        updateStatus('Tamamlandı!', 100);
        pywebview.api.process_complete(true, 'Excel dosyaları başarıyla birleştirildi.');
        
    } catch (error) {
        console.error('Birleştirme hatası:', error);
        pywebview.api.process_complete(false, `Hata: ${error.message || 'Bilinmeyen bir hata oluştu.'}`);
    }
}

// Excel dosyasını oku
function readExcelFile(filePath) {
    return new Promise((resolve, reject) => {
        // Bu fonksiyon normalde tarayıcıda çalışır, ancak PyWebView ile farklı şekilde ele alınmalı
        // PyWebView ile dosya okuma işlemi için özel bir yaklaşım gerekebilir
        
        // Şimdilik basit bir örnek olarak, dosya yolunu kullanarak XLSX.readFile kullanabiliriz
        // Ancak bu gerçek bir uygulamada çalışmayabilir ve Python tarafında dosya okuma işlemi yapılması gerekebilir
        try {
            const workbook = XLSX.readFile(filePath);
            resolve(workbook);
        } catch (error) {
            reject(error);
        }
    });
}

// ArrayBuffer'ı Base64'e dönüştür
function arrayBufferToBase64(buffer) {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
}

// Durum ve ilerleme çubuğunu güncelle
function updateStatus(message, percentage) {
    statusElement.textContent = message;
    progressBar.style.width = `${percentage}%`;
}