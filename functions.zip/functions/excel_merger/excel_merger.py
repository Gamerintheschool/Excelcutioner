import os
import sys
import json
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel,
                             QFileDialog, QListWidget, QHBoxLayout, QMessageBox,
                             QLineEdit, QFormLayout, QGroupBox, QApplication)
from .excel_bridge import ExcelBridge
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class ExcelMergerWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.selected_files = []
        self.output_file = ""
        self.initUI()
        
    def initUI(self):
        # Ana pencere ayarları
        self.setWindowTitle('Excel Dosyalarını Birleştir')
        self.setMinimumSize(700, 500)
        
        # Ana widget ve layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Başlık
        title_label = QLabel('Excel Dosyalarını Birleştir')
        title_font = QFont('Arial', 18, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Dosya seçim bölümü
        file_group = QGroupBox("Dosya Seçimi")
        file_layout = QVBoxLayout()
        
        # Dosya seçim butonu
        file_button_layout = QHBoxLayout()
        self.select_files_button = QPushButton('Excel Dosyalarını Seç')
        self.select_files_button.clicked.connect(self.select_files)
        self.clear_files_button = QPushButton('Seçimi Temizle')
        self.clear_files_button.clicked.connect(self.clear_files)
        file_button_layout.addWidget(self.select_files_button)
        file_button_layout.addWidget(self.clear_files_button)
        file_layout.addLayout(file_button_layout)
        
        # Seçilen dosyaları göster
        self.file_list = QListWidget()
        file_layout.addWidget(self.file_list)
        
        file_group.setLayout(file_layout)
        main_layout.addWidget(file_group)
        
        # Çıktı dosyası seçim bölümü
        output_group = QGroupBox("Çıktı Dosyası")
        output_layout = QFormLayout()
        
        self.output_path = QLineEdit()
        self.output_path.setReadOnly(True)
        self.output_path.setPlaceholderText("Çıktı dosyası seçilmedi")
        
        output_button_layout = QHBoxLayout()
        self.select_output_button = QPushButton('Çıktı Dosyası Seç')
        self.select_output_button.clicked.connect(self.select_output)
        output_button_layout.addWidget(self.output_path)
        output_button_layout.addWidget(self.select_output_button)
        
        output_layout.addRow(output_button_layout)
        output_group.setLayout(output_layout)
        main_layout.addWidget(output_group)
        
        # Birleştirme seçenekleri
        options_group = QGroupBox("Birleştirme Seçenekleri")
        options_layout = QVBoxLayout()
        
        # Burada birleştirme seçenekleri eklenebilir
        # Örneğin: Başlık satırını dahil et/etme, belirli sütunları seç, vb.
        
        options_group.setLayout(options_layout)
        main_layout.addWidget(options_group)
        
        # Birleştirme butonu
        self.merge_button = QPushButton('Dosyaları Birleştir')
        self.merge_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
            }
        """)
        self.merge_button.clicked.connect(self.merge_files)
        self.merge_button.setEnabled(False)
        main_layout.addWidget(self.merge_button)
    
    def select_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Excel Dosyalarını Seç",
            "",
            "Excel Dosyaları (*.xlsx *.xls *.csv)"
        )
        
        if files:
            self.selected_files.extend(files)
            self.update_file_list()
            self.check_merge_button_state()
    
    def clear_files(self):
        self.selected_files = []
        self.update_file_list()
        self.check_merge_button_state()
    
    def update_file_list(self):
        self.file_list.clear()
        for file in self.selected_files:
            self.file_list.addItem(os.path.basename(file))
    
    def select_output(self):
        file, _ = QFileDialog.getSaveFileName(
            self,
            "Çıktı Dosyasını Seç",
            "",
            "Excel Dosyası (*.xlsx)"
        )
        
        if file:
            self.output_file = file
            self.output_path.setText(file)
            self.check_merge_button_state()
    
    def check_merge_button_state(self):
        # En az 2 dosya seçilmiş ve çıktı dosyası belirlenmiş olmalı
        self.merge_button.setEnabled(len(self.selected_files) >= 2 and self.output_file != "")
    
    def merge_files(self):
        # İşlemi başlat
        try:
            # Kullanıcıya işlemin başladığını bildir
            self.merge_button.setEnabled(False)
            self.merge_button.setText("Birleştiriliyor...")
            
            # Excel dosyalarını birleştir
            success, message = ExcelBridge.merge_excel_files(
                self.selected_files,
                self.output_file
            )
            
            # Sonucu göster
            if success:
                QMessageBox.information(self, "Başarılı", message)
            else:
                QMessageBox.critical(self, "Hata", message)
        
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Birleştirme işlemi sırasında bir hata oluştu: {str(e)}")
        
        finally:
            # Butonu eski haline getir
            self.merge_button.setEnabled(True)
            self.merge_button.setText("Dosyaları Birleştir")

# Bu sınıf artık kullanılmıyor, doğrudan ExcelBridge kullanılıyor
# class ExcelMergerAPI:
#     def __init__(self, data, parent):
#         self.data = data
#         self.parent = parent
#     
#     def get_data(self):
#         return json.dumps(self.data)
#     
#     def process_complete(self, success, message):
#         if success:
#             QMessageBox.information(self.parent, "Başarılı", message)
#         else:
#             QMessageBox.critical(self.parent, "Hata", message)
#         
#         # WebView'ı kapat
#         webview.windows[0].destroy()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ExcelMergerWindow()
    window.show()
    sys.exit(app.exec_())