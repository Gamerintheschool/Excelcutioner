import os
import sys
import eel
import tempfile
import pandas as pd
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QPushButton, QLabel, QFileDialog, QComboBox, 
                             QTextEdit, QListWidget, QMessageBox, QTabWidget,
                             QLineEdit, QCheckBox, QGroupBox, QFormLayout, QSpinBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

from .excel_bridge import ExcelBridge

class ExcelMacroWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Excel Makro Oluşturma ve Yönetme")
        self.setGeometry(100, 100, 1000, 700)
        self.excel_bridge = ExcelBridge()
        self.init_ui()
        
    def init_ui(self):
        # Ana widget ve layout
        main_widget = QWidget()
        main_layout = QVBoxLayout()
        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)
        
        # Başlık
        title_label = QLabel("Excel Makro Oluşturma ve Yönetme")
        title_label.setFont(QFont("Arial", 16, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Alt başlık
        subtitle_label = QLabel("Excel dosyalarınız için makrolar oluşturun, düzenleyin ve yönetin")
        subtitle_label.setFont(QFont("Arial", 10))
        subtitle_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(subtitle_label)
        
        # Tab widget
        tab_widget = QTabWidget()
        main_layout.addWidget(tab_widget)
        
        # Makro Oluşturma Sekmesi
        create_tab = QWidget()
        create_layout = QVBoxLayout()
        create_tab.setLayout(create_layout)
        tab_widget.addTab(create_tab, "Makro Oluştur")
        
        # Makro Düzenleme Sekmesi
        edit_tab = QWidget()
        edit_layout = QVBoxLayout()
        edit_tab.setLayout(edit_layout)
        tab_widget.addTab(edit_tab, "Makro Düzenle")
        
        # Makro Yönetme Sekmesi
        manage_tab = QWidget()
        manage_layout = QVBoxLayout()
        manage_tab.setLayout(manage_layout)
        tab_widget.addTab(manage_tab, "Makro Yönet")
        
        # Makro Çalıştırma Sekmesi
        run_tab = QWidget()
        run_layout = QVBoxLayout()
        run_tab.setLayout(run_layout)
        tab_widget.addTab(run_tab, "Makro Çalıştır")
        
        # Makro Oluşturma Sekmesi İçeriği
        self.setup_create_tab(create_layout)
        
        # Makro Düzenleme Sekmesi İçeriği
        self.setup_edit_tab(edit_layout)
        
        # Makro Yönetme Sekmesi İçeriği
        self.setup_manage_tab(manage_layout)
        
        # Makro Çalıştırma Sekmesi İçeriği
        self.setup_run_tab(run_layout)
        
        # Web tabanlı arayüz için buton
        web_ui_button = QPushButton("Web Tabanlı Arayüzü Aç")
        web_ui_button.clicked.connect(self.open_web_ui)
        main_layout.addWidget(web_ui_button)
        
    def setup_create_tab(self, layout):
        # Dosya seçme bölümü
        file_group = QGroupBox("Excel Dosyası Seç")
        file_layout = QHBoxLayout()
        file_group.setLayout(file_layout)
        
        self.file_path_label = QLabel("Dosya seçilmedi")
        select_file_button = QPushButton("Dosya Seç")
        select_file_button.clicked.connect(self.select_file)
        
        file_layout.addWidget(self.file_path_label)
        file_layout.addWidget(select_file_button)
        layout.addWidget(file_group)
        
        # Makro adı ve açıklaması
        macro_info_group = QGroupBox("Makro Bilgileri")
        macro_info_layout = QFormLayout()
        macro_info_group.setLayout(macro_info_layout)
        
        self.macro_name_input = QLineEdit()
        self.macro_desc_input = QTextEdit()
        self.macro_desc_input.setMaximumHeight(100)
        
        macro_info_layout.addRow("Makro Adı:", self.macro_name_input)
        macro_info_layout.addRow("Açıklama:", self.macro_desc_input)
        layout.addWidget(macro_info_group)
        
        # Makro adımları
        steps_group = QGroupBox("Makro Adımları")
        steps_layout = QVBoxLayout()
        steps_group.setLayout(steps_layout)
        
        # Adım ekleme bölümü
        step_add_layout = QHBoxLayout()
        self.step_type_combo = QComboBox()
        self.step_type_combo.addItems(["Hücre Değeri Değiştir", "Formül Ekle", "Sütun Ekle", 
                                     "Sütun Sil", "Satır Ekle", "Satır Sil", "Hücre Biçimlendir", 
                                     "Veri Sırala", "Veri Filtrele", "Pivot Tablo Oluştur"])
        add_step_button = QPushButton("Adım Ekle")
        add_step_button.clicked.connect(self.add_macro_step)
        
        step_add_layout.addWidget(QLabel("Adım Türü:"))
        step_add_layout.addWidget(self.step_type_combo)
        step_add_layout.addWidget(add_step_button)
        steps_layout.addLayout(step_add_layout)
        
        # Adım listesi
        self.steps_list = QListWidget()
        steps_layout.addWidget(self.steps_list)
        
        # Adım düzenleme butonları
        step_buttons_layout = QHBoxLayout()
        edit_step_button = QPushButton("Adımı Düzenle")
        edit_step_button.clicked.connect(self.edit_macro_step)
        remove_step_button = QPushButton("Adımı Sil")
        remove_step_button.clicked.connect(self.remove_macro_step)
        move_up_button = QPushButton("Yukarı Taşı")
        move_up_button.clicked.connect(self.move_step_up)
        move_down_button = QPushButton("Aşağı Taşı")
        move_down_button.clicked.connect(self.move_step_down)
        
        step_buttons_layout.addWidget(edit_step_button)
        step_buttons_layout.addWidget(remove_step_button)
        step_buttons_layout.addWidget(move_up_button)
        step_buttons_layout.addWidget(move_down_button)
        steps_layout.addLayout(step_buttons_layout)
        
        layout.addWidget(steps_group)
        
        # Kaydetme ve test etme butonları
        buttons_layout = QHBoxLayout()
        save_macro_button = QPushButton("Makroyu Kaydet")
        save_macro_button.clicked.connect(self.save_macro)
        test_macro_button = QPushButton("Makroyu Test Et")
        test_macro_button.clicked.connect(self.test_macro)
        
        buttons_layout.addWidget(save_macro_button)
        buttons_layout.addWidget(test_macro_button)
        layout.addLayout(buttons_layout)
        
    def setup_edit_tab(self, layout):
        # Makro seçme bölümü
        macro_select_group = QGroupBox("Düzenlenecek Makro Seç")
        macro_select_layout = QVBoxLayout()
        macro_select_group.setLayout(macro_select_layout)
        
        self.edit_macro_list = QListWidget()
        refresh_button = QPushButton("Makro Listesini Yenile")
        refresh_button.clicked.connect(self.refresh_macro_list)
        
        macro_select_layout.addWidget(self.edit_macro_list)
        macro_select_layout.addWidget(refresh_button)
        layout.addWidget(macro_select_group)
        
        # Makro düzenleme butonları
        edit_buttons_layout = QHBoxLayout()
        load_macro_button = QPushButton("Makroyu Yükle")
        load_macro_button.clicked.connect(self.load_macro_for_edit)
        
        edit_buttons_layout.addWidget(load_macro_button)
        layout.addLayout(edit_buttons_layout)
        
        # Makro bilgileri (yüklendikten sonra görünecek)
        self.edit_info_group = QGroupBox("Makro Bilgileri")
        edit_info_layout = QFormLayout()
        self.edit_info_group.setLayout(edit_info_layout)
        
        self.edit_name_input = QLineEdit()
        self.edit_desc_input = QTextEdit()
        self.edit_desc_input.setMaximumHeight(100)
        
        edit_info_layout.addRow("Makro Adı:", self.edit_name_input)
        edit_info_layout.addRow("Açıklama:", self.edit_desc_input)
        layout.addWidget(self.edit_info_group)
        self.edit_info_group.setVisible(False)
        
        # Makro adımları (yüklendikten sonra görünecek)
        self.edit_steps_group = QGroupBox("Makro Adımları")
        edit_steps_layout = QVBoxLayout()
        self.edit_steps_group.setLayout(edit_steps_layout)
        
        self.edit_steps_list = QListWidget()
        edit_steps_layout.addWidget(self.edit_steps_list)
        
        # Adım düzenleme butonları
        edit_step_buttons_layout = QHBoxLayout()
        edit_step_edit_button = QPushButton("Adımı Düzenle")
        edit_step_edit_button.clicked.connect(self.edit_step_in_edit_mode)
        edit_step_remove_button = QPushButton("Adımı Sil")
        edit_step_remove_button.clicked.connect(self.remove_step_in_edit_mode)
        edit_step_move_up_button = QPushButton("Yukarı Taşı")
        edit_step_move_up_button.clicked.connect(self.move_step_up_in_edit_mode)
        edit_step_move_down_button = QPushButton("Aşağı Taşı")
        edit_step_move_down_button.clicked.connect(self.move_step_down_in_edit_mode)
        
        edit_step_buttons_layout.addWidget(edit_step_edit_button)
        edit_step_buttons_layout.addWidget(edit_step_remove_button)
        edit_step_buttons_layout.addWidget(edit_step_move_up_button)
        edit_step_buttons_layout.addWidget(edit_step_move_down_button)
        edit_steps_layout.addLayout(edit_step_buttons_layout)
        
        layout.addWidget(self.edit_steps_group)
        self.edit_steps_group.setVisible(False)
        
        # Kaydetme butonu
        save_edited_button = QPushButton("Değişiklikleri Kaydet")
        save_edited_button.clicked.connect(self.save_edited_macro)
        layout.addWidget(save_edited_button)
        
    def setup_manage_tab(self, layout):
        # Makro listesi
        macro_list_group = QGroupBox("Kayıtlı Makrolar")
        macro_list_layout = QVBoxLayout()
        macro_list_group.setLayout(macro_list_layout)
        
        self.manage_macro_list = QListWidget()
        refresh_manage_button = QPushButton("Listeyi Yenile")
        refresh_manage_button.clicked.connect(self.refresh_manage_macro_list)
        
        macro_list_layout.addWidget(self.manage_macro_list)
        macro_list_layout.addWidget(refresh_manage_button)
        layout.addWidget(macro_list_group)
        
        # Makro yönetim butonları
        manage_buttons_layout = QHBoxLayout()
        view_macro_button = QPushButton("Makroyu Görüntüle")
        view_macro_button.clicked.connect(self.view_macro)
        export_macro_button = QPushButton("Makroyu Dışa Aktar")
        export_macro_button.clicked.connect(self.export_macro)
        import_macro_button = QPushButton("Makro İçe Aktar")
        import_macro_button.clicked.connect(self.import_macro)
        delete_macro_button = QPushButton("Makroyu Sil")
        delete_macro_button.clicked.connect(self.delete_macro)
        
        manage_buttons_layout.addWidget(view_macro_button)
        manage_buttons_layout.addWidget(export_macro_button)
        manage_buttons_layout.addWidget(import_macro_button)
        manage_buttons_layout.addWidget(delete_macro_button)
        layout.addLayout(manage_buttons_layout)
        
        # Makro detayları
        self.macro_details_group = QGroupBox("Makro Detayları")
        macro_details_layout = QVBoxLayout()
        self.macro_details_group.setLayout(macro_details_layout)
        
        self.macro_details_text = QTextEdit()
        self.macro_details_text.setReadOnly(True)
        
        macro_details_layout.addWidget(self.macro_details_text)
        layout.addWidget(self.macro_details_group)
        
    def setup_run_tab(self, layout):
        # Dosya seçme bölümü
        run_file_group = QGroupBox("Excel Dosyası Seç")
        run_file_layout = QHBoxLayout()
        run_file_group.setLayout(run_file_layout)
        
        self.run_file_path_label = QLabel("Dosya seçilmedi")
        run_select_file_button = QPushButton("Dosya Seç")
        run_select_file_button.clicked.connect(self.select_run_file)
        
        run_file_layout.addWidget(self.run_file_path_label)
        run_file_layout.addWidget(run_select_file_button)
        layout.addWidget(run_file_group)
        
        # Makro seçme bölümü
        run_macro_group = QGroupBox("Çalıştırılacak Makro Seç")
        run_macro_layout = QVBoxLayout()
        run_macro_group.setLayout(run_macro_layout)
        
        self.run_macro_list = QListWidget()
        run_refresh_button = QPushButton("Makro Listesini Yenile")
        run_refresh_button.clicked.connect(self.refresh_run_macro_list)
        
        run_macro_layout.addWidget(self.run_macro_list)
        run_macro_layout.addWidget(run_refresh_button)
        layout.addWidget(run_macro_group)
        
        # Çalıştırma seçenekleri
        run_options_group = QGroupBox("Çalıştırma Seçenekleri")
        run_options_layout = QVBoxLayout()
        run_options_group.setLayout(run_options_layout)
        
        self.backup_checkbox = QCheckBox("Çalıştırmadan önce dosyanın yedeğini al")
        self.backup_checkbox.setChecked(True)
        
        self.show_progress_checkbox = QCheckBox("İlerlemeyi göster")
        self.show_progress_checkbox.setChecked(True)
        
        run_options_layout.addWidget(self.backup_checkbox)
        run_options_layout.addWidget(self.show_progress_checkbox)
        layout.addWidget(run_options_group)
        
        # Çalıştırma butonu
        run_macro_button = QPushButton("Makroyu Çalıştır")
        run_macro_button.clicked.connect(self.run_macro)
        layout.addWidget(run_macro_button)
        
        # Sonuç alanı
        result_group = QGroupBox("Çalıştırma Sonucu")
        result_layout = QVBoxLayout()
        result_group.setLayout(result_layout)
        
        self.run_result_text = QTextEdit()
        self.run_result_text.setReadOnly(True)
        
        result_layout.addWidget(self.run_result_text)
        layout.addWidget(result_group)
        
    def select_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Excel Dosyası Seç", "", "Excel Dosyaları (*.xlsx *.xls)")
        if file_path:
            self.file_path_label.setText(file_path)
            
    def select_run_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Excel Dosyası Seç", "", "Excel Dosyaları (*.xlsx *.xls)")
        if file_path:
            self.run_file_path_label.setText(file_path)
            
    def add_macro_step(self):
        step_type = self.step_type_combo.currentText()
        # Burada adım türüne göre ek parametreler alınabilir
        # Şimdilik basit bir şekilde adım türünü listeye ekliyoruz
        self.steps_list.addItem(f"{step_type}")
        
    def edit_macro_step(self):
        selected_item = self.steps_list.currentItem()
        if selected_item:
            # Burada seçilen adımı düzenlemek için bir dialog açılabilir
            QMessageBox.information(self, "Bilgi", "Adım düzenleme özelliği henüz uygulanmadı.")
            
    def remove_macro_step(self):
        selected_row = self.steps_list.currentRow()
        if selected_row >= 0:
            self.steps_list.takeItem(selected_row)
            
    def move_step_up(self):
        current_row = self.steps_list.currentRow()
        if current_row > 0:
            current_item = self.steps_list.takeItem(current_row)
            self.steps_list.insertItem(current_row - 1, current_item)
            self.steps_list.setCurrentRow(current_row - 1)
            
    def move_step_down(self):
        current_row = self.steps_list.currentRow()
        if current_row < self.steps_list.count() - 1:
            current_item = self.steps_list.takeItem(current_row)
            self.steps_list.insertItem(current_row + 1, current_item)
            self.steps_list.setCurrentRow(current_row + 1)
            
    def save_macro(self):
        macro_name = self.macro_name_input.text()
        macro_desc = self.macro_desc_input.toPlainText()
        
        if not macro_name:
            QMessageBox.warning(self, "Uyarı", "Lütfen bir makro adı girin.")
            return
            
        if self.steps_list.count() == 0:
            QMessageBox.warning(self, "Uyarı", "Makroya en az bir adım eklemelisiniz.")
            return
            
        # Adımları toplama
        steps = []
        for i in range(self.steps_list.count()):
            steps.append(self.steps_list.item(i).text())
            
        # Makroyu kaydetme
        success = self.excel_bridge.save_macro(macro_name, macro_desc, steps)
        
        if success:
            QMessageBox.information(self, "Bilgi", f"\"{macro_name}\" makrosu başarıyla kaydedildi.")
            self.macro_name_input.clear()
            self.macro_desc_input.clear()
            self.steps_list.clear()
        else:
            QMessageBox.critical(self, "Hata", "Makro kaydedilirken bir hata oluştu.")
            
    def test_macro(self):
        file_path = self.file_path_label.text()
        
        if file_path == "Dosya seçilmedi":
            QMessageBox.warning(self, "Uyarı", "Lütfen bir Excel dosyası seçin.")
            return
            
        if self.steps_list.count() == 0:
            QMessageBox.warning(self, "Uyarı", "Test edilecek adım bulunamadı.")
            return
            
        # Adımları toplama
        steps = []
        for i in range(self.steps_list.count()):
            steps.append(self.steps_list.item(i).text())
            
        # Makroyu test etme
        result = self.excel_bridge.test_macro(file_path, steps)
        
        if result["success"]:
            QMessageBox.information(self, "Test Sonucu", "Makro başarıyla test edildi.")
        else:
            QMessageBox.critical(self, "Test Hatası", f"Makro test edilirken hata oluştu: {result['error']}")
            
    def refresh_macro_list(self):
        # Makro listesini yenileme
        macros = self.excel_bridge.get_macro_list()
        
        self.edit_macro_list.clear()
        for macro in macros:
            self.edit_macro_list.addItem(macro["name"])
            
    def refresh_manage_macro_list(self):
        # Makro listesini yenileme
        macros = self.excel_bridge.get_macro_list()
        
        self.manage_macro_list.clear()
        for macro in macros:
            self.manage_macro_list.addItem(macro["name"])
            
    def refresh_run_macro_list(self):
        # Makro listesini yenileme
        macros = self.excel_bridge.get_macro_list()
        
        self.run_macro_list.clear()
        for macro in macros:
            self.run_macro_list.addItem(macro["name"])
            
    def load_macro_for_edit(self):
        selected_item = self.edit_macro_list.currentItem()
        if not selected_item:
            QMessageBox.warning(self, "Uyarı", "Lütfen düzenlenecek bir makro seçin.")
            return
            
        macro_name = selected_item.text()
        macro_data = self.excel_bridge.get_macro(macro_name)
        
        if not macro_data["success"]:
            QMessageBox.critical(self, "Hata", f"Makro yüklenirken hata oluştu: {macro_data['error']}")
            return
            
        # Makro bilgilerini form alanlarına doldur
        self.edit_name_input.setText(macro_data["macro"]["name"])
        self.edit_desc_input.setText(macro_data["macro"]["description"])
        
        # Adımları listeye ekle
        self.edit_steps_list.clear()
        for step in macro_data["macro"]["steps"]:
            self.edit_steps_list.addItem(step)
            
        # Düzenleme alanlarını görünür yap
        self.edit_info_group.setVisible(True)
        self.edit_steps_group.setVisible(True)
        
    def edit_step_in_edit_mode(self):
        selected_item = self.edit_steps_list.currentItem()
        if selected_item:
            # Burada seçilen adımı düzenlemek için bir dialog açılabilir
            QMessageBox.information(self, "Bilgi", "Adım düzenleme özelliği henüz uygulanmadı.")
            
    def remove_step_in_edit_mode(self):
        selected_row = self.edit_steps_list.currentRow()
        if selected_row >= 0:
            self.edit_steps_list.takeItem(selected_row)
            
    def move_step_up_in_edit_mode(self):
        current_row = self.edit_steps_list.currentRow()
        if current_row > 0:
            current_item = self.edit_steps_list.takeItem(current_row)
            self.edit_steps_list.insertItem(current_row - 1, current_item)
            self.edit_steps_list.setCurrentRow(current_row - 1)
            
    def move_step_down_in_edit_mode(self):
        current_row = self.edit_steps_list.currentRow()
        if current_row < self.edit_steps_list.count() - 1:
            current_item = self.edit_steps_list.takeItem(current_row)
            self.edit_steps_list.insertItem(current_row + 1, current_item)
            self.edit_steps_list.setCurrentRow(current_row + 1)
            
    def save_edited_macro(self):
        original_name = self.edit_macro_list.currentItem().text() if self.edit_macro_list.currentItem() else ""
        new_name = self.edit_name_input.text()
        new_desc = self.edit_desc_input.toPlainText()
        
        if not new_name:
            QMessageBox.warning(self, "Uyarı", "Lütfen bir makro adı girin.")
            return
            
        if self.edit_steps_list.count() == 0:
            QMessageBox.warning(self, "Uyarı", "Makroya en az bir adım eklemelisiniz.")
            return
            
        # Adımları toplama
        steps = []
        for i in range(self.edit_steps_list.count()):
            steps.append(self.edit_steps_list.item(i).text())
            
        # Makroyu güncelleme
        success = self.excel_bridge.update_macro(original_name, new_name, new_desc, steps)
        
        if success:
            QMessageBox.information(self, "Bilgi", f"\"{new_name}\" makrosu başarıyla güncellendi.")
            self.refresh_macro_list()
            self.edit_info_group.setVisible(False)
            self.edit_steps_group.setVisible(False)
        else:
            QMessageBox.critical(self, "Hata", "Makro güncellenirken bir hata oluştu.")
            
    def view_macro(self):
        selected_item = self.manage_macro_list.currentItem()
        if not selected_item:
            QMessageBox.warning(self, "Uyarı", "Lütfen görüntülenecek bir makro seçin.")
            return
            
        macro_name = selected_item.text()
        macro_data = self.excel_bridge.get_macro(macro_name)
        
        if not macro_data["success"]:
            QMessageBox.critical(self, "Hata", f"Makro yüklenirken hata oluştu: {macro_data['error']}")
            return
            
        # Makro detaylarını göster
        macro = macro_data["macro"]
        details = f"Makro Adı: {macro['name']}\n\n"
        details += f"Açıklama: {macro['description']}\n\n"
        details += "Adımlar:\n"
        
        for i, step in enumerate(macro["steps"]):
            details += f"{i+1}. {step}\n"
            
        self.macro_details_text.setText(details)
        
    def export_macro(self):
        selected_item = self.manage_macro_list.currentItem()
        if not selected_item:
            QMessageBox.warning(self, "Uyarı", "Lütfen dışa aktarılacak bir makro seçin.")
            return
            
        macro_name = selected_item.text()
        
        # Kayıt yeri seç
        file_path, _ = QFileDialog.getSaveFileName(self, "Makroyu Kaydet", f"{macro_name}.xlmacro", "Excel Makro Dosyaları (*.xlmacro)")
        
        if not file_path:
            return
            
        # Makroyu dışa aktar
        success = self.excel_bridge.export_macro(macro_name, file_path)
        
        if success:
            QMessageBox.information(self, "Bilgi", f"\"{macro_name}\" makrosu başarıyla dışa aktarıldı.")
        else:
            QMessageBox.critical(self, "Hata", "Makro dışa aktarılırken bir hata oluştu.")
            
    def import_macro(self):
        # Makro dosyasını seç
        file_path, _ = QFileDialog.getOpenFileName(self, "Makro Dosyası Seç", "", "Excel Makro Dosyaları (*.xlmacro)")
        
        if not file_path:
            return
            
        # Makroyu içe aktar
        result = self.excel_bridge.import_macro(file_path)
        
        if result["success"]:
            QMessageBox.information(self, "Bilgi", f"\"{result['macro_name']}\" makrosu başarıyla içe aktarıldı.")
            self.refresh_manage_macro_list()
        else:
            QMessageBox.critical(self, "Hata", f"Makro içe aktarılırken hata oluştu: {result['error']}")
            
    def delete_macro(self):
        selected_item = self.manage_macro_list.currentItem()
        if not selected_item:
            QMessageBox.warning(self, "Uyarı", "Lütfen silinecek bir makro seçin.")
            return
            
        macro_name = selected_item.text()
        
        # Onay iste
        reply = QMessageBox.question(self, "Makro Silme", f"\"{macro_name}\" makrosunu silmek istediğinizden emin misiniz?", 
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.No:
            return
            
        # Makroyu sil
        success = self.excel_bridge.delete_macro(macro_name)
        
        if success:
            QMessageBox.information(self, "Bilgi", f"\"{macro_name}\" makrosu başarıyla silindi.")
            self.refresh_manage_macro_list()
        else:
            QMessageBox.critical(self, "Hata", "Makro silinirken bir hata oluştu.")
            
    def run_macro(self):
        file_path = self.run_file_path_label.text()
        
        if file_path == "Dosya seçilmedi":
            QMessageBox.warning(self, "Uyarı", "Lütfen bir Excel dosyası seçin.")
            return
            
        selected_item = self.run_macro_list.currentItem()
        if not selected_item:
            QMessageBox.warning(self, "Uyarı", "Lütfen çalıştırılacak bir makro seçin.")
            return
            
        macro_name = selected_item.text()
        backup = self.backup_checkbox.isChecked()
        show_progress = self.show_progress_checkbox.isChecked()
        
        # Makroyu çalıştır
        result = self.excel_bridge.run_macro(macro_name, file_path, backup, show_progress)
        
        if result["success"]:
            self.run_result_text.setText(f"Makro başarıyla çalıştırıldı.\n\nÇalıştırma Süresi: {result['execution_time']} saniye\n\nEtkilenen Hücre Sayısı: {result['affected_cells']}")
        else:
            self.run_result_text.setText(f"Makro çalıştırılırken hata oluştu:\n\n{result['error']}")
            
    def open_web_ui(self):
        # Web tabanlı arayüzü aç
        self.excel_bridge.open_web_ui()