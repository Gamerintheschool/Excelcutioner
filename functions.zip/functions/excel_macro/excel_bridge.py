import os
import sys
import json
import time
import shutil
import pandas as pd
import eel
from datetime import datetime

class ExcelBridge:
    def __init__(self):
        self.macros_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "macros")
        
        # Makrolar dizini yoksa oluştur
        if not os.path.exists(self.macros_dir):
            os.makedirs(self.macros_dir)
            
    def save_macro(self, name, description, steps):
        """
        Yeni bir makro kaydeder.
        
        Args:
            name (str): Makro adı
            description (str): Makro açıklaması
            steps (list): Makro adımları listesi
            
        Returns:
            bool: İşlem başarılı ise True, değilse False
        """
        try:
            # Makro verilerini oluştur
            macro_data = {
                "name": name,
                "description": description,
                "steps": steps,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            # Makro dosyasını oluştur
            file_path = os.path.join(self.macros_dir, f"{name}.json")
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(macro_data, f, ensure_ascii=False, indent=4)
                
            return True
        except Exception as e:
            print(f"Makro kaydedilirken hata oluştu: {str(e)}")
            return False
            
    def update_macro(self, original_name, new_name, description, steps):
        """
        Var olan bir makroyu günceller.
        
        Args:
            original_name (str): Makronun orijinal adı
            new_name (str): Makronun yeni adı
            description (str): Makro açıklaması
            steps (list): Makro adımları listesi
            
        Returns:
            bool: İşlem başarılı ise True, değilse False
        """
        try:
            # Orijinal makro dosyasını kontrol et
            original_file_path = os.path.join(self.macros_dir, f"{original_name}.json")
            if not os.path.exists(original_file_path):
                return False
                
            # Makro verilerini oluştur
            macro_data = {
                "name": new_name,
                "description": description,
                "steps": steps,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),  # Normalde orijinal oluşturma tarihini korumak gerekir
                "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            # Eğer isim değiştiyse eski dosyayı sil
            if original_name != new_name:
                os.remove(original_file_path)
                
            # Yeni makro dosyasını oluştur
            new_file_path = os.path.join(self.macros_dir, f"{new_name}.json")
            with open(new_file_path, "w", encoding="utf-8") as f:
                json.dump(macro_data, f, ensure_ascii=False, indent=4)
                
            return True
        except Exception as e:
            print(f"Makro güncellenirken hata oluştu: {str(e)}")
            return False
            
    def delete_macro(self, name):
        """
        Bir makroyu siler.
        
        Args:
            name (str): Silinecek makronun adı
            
        Returns:
            bool: İşlem başarılı ise True, değilse False
        """
        try:
            file_path = os.path.join(self.macros_dir, f"{name}.json")
            if os.path.exists(file_path):
                os.remove(file_path)
                return True
            return False
        except Exception as e:
            print(f"Makro silinirken hata oluştu: {str(e)}")
            return False
            
    def get_macro_list(self):
        """
        Kayıtlı makroların listesini döndürür.
        
        Returns:
            list: Makro bilgilerini içeren sözlük listesi
        """
        try:
            macros = []
            for file_name in os.listdir(self.macros_dir):
                if file_name.endswith(".json"):
                    file_path = os.path.join(self.macros_dir, file_name)
                    with open(file_path, "r", encoding="utf-8") as f:
                        macro_data = json.load(f)
                        macros.append({
                            "name": macro_data["name"],
                            "description": macro_data["description"],
                            "step_count": len(macro_data["steps"]),
                            "updated_at": macro_data["updated_at"]
                        })
            return macros
        except Exception as e:
            print(f"Makro listesi alınırken hata oluştu: {str(e)}")
            return []
            
    def get_macro(self, name):
        """
        Belirtilen makronun detaylarını döndürür.
        
        Args:
            name (str): Makro adı
            
        Returns:
            dict: İşlem sonucu ve makro bilgileri
        """
        try:
            file_path = os.path.join(self.macros_dir, f"{name}.json")
            if not os.path.exists(file_path):
                return {"success": False, "error": "Makro bulunamadı."}
                
            with open(file_path, "r", encoding="utf-8") as f:
                macro_data = json.load(f)
                
            return {"success": True, "macro": macro_data}
        except Exception as e:
            return {"success": False, "error": str(e)}
            
    def export_macro(self, name, export_path):
        """
        Bir makroyu dışa aktarır.
        
        Args:
            name (str): Makro adı
            export_path (str): Dışa aktarılacak dosya yolu
            
        Returns:
            bool: İşlem başarılı ise True, değilse False
        """
        try:
            file_path = os.path.join(self.macros_dir, f"{name}.json")
            if not os.path.exists(file_path):
                return False
                
            shutil.copy2(file_path, export_path)
            return True
        except Exception as e:
            print(f"Makro dışa aktarılırken hata oluştu: {str(e)}")
            return False
            
    def import_macro(self, import_path):
        """
        Bir makroyu içe aktarır.
        
        Args:
            import_path (str): İçe aktarılacak dosya yolu
            
        Returns:
            dict: İşlem sonucu ve makro adı
        """
        try:
            if not os.path.exists(import_path):
                return {"success": False, "error": "Dosya bulunamadı."}
                
            with open(import_path, "r", encoding="utf-8") as f:
                macro_data = json.load(f)
                
            name = macro_data["name"]
            file_path = os.path.join(self.macros_dir, f"{name}.json")
            
            # Eğer aynı isimde bir makro varsa, üzerine yazılıp yazılmayacağını kontrol et
            if os.path.exists(file_path):
                # Burada normalde kullanıcıya sorulabilir, şimdilik otomatik olarak üzerine yazıyoruz
                pass
                
            shutil.copy2(import_path, file_path)
            return {"success": True, "macro_name": name}
        except Exception as e:
            return {"success": False, "error": str(e)}
            
    def test_macro(self, file_path, steps):
        """
        Bir makroyu test eder.
        
        Args:
            file_path (str): Excel dosyası yolu
            steps (list): Test edilecek adımlar
            
        Returns:
            dict: Test sonucu
        """
        try:
            # Excel dosyasını yükle
            df = pd.read_excel(file_path)
            
            # Adımları uygula (burada gerçek bir uygulama yapılmıyor, sadece simülasyon)
            for step in steps:
                # Adım türüne göre işlem yap
                if "Hücre Değeri Değiştir" in step:
                    pass  # Simülasyon
                elif "Formül Ekle" in step:
                    pass  # Simülasyon
                # Diğer adım türleri...
                
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}
            
    def run_macro(self, macro_name, file_path, backup=True, show_progress=True):
        """
        Bir makroyu çalıştırır.
        
        Args:
            macro_name (str): Makro adı
            file_path (str): Excel dosyası yolu
            backup (bool): Yedek alınıp alınmayacağı
            show_progress (bool): İlerlemenin gösterilip gösterilmeyeceği
            
        Returns:
            dict: Çalıştırma sonucu
        """
        try:
            # Makroyu yükle
            macro_result = self.get_macro(macro_name)
            if not macro_result["success"]:
                return {"success": False, "error": "Makro yüklenemedi."}
                
            macro = macro_result["macro"]
            steps = macro["steps"]
            
            # Yedek al
            if backup:
                backup_path = f"{file_path}.backup_{datetime.now().strftime('%Y%m%d%H%M%S')}"
                shutil.copy2(file_path, backup_path)
                
            # Excel dosyasını yükle
            df = pd.read_excel(file_path)
            
            # Çalıştırma zamanını ölç
            start_time = time.time()
            affected_cells = 0
            
            # Adımları uygula
            for i, step in enumerate(steps):
                if show_progress:
                    print(f"Adım {i+1}/{len(steps)}: {step}")
                    
                # Adım türüne göre işlem yap
                if "Hücre Değeri Değiştir" in step:
                    # Simülasyon
                    affected_cells += 1
                elif "Formül Ekle" in step:
                    # Simülasyon
                    affected_cells += 1
                # Diğer adım türleri...
                
            # Değişiklikleri kaydet
            df.to_excel(file_path, index=False)
            
            execution_time = time.time() - start_time
            
            return {
                "success": True,
                "execution_time": round(execution_time, 2),
                "affected_cells": affected_cells
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
            
    def open_web_ui(self):
        """
        Web tabanlı arayüzü açar.
        """
        try:
            # Web arayüzünü başlat
            web_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "excel_macro.html")
            if os.path.exists(web_path):
                # Burada normalde Eel ile web arayüzü başlatılır
                print(f"Web arayüzü açılıyor: {web_path}")
                # eel.start("excel_macro.html", size=(1000, 700))
            else:
                print("Web arayüzü dosyası bulunamadı.")
        except Exception as e:
            print(f"Web arayüzü açılırken hata oluştu: {str(e)}")

# Eel fonksiyonları (Web arayüzü için)
@eel.expose
def select_file():
    """
    Dosya seçme dialog'unu açar.
    
    Returns:
        dict: Seçilen dosya bilgileri
    """
    try:
        # Burada normalde dosya seçme dialog'u açılır
        # Şimdilik simülasyon yapıyoruz
        return {"success": True, "file_path": "C:/example.xlsx"}
    except Exception as e:
        return {"success": False, "error": str(e)}
        
@eel.expose
def select_folder():
    """
    Klasör seçme dialog'unu açar.
    
    Returns:
        dict: Seçilen klasör bilgileri
    """
    try:
        # Burada normalde klasör seçme dialog'u açılır
        # Şimdilik simülasyon yapıyoruz
        return {"success": True, "folder_path": "C:/example_folder"}
    except Exception as e:
        return {"success": False, "error": str(e)}
        
@eel.expose
def load_excel_data(file_path):
    """
    Excel dosyasındaki sheet'leri yükler.
    
    Args:
        file_path (str): Excel dosyası yolu
        
    Returns:
        dict: Sheet listesi
    """
    try:
        # Excel dosyasını yükle
        excel = pd.ExcelFile(file_path)
        sheets = excel.sheet_names
        
        return {"success": True, "sheets": sheets}
    except Exception as e:
        return {"success": False, "error": str(e)}
        
@eel.expose
def load_sheet_columns(file_path, sheet_name):
    """
    Excel sheet'indeki sütunları yükler.
    
    Args:
        file_path (str): Excel dosyası yolu
        sheet_name (str): Sheet adı
        
    Returns:
        dict: Sütun listesi
    """
    try:
        # Sheet'i yükle
        df = pd.read_excel(file_path, sheet_name=sheet_name)
        columns = df.columns.tolist()
        
        return {"success": True, "columns": columns}
    except Exception as e:
        return {"success": False, "error": str(e)}
        
@eel.expose
def save_macro(name, description, steps):
    """
    Yeni bir makro kaydeder.
    
    Args:
        name (str): Makro adı
        description (str): Makro açıklaması
        steps (list): Makro adımları
        
    Returns:
        dict: İşlem sonucu
    """
    try:
        bridge = ExcelBridge()
        success = bridge.save_macro(name, description, steps)
        
        return {"success": success}
    except Exception as e:
        return {"success": False, "error": str(e)}
        
@eel.expose
def get_macro_list():
    """
    Kayıtlı makroların listesini döndürür.
    
    Returns:
        dict: Makro listesi
    """
    try:
        bridge = ExcelBridge()
        macros = bridge.get_macro_list()
        
        return {"success": True, "macros": macros}
    except Exception as e:
        return {"success": False, "error": str(e)}
        
@eel.expose
def get_macro(name):
    """
    Belirtilen makronun detaylarını döndürür.
    
    Args:
        name (str): Makro adı
        
    Returns:
        dict: Makro bilgileri
    """
    try:
        bridge = ExcelBridge()
        return bridge.get_macro(name)
    except Exception as e:
        return {"success": False, "error": str(e)}
        
@eel.expose
def run_macro(macro_name, file_path, backup=True, show_progress=True):
    """
    Bir makroyu çalıştırır.
    
    Args:
        macro_name (str): Makro adı
        file_path (str): Excel dosyası yolu
        backup (bool): Yedek alınıp alınmayacağı
        show_progress (bool): İlerlemenin gösterilip gösterilmeyeceği
        
    Returns:
        dict: Çalıştırma sonucu
    """
    try:
        bridge = ExcelBridge()
        return bridge.run_macro(macro_name, file_path, backup, show_progress)
    except Exception as e:
        return {"success": False, "error": str(e)}